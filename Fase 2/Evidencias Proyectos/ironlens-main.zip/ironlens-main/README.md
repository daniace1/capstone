# IronLens

Android-first Flutter app that scans gym machines with AI and tracks workout progress.

**Philosophy:** Less time looking at your phone, more time training.

## Monorepo structure

```
app/
├── backend/    FastAPI — AI endpoints (scan, recommendations, routine generation)
└── mobile/     Flutter — camera, UI, Supabase auth
```

## Tech stack

| Layer    | Technology                  |
|----------|-----------------------------|
| Mobile   | Flutter + Riverpod          |
| Backend  | FastAPI                     |
| Database | Supabase (PostgreSQL)       |
| AI       | Gemini 2.5 Flash Lite       |

## Quick start

```bash
# Backend
cd backend
cp .env.example .env   # fill in GEMINI_API_KEY, SUPABASE_URL, SUPABASE_SERVICE_KEY
pip install -r requirements.txt
uvicorn main:app --reload

# Mobile
cd mobile
cp .env.example .env   # fill in SUPABASE_URL, SUPABASE_ANON_KEY, API_BASE_URL
flutter pub get
flutter run
```

## Docs

- [Architecture](docs/architecture.md)
- [API contracts](docs/api.md)
- [Database schema](docs/schema.sql)

## Roadmap

### MVP — completed

| Phase | Feature              | Notes                                      |
|-------|----------------------|--------------------------------------------|
| 1     | Auth + profile setup | Login, register, initial profile           |
| 2     | Live camera preview  | Auto-capture                               |
| 3     | Machine recognition  | Gemini via FastAPI, ID-based matching      |
| 4     | Machine collection   | Save scanned machines, browse catalog      |
| 5     | Workout logging      | Sessions + sets, active sessions home card |
| 6     | Progress graphs      | fl_chart, max weight or max reps, 30 days  |

### Phase 2 — AI coach

| Phase | Feature                     | Scope                                                                                                          |
|-------|-----------------------------|----------------------------------------------------------------------------------------------------------------|
| 7     | ✅ Profile & Settings        | Editable profile (weight, height, goal, training days, medical notes); Settings screen with logout. DB: `alter profiles` add `training_days text[]` (default Mon/Wed/Fri), `medical_notes text` |
| 8     | ✅ AI progress recommendations | `POST /recommend` → weekly tip per machine, lazy-generated, cached in DB. Shown below the graph in `MachineProgressPage`. DB: `ai_recommendations (user_id, machine_id, week_start, content)` |
| 9     | ✅ AI routine generation     | `POST /generate-routine` → one active routine per user, weekly lazy-generated. Uses scanned machines + full profile. Routine card on home screen + `/routine` route. DB: `routines`, `routine_days`, `routine_exercises` |
| 10    | ✅ Routine execution         | Simplified logging screen per routine day. Creates `workout_sessions` per exercise (progress tracking unaffected). Tracks completed/skipped. DB: `routine_logs`, `routine_log_items` |
