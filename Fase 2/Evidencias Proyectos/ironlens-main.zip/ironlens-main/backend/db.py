"""Single shared Supabase client (service-role).

Created once and reused across requests, instead of instantiating a new client
on every call inside each router and on every auth check.
"""
from supabase import Client, create_client

import config

_client: Client | None = None


def get_db() -> Client:
    global _client
    if _client is None:
        _client = create_client(config.SUPABASE_URL, config.SUPABASE_SERVICE_KEY)
    return _client
