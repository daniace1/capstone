from typing import Optional
from pydantic import BaseModel


class MachineCandidate(BaseModel):
    machine_name: str
    confidence: float
    muscle_groups: list[str]
    description: str
    machine_id: Optional[int] = None


class ScanResponse(BaseModel):
    candidates: list[MachineCandidate]
