from enum import Enum
from typing import Optional

from pydantic import BaseModel


class NaviActionType(str, Enum):
    # Simple navigation (no params)
    nav_scan             = "nav_scan"
    nav_sessions         = "nav_sessions"
    nav_routine          = "nav_routine"
    nav_collection       = "nav_collection"
    nav_progress         = "nav_progress"
    nav_profile          = "nav_profile"
    nav_monthly_analysis = "nav_monthly_analysis"
    log_weight           = "log_weight"
    regen_routine        = "regen_routine"
    # Machine-specific (require params)
    nav_workout          = "nav_workout"
    nav_machine_progress = "nav_machine_progress"


# Actions that must carry a valid machine_id in params
MACHINE_ACTIONS = {NaviActionType.nav_workout, NaviActionType.nav_machine_progress}


class NaviReportType(str, Enum):
    bmi          = "bmi"            # current BMI + history chart
    machine_rank = "machine_rank"  # rank badge + 1RM (requires machine_id)
    weight_trend = "weight_trend"  # bodyweight trend chart
    best_machine = "best_machine"  # user's strongest machine card


# Reports that must carry a valid machine_id in params
MACHINE_REPORTS = {NaviReportType.machine_rank}


class ChatMessage(BaseModel):
    role: str            # "user" | "assistant"
    content: str


class ChatRequest(BaseModel):
    messages: list[ChatMessage]
    page_context: str = "home"
    active_machine_id: Optional[int] = None


class ChatAction(BaseModel):
    type: NaviActionType
    label: str
    params: Optional[dict] = None


class ChatReport(BaseModel):
    type: NaviReportType
    params: Optional[dict] = None


class ChatResponse(BaseModel):
    message: str
    actions: list[ChatAction] = []
    report: Optional[ChatReport] = None
