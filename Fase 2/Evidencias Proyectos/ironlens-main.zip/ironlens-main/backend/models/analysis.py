from typing import Optional
from pydantic import BaseModel


class SessionSummary(BaseModel):
    date: str
    machine_name: str
    sets_count: int
    max_weight_kg: Optional[float] = None
    max_reps: Optional[int] = None


class RoutineCompletion(BaseModel):
    days_attempted: int
    days_completed: int


class WeightEntry(BaseModel):
    weight_kg: float
    logged_at: str


class AnalysisProfile(BaseModel):
    goal: Optional[str] = None
    weight_kg: Optional[float] = None


class MachineRankEntry(BaseModel):
    machine_id: int
    machine_name: str
    muscle_group: str
    rank: Optional[str] = None
    sessions_this_month: int = 0


class MonthlyAnalysisRequest(BaseModel):
    month_start: str
    sessions: list[SessionSummary] = []
    routine_completion: Optional[RoutineCompletion] = None
    weight_logs: list[WeightEntry] = []
    profile: AnalysisProfile
    machine_ranks: list[MachineRankEntry] = []


class InsightItem(BaseModel):
    label: str
    value: str


class WeaknessMachine(BaseModel):
    machine_id: int
    machine_name: str
    muscle_group: str
    reason: str


class MonthlyAnalysisResponse(BaseModel):
    summary: str
    insights: list[InsightItem]
    weakness_machines: list[WeaknessMachine]
    recommendation: str
