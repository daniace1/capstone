from typing import Optional
from pydantic import BaseModel


class SetData(BaseModel):
    reps: int
    weight_kg: Optional[float] = None


class SessionData(BaseModel):
    date: str
    sets: list[SetData]


class WeightEntry(BaseModel):
    weight_kg: float
    logged_at: str


class UserProfile(BaseModel):
    goal: Optional[str] = None
    weight_kg: Optional[float] = None
    height_cm: Optional[float] = None
    medical_notes: Optional[str] = None
    weight_history: list[WeightEntry] = []


class RecommendRequest(BaseModel):
    machine_id: int
    machine_name: str
    muscle_group: str
    week_start: str  # YYYY-MM-DD
    sessions: list[SessionData]
    profile: UserProfile
    baseline_1rm_kg: Optional[float] = None
    base_recommended_weight_kg: Optional[float] = None


class RecommendResponse(BaseModel):
    content: str
    recommended_weight_kg: Optional[float] = None
    safe_max_weight_kg: Optional[float] = None
