from typing import Optional
from pydantic import BaseModel


class WeightEntry(BaseModel):
    weight_kg: float
    logged_at: str


class MachineHistoryEntry(BaseModel):
    machine_id: int
    name: str
    sessions_count: int
    max_weight_kg: Optional[float] = None
    avg_weight_kg: Optional[float] = None
    avg_reps: Optional[float] = None
    last_used: Optional[str] = None


class RoutineProfile(BaseModel):
    goal: Optional[str] = None
    weight_kg: Optional[float] = None
    height_cm: Optional[float] = None
    training_days: list[str] = []
    medical_notes: Optional[str] = None
    weight_history: list[WeightEntry] = []
    machine_history: list[MachineHistoryEntry] = []


class GenerateRoutineRequest(BaseModel):
    week_start: str  # YYYY-MM-DD
    profile: RoutineProfile


class ExerciseOut(BaseModel):
    machine_id: int
    sets: int
    reps_range: str
    suggested_weight_kg: Optional[float] = None


class DayOut(BaseModel):
    day_of_week: str
    day_label: str
    exercises: list[ExerciseOut]


class GenerateRoutineResponse(BaseModel):
    days: list[DayOut]
