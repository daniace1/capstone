from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

import config  # noqa: F401 — validates required env vars at boot
from routers import analysis, chat, recommend, routine, scan

app = FastAPI(title="IronLens API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(scan.router)
app.include_router(recommend.router)
app.include_router(routine.router)
app.include_router(analysis.router)
app.include_router(chat.router)


@app.get("/health")
def health():
    return {"status": "ok"}
