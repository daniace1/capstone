# IronLens — Backend (FastAPI)

## Setup

```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # fill in keys
uvicorn main:app --reload
```

## Environment variables

| Variable               | Description                              |
|------------------------|------------------------------------------|
| ANTHROPIC_API_KEY      | Claude API key (all AI endpoints)        |
| SUPABASE_URL           | Project URL from Supabase dashboard      |
| SUPABASE_SERVICE_KEY   | Service role key (bypasses RLS for reads)|

## Endpoints

See [../docs/api.md](../docs/api.md) for full contracts.

| Method | Path                          | Description            |
|--------|-------------------------------|------------------------|
| POST   | /scan                         | Identify machine       |
| GET    | /machines                     | Machine catalog        |
| POST   | /sessions                     | Start workout session  |
| POST   | /sessions/{id}/sets           | Log a set              |
| GET    | /users/{user_id}/progress     | Weekly progress data   |

## Auth

Every endpoint validates the Supabase JWT from the `Authorization: Bearer` header.
The middleware checks the token against `SUPABASE_URL/auth/v1/user`.
