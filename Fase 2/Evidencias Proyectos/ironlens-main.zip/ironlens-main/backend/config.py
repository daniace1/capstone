"""Centralised configuration.

Importing this module validates the required environment variables at boot and
fails fast with a clear message — instead of surfacing a KeyError on the first
request. It also centralises the Claude model IDs so they live in one place.
"""
import os

from dotenv import load_dotenv

load_dotenv()

_REQUIRED = ("SUPABASE_URL", "SUPABASE_SERVICE_KEY", "ANTHROPIC_API_KEY")

_missing = [name for name in _REQUIRED if not os.environ.get(name)]
if _missing:
    raise RuntimeError(
        "Missing required environment variables: "
        + ", ".join(_missing)
        + ". Set them in backend/.env (see .env.example)."
    )

SUPABASE_URL         = os.environ["SUPABASE_URL"]
SUPABASE_SERVICE_KEY = os.environ["SUPABASE_SERVICE_KEY"]
ANTHROPIC_API_KEY    = os.environ["ANTHROPIC_API_KEY"]

# Anthropic client behaviour — the SDK retries 429/5xx with exponential backoff.
ANTHROPIC_MAX_RETRIES = 3

# Model per agent (cost / latency / quality trade-off).
SCAN_MODEL      = "claude-haiku-4-5-20251001"  # vision, fast, cheap
RECOMMEND_MODEL = "claude-haiku-4-5-20251001"  # short coaching tip
ROUTINE_MODEL   = "claude-opus-4-8"            # highest quality, infrequent
ANALYSIS_MODEL  = "claude-sonnet-4-6"          # balanced
CHAT_MODEL      = "claude-haiku-4-5-20251001"  # concise, fast (Navi)
