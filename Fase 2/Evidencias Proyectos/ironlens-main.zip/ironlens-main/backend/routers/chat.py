from fastapi import APIRouter, Depends

from auth import get_current_user
from db import get_db
from models.chat import ChatRequest, ChatResponse, ChatAction, ChatReport
from services import chat

router = APIRouter()


def _safe(fn, default):
    """Run a Supabase query defensively — a failing context query must never break chat."""
    try:
        return fn()
    except Exception as e:
        print(f"[chat] context query failed: {e}")
        return default


def _fetch_machines(db, user_id: str) -> list[dict]:
    scanned = _safe(
        lambda: db.from_("scanned_machines")
        .select("machines(id, name, muscle_group)")
        .eq("user_id", user_id)
        .execute()
        .data,
        [],
    )
    machines = [r["machines"] for r in scanned if r.get("machines")]
    if machines:
        return machines
    # Fallback to full catalog if the user hasn't scanned anything yet.
    return _safe(
        lambda: db.from_("machines").select("id, name, muscle_group").execute().data,
        [],
    )


def _fetch_active_machine(db, user_id: str, machine_id: int) -> dict | None:
    machine = _safe(
        lambda: db.from_("machines")
        .select("id, name, muscle_group")
        .eq("id", machine_id)
        .limit(1)
        .execute()
        .data,
        [],
    )
    if not machine:
        return None

    result = dict(machine[0])
    stats = _safe(
        lambda: db.from_("user_machine_stats")
        .select("recommended_weight_kg, safe_max_weight_kg")
        .eq("user_id", user_id)
        .eq("machine_id", machine_id)
        .limit(1)
        .execute()
        .data,
        [],
    )
    if stats:
        result["recommended_weight_kg"] = stats[0].get("recommended_weight_kg")
        result["safe_max_weight_kg"]    = stats[0].get("safe_max_weight_kg")

    # Recent sets on this machine, so tips can reference real numbers.
    sessions = _safe(
        lambda: db.from_("workout_sessions")
        .select("started_at, workout_sets(reps, weight_kg)")
        .eq("user_id", user_id)
        .eq("machine_id", machine_id)
        .order("started_at", desc=True)
        .limit(3)
        .execute()
        .data,
        [],
    )
    recent = []
    for s in sessions:
        for st in (s.get("workout_sets") or []):
            recent.append({"reps": st.get("reps"), "weight_kg": st.get("weight_kg")})
    result["recent_sets"] = recent[:6]
    return result


def _fetch_weekly_routine(db, user_id: str) -> list[dict] | None:
    routine = _safe(
        lambda: db.from_("routines")
        .select("id")
        .eq("user_id", user_id)
        .order("week_start", desc=True)
        .limit(1)
        .execute()
        .data,
        [],
    )
    if not routine:
        return None
    rid = routine[0]["id"]

    days = _safe(
        lambda: db.from_("routine_days")
        .select("id, day_of_week, day_label, order_index, routine_exercises(order_index, machines(name))")
        .eq("routine_id", rid)
        .order("order_index")
        .execute()
        .data,
        [],
    )
    if not days:
        return None

    done = _safe(
        lambda: db.from_("routine_logs")
        .select("routine_day_id")
        .eq("routine_id", rid)
        .not_.is_("ended_at", "null")
        .execute()
        .data,
        [],
    )
    done_ids = {d["routine_day_id"] for d in done}

    result = []
    for day in days:
        exercises = sorted(
            day.get("routine_exercises") or [],
            key=lambda e: e.get("order_index") or 0,
        )
        names = [e["machines"]["name"] for e in exercises if e.get("machines")]
        result.append({
            "day_of_week": day.get("day_of_week"),
            "day_label":   day.get("day_label"),
            "exercises":   names,
            "done":        day.get("id") in done_ids,
        })
    return result


def _fetch_last_session(db, user_id: str) -> dict | None:
    rows = _safe(
        lambda: db.from_("workout_sessions")
        .select("ended_at, machines(name), workout_sets(reps, weight_kg, set_number)")
        .eq("user_id", user_id)
        .not_.is_("ended_at", "null")
        .order("ended_at", desc=True)
        .limit(1)
        .execute()
        .data,
        [],
    )
    if not rows:
        return None
    row = rows[0]
    sets = sorted(
        row.get("workout_sets") or [],
        key=lambda s: s.get("set_number") or 0,
    )
    return {
        "machine_name": (row.get("machines") or {}).get("name", "a machine"),
        "ended_at":     (row.get("ended_at") or "")[:10],
        "sets":         [{"reps": s.get("reps"), "weight_kg": s.get("weight_kg")} for s in sets],
    }


def _fetch_bodyweight(db, user_id: str) -> dict | None:
    logs = _safe(
        lambda: db.from_("weight_logs")
        .select("weight_kg, logged_at")
        .eq("user_id", user_id)
        .order("logged_at", desc=True)
        .limit(10)
        .execute()
        .data,
        [],
    )
    if not logs:
        return None
    latest = logs[0].get("weight_kg")
    oldest = logs[-1].get("weight_kg")
    delta = (latest - oldest) if (latest is not None and oldest is not None) else None
    return {"latest_kg": latest, "delta_kg": delta, "samples": len(logs)}


def _fetch_context(db, user_id: str, page_context: str, active_machine_id: int | None) -> dict:
    profile = _safe(
        lambda: db.from_("profiles")
        .select("name, goal, weight_kg, height_cm")
        .eq("id", user_id)
        .limit(1)
        .execute()
        .data,
        [],
    )

    active_sessions = _safe(
        lambda: db.from_("workout_sessions")
        .select("id")
        .eq("user_id", user_id)
        .is_("ended_at", "null")
        .execute()
        .data,
        [],
    )

    context = {
        "profile":               profile[0] if profile else {},
        "machines":              _fetch_machines(db, user_id),
        "active_sessions_count": len(active_sessions),
        "page_context":          page_context,
        "weekly_routine":        _fetch_weekly_routine(db, user_id),
        "last_session":          _fetch_last_session(db, user_id),
        "bodyweight":            _fetch_bodyweight(db, user_id),
        "active_machine":        None,
    }

    if active_machine_id is not None:
        context["active_machine"] = _fetch_active_machine(db, user_id, active_machine_id)

    return context


@router.post("/chat", response_model=ChatResponse)
async def chat_endpoint(
    body: ChatRequest,
    user=Depends(get_current_user),
):
    db = get_db()
    context = _fetch_context(db, str(user.id), body.page_context, body.active_machine_id)

    result = chat.generate_reply(
        messages=[m.model_dump() for m in body.messages],
        context=context,
    )

    return ChatResponse(
        message=result["message"],
        actions=[ChatAction(**a) for a in result["actions"]],
        report=ChatReport(**result["report"]) if result.get("report") else None,
    )
