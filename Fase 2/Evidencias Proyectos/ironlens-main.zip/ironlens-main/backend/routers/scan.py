from fastapi import APIRouter, Depends, File, UploadFile

from auth import get_current_user
from db import get_db
from models.scan import MachineCandidate, ScanResponse
from services import claude

router = APIRouter()


@router.post("/scan", response_model=ScanResponse)
async def scan_machine(
    image: UploadFile = File(...),
    user=Depends(get_current_user),
):
    machines = (
        get_db()
        .from_("machines")
        .select("id, name, muscle_group, description")
        .execute()
        .data
    )

    image_bytes = await image.read()
    raw_candidates = claude.identify_machine(image_bytes, machines)

    id_to_machine = {m["id"]: m for m in machines}

    candidates = []
    for c in raw_candidates:
        mid = c.get("machine_id")
        machine = id_to_machine.get(mid)
        if machine is None:
            continue
        candidates.append(
            MachineCandidate(
                machine_name=machine["name"],
                confidence=float(c.get("confidence", 0.0)),
                muscle_groups=c.get("muscle_groups", []),
                description=c.get("description", ""),
                machine_id=mid,
            )
        )

    return ScanResponse(candidates=candidates)
