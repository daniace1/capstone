from fastapi import APIRouter, Depends

from auth import get_current_user
from db import get_db
from models.routine import GenerateRoutineRequest, GenerateRoutineResponse, DayOut, ExerciseOut
from services import claude

router = APIRouter()


@router.post("/generate-routine", response_model=GenerateRoutineResponse)
async def generate_routine(
    body: GenerateRoutineRequest,
    user=Depends(get_current_user),
):
    db = get_db()

    # Fetch user's scanned machines with full details
    scanned = (
        db.from_("scanned_machines")
        .select("machine_id, machines(id, name, muscle_group)")
        .eq("user_id", str(user.id))
        .execute()
        .data
    )

    if scanned:
        machines = [row["machines"] for row in scanned if row.get("machines")]
    else:
        # No scanned machines — use full catalog
        machines = (
            db.from_("machines")
            .select("id, name, muscle_group")
            .execute()
            .data
        )

    profile = {
        "goal":            body.profile.goal,
        "weight_kg":       body.profile.weight_kg,
        "height_cm":       body.profile.height_cm,
        "training_days":   body.profile.training_days or ["monday", "wednesday", "friday"],
        "medical_notes":   body.profile.medical_notes,
        "weight_history":  [{"weight_kg": w.weight_kg, "logged_at": w.logged_at} for w in body.profile.weight_history],
        "machine_history": [
            {
                "machine_id":    m.machine_id,
                "name":          m.name,
                "sessions_count": m.sessions_count,
                "max_weight_kg": m.max_weight_kg,
                "avg_weight_kg": m.avg_weight_kg,
                "avg_reps":      m.avg_reps,
                "last_used":     m.last_used,
            }
            for m in body.profile.machine_history
        ],
    }

    raw_days = claude.generate_routine(
        machines=machines,
        profile=profile,
        week_start=body.week_start,
    )

    days = [
        DayOut(
            day_of_week=d.get("day_of_week", ""),
            day_label=d.get("day_label", ""),
            exercises=[
                ExerciseOut(
                    machine_id=e["machine_id"],
                    sets=e.get("sets", 3),
                    reps_range=e.get("reps_range", "8-12"),
                    suggested_weight_kg=e.get("suggested_weight_kg"),
                )
                for e in d.get("exercises", [])
            ],
        )
        for d in raw_days
    ]

    return GenerateRoutineResponse(days=days)
