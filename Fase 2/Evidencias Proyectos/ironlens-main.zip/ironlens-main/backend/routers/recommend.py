from datetime import datetime, timezone

from fastapi import APIRouter, Depends

from auth import get_current_user
from db import get_db
from models.recommend import RecommendRequest, RecommendResponse
from services import claude

router = APIRouter()


@router.post("/recommend", response_model=RecommendResponse)
async def recommend(
    body: RecommendRequest,
    user=Depends(get_current_user),
):
    sessions = [
        {
            "date": s.date,
            "sets": [{"reps": st.reps, "weight_kg": st.weight_kg} for st in s.sets],
        }
        for s in body.sessions
    ]

    profile = {
        "goal":           body.profile.goal,
        "weight_kg":      body.profile.weight_kg,
        "height_cm":      body.profile.height_cm,
        "medical_notes":  body.profile.medical_notes,
        "weight_history": [{"weight_kg": w.weight_kg, "logged_at": w.logged_at} for w in body.profile.weight_history],
    }

    result = claude.recommend_machine(
        machine_name=body.machine_name,
        muscle_group=body.muscle_group,
        sessions=sessions,
        profile=profile,
        baseline_1rm_kg=body.baseline_1rm_kg,
        base_recommended_weight_kg=body.base_recommended_weight_kg,
    )

    recommended_kg = result.get("recommended_weight_kg")
    safe_max_kg    = result.get("safe_max_weight_kg")

    if body.sessions and (recommended_kg is not None or safe_max_kg is not None):
        get_db().table("user_machine_stats").upsert(
            {
                "user_id":               user.id,
                "machine_id":            body.machine_id,
                "recommended_weight_kg": recommended_kg,
                "safe_max_weight_kg":    safe_max_kg,
                "computed_at":           datetime.now(timezone.utc).isoformat(),
            }
        ).execute()

    return RecommendResponse(
        content=result["tip"],
        recommended_weight_kg=recommended_kg,
        safe_max_weight_kg=safe_max_kg,
    )
