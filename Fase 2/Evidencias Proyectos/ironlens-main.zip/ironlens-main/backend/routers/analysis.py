from fastapi import APIRouter, Depends

from auth import get_current_user
from models.analysis import MonthlyAnalysisRequest, MonthlyAnalysisResponse
from services import claude

router = APIRouter()


@router.post("/monthly-analysis", response_model=MonthlyAnalysisResponse)
async def monthly_analysis(
    body: MonthlyAnalysisRequest,
    user=Depends(get_current_user),
):
    result = claude.monthly_analysis(
        month_start=body.month_start,
        sessions=[s.model_dump() for s in body.sessions],
        routine_completion=body.routine_completion.model_dump() if body.routine_completion else None,
        weight_logs=[w.model_dump() for w in body.weight_logs],
        profile=body.profile.model_dump(),
        machine_ranks=[m.model_dump() for m in body.machine_ranks],
    )
    return MonthlyAnalysisResponse(**result)
