import config
from models.chat import (
    NaviActionType,
    NaviReportType,
    MACHINE_ACTIONS,
    MACHINE_REPORTS,
)
from services import llm

_VALID_TYPES = {t.value for t in NaviActionType}
_VALID_REPORT_TYPES = {t.value for t in NaviReportType}
_MACHINE_REPORT_TYPES = {t.value for t in MACHINE_REPORTS}
_FALLBACK_MESSAGE = "I couldn't process that. Try again."
_MAX_ACTIONS = 3

# Structured output schema for Navi replies — guarantees the shape so the
# client never has to parse free-form text.
_NAVI_SCHEMA = {
    "type": "object",
    "properties": {
        "message": {
            "type": "string",
            "description": "Reply text. A one-line lead-in when a report is attached.",
        },
        "actions": {
            "type": "array",
            "description": f"Up to {_MAX_ACTIONS} navigation chips. Empty if none are useful.",
            "items": {
                "type": "object",
                "properties": {
                    "type": {"type": "string", "enum": sorted(_VALID_TYPES)},
                    "label": {"type": "string", "description": "<= 3 words."},
                    "params": {
                        "type": ["object", "null"],
                        "description": 'e.g. {"machine_id": 1} for machine-specific actions.',
                    },
                },
                "required": ["type", "label"],
            },
        },
        "report": {
            "type": ["object", "null"],
            "description": "Inline data widget to render, or null. Set only when the user asks to SEE data.",
            "properties": {
                "type": {"type": "string", "enum": sorted(_VALID_REPORT_TYPES)},
                "params": {
                    "type": ["object", "null"],
                    "description": 'e.g. {"machine_id": 1} for machine_rank.',
                },
            },
            "required": ["type"],
        },
    },
    "required": ["message", "actions", "report"],
}


def _format_sets(sets: list[dict]) -> str:
    return ", ".join(
        f'{s["weight_kg"]}kg x{s["reps"]}'
        if s.get("weight_kg") else f'{s.get("reps", "?")} reps (bw)'
        for s in sets
    )


def build_system_prompt(context: dict) -> str:
    profile  = context.get("profile") or {}
    machines = context.get("machines") or []

    machines_block = "\n".join(
        f'  {{"id": {m["id"]}, "name": "{m["name"]}", "muscle_group": "{m["muscle_group"]}"}}'
        for m in machines
    ) or "  (none yet)"

    # Weekly routine (full week, with completion state)
    week = context.get("weekly_routine")
    if week:
        rows = []
        for d in week:
            ex = ", ".join(d.get("exercises") or []) or "rest"
            status = "done" if d.get("done") else "pending"
            rows.append(f'  {d.get("day_of_week", "?")} — {d.get("day_label", "")}: {ex} [{status}]')
        routine_block = "\n".join(rows)
    else:
        routine_block = "  No routine generated yet."

    # Last completed session
    last = context.get("last_session")
    if last and last.get("sets"):
        last_line = f'{last["machine_name"]} on {last["ended_at"]} — {_format_sets(last["sets"])}'
    else:
        last_line = "none recorded yet"

    # Bodyweight
    bw = context.get("bodyweight")
    if bw and bw.get("latest_kg") is not None:
        delta = bw.get("delta_kg")
        if delta is not None:
            sign = "+" if delta > 0 else ""
            bw_line = f'{bw["latest_kg"]}kg (latest), {sign}{delta:.1f}kg over last {bw.get("samples", 0)} logs'
        else:
            bw_line = f'{bw["latest_kg"]}kg (latest)'
    else:
        bw_line = "no logs yet"

    # Active machine (+ recent sets on it)
    active = context.get("active_machine")
    if active:
        parts = [f'{active["name"]} ({active["muscle_group"]})']
        if active.get("recommended_weight_kg"):
            parts.append(f'recommended {active["recommended_weight_kg"]}kg')
        if active.get("safe_max_weight_kg"):
            parts.append(f'safe max {active["safe_max_weight_kg"]}kg')
        if active.get("recent_sets"):
            parts.append(f'recent: {_format_sets(active["recent_sets"])}')
        active_line = " | ".join(parts)
    else:
        active_line = "none"

    return f"""You are Navi, a gym AI assistant for IronLens.

USER: {profile.get('name', 'athlete')}, goal: {profile.get('goal', 'general')}, weight: {profile.get('weight_kg', 'unknown')}kg, height: {profile.get('height_cm', 'unknown')}cm
BODYWEIGHT: {bw_line}
ACTIVE SESSIONS: {context.get('active_sessions_count', 0)}
PAGE: {context.get('page_context', 'home')}
ACTIVE MACHINE: {active_line}
LAST SESSION: {last_line}
WEEKLY ROUTINE:
{routine_block}
MACHINES (user's collection — use ONLY these ids):
[
{machines_block}
]

RULES:
1. English only.
2. Length adapts to the question:
   - Navigation / quick replies: 1-2 sentences.
   - Data / analysis / opinion (e.g. "how was my last session", "give me a tip",
     "how am I progressing"): up to 4 sentences with a brief, useful opinion grounded
     in the context above. Never pad.
3. Ground every claim in the context above. If the needed data is missing, say so in
   one line instead of inventing numbers.
4. Call the `reply` tool with your message, any actions, and a report (or null).
5. Available action types:
   nav_scan, nav_sessions, nav_routine, nav_collection, nav_progress,
   nav_profile, nav_monthly_analysis, log_weight, regen_routine,
   nav_workout (requires params.machine_id), nav_machine_progress (requires params.machine_id)
6. Only use machine_ids from the MACHINES list above.
7. Only include actions genuinely useful for the current PAGE and question. Max {_MAX_ACTIONS}.
   Each action has "type", "label" (<= 3 words), and optional "params".
8. "report": when the user asks to SEE data, set this to an object that renders an inline widget.
   Otherwise null. The app fetches and draws the data — you only pick the type.

   EXAMPLES of correct report structure:
   - User asks "what's my BMI?" → {{ "type": "bmi", "params": null }}
   - User asks "my weight trend?" → {{ "type": "weight_trend", "params": null }}
   - User asks "strongest machine?" → {{ "type": "best_machine", "params": null }}
   - User asks "rank on chest press?" (active_machine_id=1) → {{ "type": "machine_rank", "params": {{"machine_id": 1, "machine_name": "Chest Press"}} }}

   Keep "message" as a one-line lead-in; the widget shows the detail.
   If no report needed, use null (not a string)."""


def _validate(raw: dict, machines: list[dict]) -> dict:
    """Sanitize Claude output so a malformed reply can never reach the client.

    Structured Outputs guarantees the shape; this enforces the semantics
    (valid action types, real machine ids, action cap).
    """
    by_id = {m["id"]: m for m in machines}

    message = (raw.get("message") or "").strip()
    if not message:
        message = _FALLBACK_MESSAGE

    clean: list[dict] = []
    for action in raw.get("actions") or []:
        if not isinstance(action, dict):
            continue
        a_type = action.get("type")
        if a_type not in _VALID_TYPES:
            continue

        label = (action.get("label") or "").strip()
        if not label:
            continue

        params = action.get("params") if isinstance(action.get("params"), dict) else None

        if a_type in {t.value for t in MACHINE_ACTIONS}:
            machine_id = (params or {}).get("machine_id")
            machine = by_id.get(machine_id)
            if machine is None:
                continue  # hallucinated / unscanned machine → drop
            # Enrich from catalog so the client always gets correct names.
            params = {
                "machine_id":   machine["id"],
                "machine_name": machine["name"],
                "muscle_group": machine["muscle_group"],
            }

        clean.append({"type": a_type, "label": label, "params": params})
        if len(clean) >= _MAX_ACTIONS:
            break

    return {"message": message, "actions": clean, "report": _validate_report(raw, by_id)}


def _validate_report(raw: dict, by_id: dict) -> dict | None:
    report = raw.get("report")
    if not isinstance(report, dict):
        return None

    r_type = report.get("type")
    if r_type not in _VALID_REPORT_TYPES:
        return None

    params = report.get("params") if isinstance(report.get("params"), dict) else None

    if r_type in _MACHINE_REPORT_TYPES:
        machine = by_id.get((params or {}).get("machine_id"))
        if machine is None:
            return None  # rank report needs a real machine
        params = {"machine_id": machine["id"], "machine_name": machine["name"]}

    return {"type": r_type, "params": params}


def generate_reply(messages: list[dict], context: dict) -> dict:
    system_prompt = build_system_prompt(context)

    # Convert messages to Anthropic format.
    api_messages = [
        {
            "role": "assistant" if m.get("role") == "assistant" else "user",
            "content": m.get("content", ""),
        }
        for m in messages
        if m.get("content")
    ]

    try:
        raw = llm.extract_tool_output(
            model=config.CHAT_MODEL,
            max_tokens=1024,
            system=system_prompt,
            messages=api_messages,
            temperature=0.4,
            tool_name="reply",
            tool_description="Reply to the user with a message, optional navigation actions, and an optional inline report.",
            input_schema=_NAVI_SCHEMA,
        )
    except Exception as e:
        print(f"[chat] claude error: {e}")
        return {"message": "Navi is unavailable right now. Try again shortly.", "actions": []}

    return _validate(raw, context.get("machines") or [])
