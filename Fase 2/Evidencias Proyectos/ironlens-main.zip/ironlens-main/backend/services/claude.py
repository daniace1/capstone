"""Claude AI agents (scan, recommend, routine, analysis).

Each agent uses Structured Outputs (forced tool use, see `services.llm`) so the
returned shape is guaranteed and there is no markdown-stripping / json.loads
fragility. Business-level validation (e.g. machine_id must exist) still happens
in the routers — Structured Outputs guarantees the shape, not the semantics.
On any Claude failure, agents return a neutral fallback instead of raising 500.
"""
import base64

import config
from services import llm


def _format_weight_history(history: list[dict]) -> str:
    if not history:
        return ""
    lines = [f"  {w['logged_at']}: {w['weight_kg']} kg" for w in history]
    if len(history) >= 2:
        delta = history[-1]["weight_kg"] - history[0]["weight_kg"]
        sign = "+" if delta > 0 else ""
        lines.append(f"Trend: {sign}{delta:.1f} kg over the period")
    return "\nWeight history (last 30 days):\n" + "\n".join(lines)


def _format_machine_history(history: list[dict]) -> str:
    if not history:
        return ""
    lines = []
    for m in history:
        parts = [f"  {m['name']}: {m['sessions_count']} session(s)"]
        if m.get("max_weight_kg"):
            parts.append(f"max {m['max_weight_kg']} kg")
            parts.append(f"avg {m['avg_weight_kg']:.1f} kg")
        if m.get("avg_reps"):
            parts.append(f"avg {float(m['avg_reps']):.0f} reps")
        if m.get("last_used"):
            parts.append(f"last used {m['last_used']}")
        lines.append(", ".join(parts))
    return "\nMachine usage history (last 30 days):\n" + "\n".join(lines)


# ── scan ──────────────────────────────────────────────────────────────────

_SCAN_SCHEMA = {
    "type": "object",
    "properties": {
        "candidates": {
            "type": "array",
            "description": "Exactly 3 candidates, ordered by confidence descending.",
            "items": {
                "type": "object",
                "properties": {
                    "machine_id": {
                        "type": "integer",
                        "description": "Exact id from the catalog. Never invent one.",
                    },
                    "confidence": {
                        "type": "number",
                        "description": "0.0–1.0 confidence for this candidate.",
                    },
                },
                "required": ["machine_id", "confidence"],
            },
        }
    },
    "required": ["candidates"],
}


def identify_machine(image_bytes: bytes, machines: list[dict], mime_type: str = "image/jpeg") -> list[dict]:
    """Identify a gym machine from an image using Claude Haiku vision.

    Returns a list of candidate dicts ({machine_id, confidence}); empty on failure.
    """
    rows = "\n".join(
        f'  {{"id": {m["id"]}, "name": "{m["name"]}", "muscle_group": "{m["muscle_group"]}"}}'
        for m in machines
    )

    system_prompt = f"""You are a gym machine identifier for a gym tracking app.

Available machines catalog (use only these ids):
[
{rows}
]

Report EXACTLY 3 candidates from the catalog, ordered by confidence descending.
- Candidate 1: the best match for what is visible.
- Candidates 2 and 3: other plausible machines from the catalog that could be confused
  with candidate 1, or that share the same muscle groups. Lower confidence (e.g. 0.3–0.6).
- If the image shows nothing gym-related, still return 3 candidates with very low confidence (< 0.2).

CRITICAL: machine_id must be an exact integer from the catalog above. Never invent an id."""

    image_data = base64.standard_b64encode(image_bytes).decode("utf-8")

    try:
        result = llm.extract_tool_output(
            model=config.SCAN_MODEL,
            max_tokens=1024,
            system=system_prompt,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": mime_type,
                                "data": image_data,
                            },
                        },
                        {"type": "text", "text": "Identify this gym machine from the catalog."},
                    ],
                }
            ],
            tool_name="report_candidates",
            tool_description="Report the 3 most likely gym machines from the catalog.",
            input_schema=_SCAN_SCHEMA,
        )
    except Exception as e:
        print(f"[claude] scan error: {e}")
        return []

    raw = result.get("candidates", [])
    print(f"[claude] scan: {len(raw)} candidates")
    return raw


# ── recommend ─────────────────────────────────────────────────────────────

_RECOMMEND_SCHEMA = {
    "type": "object",
    "properties": {
        "tip": {
            "type": "string",
            "description": "2-3 sentence coaching tip. Specific and encouraging. Plain text, no markdown.",
        },
        "recommended_weight_kg": {
            "type": ["number", "null"],
            "description": "Personalized working weight for sets of 8-12 reps, or null if no history / bodyweight-only.",
        },
        "safe_max_weight_kg": {
            "type": ["number", "null"],
            "description": "Max safe weight for a single set, anchored to baseline if provided, or null.",
        },
    },
    "required": ["tip", "recommended_weight_kg", "safe_max_weight_kg"],
}


def recommend_machine(
    machine_name: str,
    muscle_group: str,
    sessions: list[dict],
    profile: dict,
    baseline_1rm_kg: float | None = None,
    base_recommended_weight_kg: float | None = None,
) -> dict:
    """Recommend weight and a coaching tip for a machine, based on user history."""
    medical = profile.get("medical_notes")
    medical_line = f"- Medical notes: {medical}" if medical else ""

    if sessions:
        lines = []
        for s in sessions:
            sets_text = ", ".join(
                f"{st['reps']} reps @ {st['weight_kg']} kg"
                if st.get("weight_kg") else f"{st['reps']} reps (bodyweight)"
                for st in s["sets"]
            )
            lines.append(f"  {s['date']}: {sets_text}")
        history = "\n".join(lines)
    else:
        history = "  No sessions recorded yet."

    weight_section = _format_weight_history(profile.get("weight_history", []))

    ref_parts = []
    if baseline_1rm_kg:
        ref_parts.append(f"- Estimated 1RM baseline: {baseline_1rm_kg} kg")
    if base_recommended_weight_kg:
        ref_parts.append(f"- Default working weight for sets: {base_recommended_weight_kg} kg")
    machine_ref = ("\nMachine reference:\n" + "\n".join(ref_parts)) if ref_parts else ""

    no_history_note = (
        "\nNote: No training history available — return null for both weight fields.\n"
        if not sessions else ""
    )

    prompt = f"""You are a personal fitness coach. Analyze this user's training data.

User profile:
- Goal: {profile.get('goal', 'general')}
- Weight: {profile.get('weight_kg', 'unknown')} kg
- Height: {profile.get('height_cm', 'unknown')} cm
{medical_line}{weight_section}

Machine: {machine_name} ({muscle_group}){machine_ref}

Training history (last 30 days):
{history}
{no_history_note}
Rules:
- tip: plain text, 2-3 sentences, no markdown. If medical notes present, factor them in.
- recommended_weight_kg: use history averages/trend + goal for progression. null if no history or bodyweight-only.
- safe_max_weight_kg: do not exceed baseline_1rm_kg if provided. null if no history or bodyweight-only."""

    try:
        result = llm.extract_tool_output(
            model=config.RECOMMEND_MODEL,
            max_tokens=512,
            messages=[{"role": "user", "content": prompt}],
            tool_name="report_recommendation",
            tool_description="Report a coaching tip and weight recommendations.",
            input_schema=_RECOMMEND_SCHEMA,
        )
    except Exception as e:
        print(f"[claude] recommend error: {e}")
        result = {}

    return {
        "tip": result.get("tip", ""),
        "recommended_weight_kg": result.get("recommended_weight_kg"),
        "safe_max_weight_kg": result.get("safe_max_weight_kg"),
    }


# ── routine ───────────────────────────────────────────────────────────────

_ROUTINE_SCHEMA = {
    "type": "object",
    "properties": {
        "days": {
            "type": "array",
            "description": "One entry per training day.",
            "items": {
                "type": "object",
                "properties": {
                    "day_of_week": {"type": "string", "description": "One of the training days."},
                    "day_label": {"type": "string", "description": "Descriptive label, e.g. 'Day A — Chest & Triceps'."},
                    "exercises": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "machine_id": {"type": "integer", "description": "Exact id from the catalog."},
                                "sets": {"type": "integer", "description": "3 or 4."},
                                "reps_range": {"type": "string", "description": "e.g. '8-12'."},
                                "suggested_weight_kg": {
                                    "type": ["number", "null"],
                                    "description": "Estimated starting weight in kg, or null for bodyweight.",
                                },
                            },
                            "required": ["machine_id", "sets", "reps_range", "suggested_weight_kg"],
                        },
                    },
                },
                "required": ["day_of_week", "day_label", "exercises"],
            },
        }
    },
    "required": ["days"],
}


def generate_routine(machines: list[dict], profile: dict, week_start: str) -> list[dict]:
    """Generate a weekly workout routine using Claude Opus. Empty list on failure."""
    training_days = profile.get("training_days") or ["monday", "wednesday", "friday"]
    medical = profile.get("medical_notes")
    medical_line = f"- Medical notes: {medical}" if medical else ""

    rows = "\n".join(
        f'  {{"id": {m["id"]}, "name": "{m["name"]}", "muscle_group": "{m["muscle_group"]}"}}'
        for m in machines
    )

    weight_section = _format_weight_history(profile.get("weight_history", []))
    history_section = _format_machine_history(profile.get("machine_history", []))

    prompt = f"""You are a personal fitness coach creating a weekly workout routine.

User profile:
- Goal: {profile.get('goal', 'general')}
- Weight: {profile.get('weight_kg', 'unknown')} kg
- Height: {profile.get('height_cm', 'unknown')} cm
- Training days: {', '.join(training_days)}
{medical_line}{weight_section}{history_section}

Available machines (use ONLY these ids):
[
{rows}
]

Create a balanced weekly routine covering the training days above.
Rules:
- 3-5 exercises per day. One entry per training day ({', '.join(training_days)}).
- Balance muscle groups across days to avoid consecutive same-group sessions.
- sets: 3-4 | reps_range: "4-6" strength, "8-12" hypertrophy, "12-15" endurance. Adjust to goal.
- If medical notes are present, avoid machines that could worsen the condition.
- suggested_weight_kg: always estimate a starting weight in kg. Use machine history if available;
  otherwise estimate from body weight, height and goal (~30-40% body weight upper body, ~60-80% legs).
  Use null only for pure bodyweight exercises (e.g. pull-up bar).
- day_of_week must be exactly one of: {', '.join(training_days)}.

CRITICAL: machine_id must be an exact integer from the catalog above."""

    try:
        result = llm.extract_tool_output(
            model=config.ROUTINE_MODEL,
            max_tokens=2048,
            messages=[{"role": "user", "content": prompt}],
            tool_name="report_routine",
            tool_description="Report the generated weekly workout routine.",
            input_schema=_ROUTINE_SCHEMA,
        )
    except Exception as e:
        print(f"[claude] routine error: {e}")
        return []

    raw = result.get("days", [])
    print(f"[claude] routine: {len(raw)} days")
    return raw


# ── monthly analysis ──────────────────────────────────────────────────────

_ANALYSIS_SCHEMA = {
    "type": "object",
    "properties": {
        "summary": {"type": "string", "description": "2-3 sentence overall assessment. Plain text."},
        "insights": {
            "type": "array",
            "description": "Exactly 3 items.",
            "items": {
                "type": "object",
                "properties": {
                    "label": {"type": "string", "description": "Short label, e.g. 'consistency'."},
                    "value": {"type": "string", "description": "Concise value."},
                },
                "required": ["label", "value"],
            },
        },
        "weakness_machines": {
            "type": "array",
            "description": "Exactly 2 machines from the user's collection.",
            "items": {
                "type": "object",
                "properties": {
                    "machine_id": {"type": "integer", "description": "Exact id from the collection."},
                    "machine_name": {"type": "string", "description": "Exact name from the collection."},
                    "muscle_group": {"type": "string", "description": "Exact muscle_group from the collection."},
                    "reason": {"type": "string", "description": "One sentence: why this is a weakness."},
                },
                "required": ["machine_id", "machine_name", "muscle_group", "reason"],
            },
        },
        "recommendation": {"type": "string", "description": "One concrete, actionable sentence for next month."},
    },
    "required": ["summary", "insights", "weakness_machines", "recommendation"],
}


def monthly_analysis(
    month_start: str,
    sessions: list[dict],
    routine_completion: dict | None,
    weight_logs: list[dict],
    profile: dict,
    machine_ranks: list[dict] = [],
) -> dict:
    """Generate a structured monthly training analysis using Claude Sonnet."""
    if sessions:
        lines = []
        for s in sessions:
            line = f"  {s['date']}: {s['machine_name']} — {s['sets_count']} sets"
            if s.get("max_weight_kg"):
                line += f", max {s['max_weight_kg']} kg"
            if s.get("max_reps"):
                line += f", max {s['max_reps']} reps"
            lines.append(line)
        sessions_text = "\n".join(lines)
    else:
        sessions_text = "  No sessions recorded this month."

    if routine_completion:
        attempted = routine_completion["days_attempted"]
        completed = routine_completion["days_completed"]
        pct = round(completed / attempted * 100) if attempted > 0 else 0
        routine_text = f"{completed}/{attempted} routine days completed ({pct}%)"
    else:
        routine_text = "No routine data available."

    if machine_ranks:
        rank_lines = []
        for m in machine_ranks:
            rank = m.get("rank") or "unranked"
            monthly = m["sessions_this_month"]
            rank_lines.append(
                f"  machine_id={m['machine_id']} | {m['machine_name']} ({m['muscle_group']}) | rank: {rank} | sessions this month: {monthly}"
            )
        ranks_text = "\n".join(rank_lines)
    else:
        ranks_text = "  No machine rank data available."

    weight_section = _format_weight_history(weight_logs)
    machine_ids = [m["machine_id"] for m in machine_ranks]

    prompt = f"""You are a personal fitness coach. Generate a structured monthly training analysis.

Month: {month_start}
Goal: {profile.get('goal', 'general')}
Current weight: {profile.get('weight_kg', 'unknown')} kg
{weight_section}

Routine completion: {routine_text}

Training sessions this month:
{sessions_text}

User's machine collection with ranks (use ONLY these machine_ids for weakness_machines):
{ranks_text}

Rules:
- insights: exactly 3 items. Good labels: "consistency", "sessions", "strongest rank", "weakest area", "weight trend".
- weakness_machines: exactly 2 machines with low/no sessions this month OR low rank. machine_id MUST be from: {machine_ids}
- summary: plain text, no markdown.
- recommendation: specific and actionable."""

    try:
        return llm.extract_tool_output(
            model=config.ANALYSIS_MODEL,
            max_tokens=1024,
            messages=[{"role": "user", "content": prompt}],
            tool_name="report_analysis",
            tool_description="Report the structured monthly training analysis.",
            input_schema=_ANALYSIS_SCHEMA,
        )
    except Exception as e:
        print(f"[claude] analysis error: {e}")
        # Neutral fallback so the endpoint never 500s.
        return {
            "summary": "Analysis is unavailable right now. Try again shortly.",
            "insights": [],
            "weakness_machines": [],
            "recommendation": "",
        }
