"""Shared Anthropic client + Structured Outputs helper.

Centralises the single Anthropic client (with retries) and the forced-tool-use
pattern used for Structured Outputs: the desired response shape is declared as a
tool's `input_schema` and the model is forced to call that tool, so the returned
`input` is guaranteed to match the schema. This removes the fragile
"strip markdown + json.loads" parsing the agents used before.
"""
from anthropic import Anthropic

import config

_client: Anthropic | None = None


def client() -> Anthropic:
    global _client
    if _client is None:
        _client = Anthropic(
            api_key=config.ANTHROPIC_API_KEY,
            max_retries=config.ANTHROPIC_MAX_RETRIES,
        )
    return _client


def extract_tool_output(
    *,
    model: str,
    messages: list[dict],
    tool_name: str,
    tool_description: str,
    input_schema: dict,
    max_tokens: int,
    system: str | None = None,
    temperature: float | None = None,
) -> dict:
    """Force Claude to call one tool and return its `input` (guaranteed shape).

    Raises ValueError if no tool_use block comes back; callers handle that as an
    error and return their own neutral fallback.
    """
    kwargs: dict = {
        "model": model,
        "max_tokens": max_tokens,
        "messages": messages,
        "tools": [
            {
                "name": tool_name,
                "description": tool_description,
                "input_schema": input_schema,
            }
        ],
        "tool_choice": {"type": "tool", "name": tool_name},
    }
    if system is not None:
        kwargs["system"] = system
    if temperature is not None:
        kwargs["temperature"] = temperature

    response = client().messages.create(**kwargs)
    for block in response.content:
        if block.type == "tool_use":
            return block.input
    raise ValueError("Claude returned no tool_use block")
