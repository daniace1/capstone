# IronLens — Handoff (Fase K Completa)

## Estado General
- **MVP:** ✅ Todas 6 fases completadas (auth, camera, scan, collection, sessions, progress)
- **Phase 2 (AI Coach):** 🔄 Fase K (IA migration) **COMPLETA**
- **Próximo:** Fase K+ (refactor arquitectura + Structured Outputs)

---

## Fase K — Migración Gemini → Claude (HECHO)

### Cambios Principales
1. **Backend migrado a Anthropic SDK**
   - `services/gemini.py` → `services/claude.py` (5 funciones IA)
   - `services/chat.py` → Anthropic client (Navi asistente)
   - Modelos por agente: Haiku (scan, recommend, chat), Opus (routine), Sonnet (analysis)
   - Una sola key: `ANTHROPIC_API_KEY`

2. **System prompt mejorado (CRÍTICO)**
   - ✅ Ahora tiene ejemplos JSON **explícitos** para cada report type
   - ✅ Soluciona bug donde Claude devolvía `"report": "bmi"` en lugar de `{ "type": "bmi" }`
   - Archivos afectados: `backend/services/chat.py` línea 104-128

3. **Todos los routers actualizados**
   - scan.py, recommend.py, routine.py, analysis.py, chat.py
   - Importan de `services.claude` y `services.chat`

4. **Dependencias**
   - `requirements.txt`: `google-genai` → `anthropic`
   - `.env.example`: 2 keys Gemini → 1 key Anthropic

### Tests Validados
- ✅ `/scan` — Haiku detecta máquinas correctamente
- ✅ `/recommend` — Haiku devuelve peso + tip personalizado
- ✅ `/generate-routine` — Opus genera plan semanal
- ✅ `/monthly-analysis` — Sonnet analiza mes completo
- ✅ `/chat` (Navi) — Haiku responde con message + actions + **report válido**

### Commits
```
a20bf2d feat: migrate IA backend from Gemini to Claude (Anthropic SDK)
880d4c6 docs: update tech stack and roadmap (Gemini → Claude migration)
```

---

## Lecciones Aprendidas

### 1. System Prompts Frágiles
**Problema:** LLMs pequeños (Haiku) no siguen instrucciones textuales ambiguas
```
❌ MALO:   "return 'bmi' if user asks about BMI"
✅ BUENO:  "return { 'type': 'bmi', 'params': null } — Example: User says 'what's my BMI?' → { 'type': 'bmi', 'params': null }"
```

**Solución:** Few-shot examples en el prompt (hecho hoy)
**Mejora futura:** Structured Outputs de Anthropic (Fase K+)

### 2. Validación en Múltiples Capas
- Backend: `_validate()` filtra JSON inválido
- Flutter: `NaviReportView` verifica tipos esperados
- Never trust LLM output directly

### 3. Rate Limiting Importante para Demo
- Anthropic free tier: ~3 req/sec
- Si repites preguntas rápido → 429 error
- Agregar cooldown visual antes de presentación

---

## Setup Próximo (para quien continúe)

### Prerequisitos
```bash
cd backend
pip install -r requirements.txt
# Requiere: ANTHROPIC_API_KEY en .env

cd mobile
flutter pub get
# Flutter 3.11+, Android SDK 28+
```

### Testing Local
```bash
# Terminal 1: Backend
cd backend && uvicorn main:app --reload

# Terminal 2: Mobile
cd mobile && flutter run

# En app:
# 1. Login
# 2. Abre Home → Navi dock (abajo)
# 3. Pregunta: "what's my BMI?" → debería mostrar gráfico
```

---

## Fase K+ — Próxima Iteración

### Objetivo
Hacer el backend **bulletproof** para producción sin sacrificar velocidad.

### Cambios Planeados
1. **Refactor arquitectura FastAPI**
   - `config.py` (env vars, constants)
   - `dependencies.py` (inyección: DB, auth)
   - `core/security.py` (auth con caché)
   - `services/` reutilizable (no queries repetidas)

2. **Structured Outputs (Anthropic)**
   - JSON schema garantizado válido
   - Sin validación manual
   - Elimina clase de bugs de prompts

3. **Error Handling Consistente**
   - Custom exceptions
   - Middleware global
   - Logging estructurado

4. **Tests Automatizados**
   - pytest para servicios
   - Mocks de Anthropic
   - Validación de schemas

### Estimado
- 6-8 horas (solo backend, mobile sin cambios)

---

## Git History
```
880d4c6 docs: update tech stack and roadmap
a20bf2d feat: migrate IA backend from Gemini to Claude
29e8294 feat: add weight logging functionality with dialog
89c6e72 feat: enhance HomeNotification to support in-situ weight logging
```

---

## Archivos Clave

### Backend
- `backend/services/claude.py` — 5 agentes IA (scan, recommend, routine, analysis)
- `backend/services/chat.py` — Navi (contexto + validación)
- `backend/routers/{scan,recommend,routine,analysis,chat}.py` — Endpoints
- `backend/.env.example` — Vars requeridas

### Mobile
- `mobile/lib/features/navi/` — Asistente conversacional
- `mobile/lib/core/fitness/` — Utils compartidas (BMI, 1RM, rank)
- `mobile/lib/core/network/api_client.dart` — HTTP + JWT auto-injected

### Docs
- `docs/features.md` — Roadmap técnico detallado
- `CLAUDE.md` — Contexto para Claude Code
- `tech-stack.md` — Stack enforcement

---

## Notas para Presentación
- ✅ Todos los endpoints funcionan
- ⚠️ Rate limit Anthropic: esperar 2-3s entre preguntas en demo
- ✅ Navi devuelve reports correctamente (BMI chart, rank badge, etc)
- 💰 ~$50 crédito Anthropic = 1000s de requests (OK para demo)

---

## Contacto/Preguntas
- Código: Ver git history
- Bugs: Revisar system prompt en `services/chat.py` línea 104-128
- Próxima fase: Structured Outputs + refactor arquitectura
