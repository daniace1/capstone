package com.example.ironlens

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
