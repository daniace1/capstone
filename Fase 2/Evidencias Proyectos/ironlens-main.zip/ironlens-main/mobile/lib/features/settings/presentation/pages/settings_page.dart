import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/notifications/weight_reminder.dart';
import '../../../../core/preferences/rest_timer.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/pressable.dart';
import '../../../../core/units/unit_system.dart';
import '../../../navi/data/navi_prefs.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  int  _reminderDays  = 14;
  int  _restSeconds   = 90;
  bool _naviVoice     = false;
  bool _naviShowText  = true;

  @override
  void initState() {
    super.initState();
    getWeightReminderDays().then((d) {
      if (mounted) setState(() => _reminderDays = d);
    });
    getRestTimerSeconds().then((s) {
      if (mounted) setState(() => _restSeconds = s);
    });
    getNaviVoiceEnabled().then((v) {
      if (mounted) setState(() => _naviVoice = v);
    });
    getNaviShowText().then((v) {
      if (mounted) setState(() => _naviShowText = v);
    });
  }

  @override
  Widget build(BuildContext context) {
    final isImperial = UnitSystemScope.of(context).isImperial;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(
                children: [
                  Pressable(
                    onTap: () => context.go(AppRoutes.home),
                    child: const Text(
                      '← back',
                      style: TextStyle(
                          fontSize: 12,
                          color: AppColors.textSecondary,
                          fontFamily: 'monospace'),
                    ),
                  ),
                  const Spacer(),
                  const Text(
                    'settings',
                    style: TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                        fontFamily: 'monospace'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 32),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 36),
              child: Text(
                'SETTINGS',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w200,
                  color: AppColors.textPrimary,
                  letterSpacing: 8,
                  fontFamily: 'monospace',
                ),
              ),
            ),
            const SizedBox(height: 40),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36),
              child: _UnitToggle(isImperial: isImperial),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36),
              child: _WeightReminderSetting(
                currentDays: _reminderDays,
                onChanged: (days) async {
                  await setWeightReminderDays(days);
                  if (mounted) setState(() => _reminderDays = days);
                },
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36),
              child: _RestTimerSetting(
                currentSeconds: _restSeconds,
                onChanged: (s) async {
                  await setRestTimerSeconds(s);
                  if (mounted) setState(() => _restSeconds = s);
                },
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36),
              child: _NaviSwitch(
                label: 'navi voice',
                comment: '// speak responses',
                value: _naviVoice,
                onChanged: (v) async {
                  await setNaviVoiceEnabled(v);
                  if (mounted) setState(() => _naviVoice = v);
                },
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36),
              child: _NaviSwitch(
                label: 'navi text',
                comment: '// show response text',
                value: _naviShowText,
                onChanged: (v) async {
                  await setNaviShowText(v);
                  if (mounted) setState(() => _naviShowText = v);
                },
              ),
            ),
            const SizedBox(height: 12),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 36),
              child: _SettingsItem(
                label: 'sign out',
                comment: '// end session',
                color: Colors.redAccent.withAlpha(200),
                onTap: () {
                  Supabase.instance.client.auth.signOut();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Rest timer setting ────────────────────────────────────────

class _RestTimerSetting extends StatelessWidget {
  const _RestTimerSetting({required this.currentSeconds, required this.onChanged});
  final int currentSeconds;
  final void Function(int) onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(border: Border.all(color: AppColors.borderSubtle)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'rest timer',
            style: TextStyle(fontSize: 13, fontFamily: 'monospace', letterSpacing: 1.5, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 2),
          const Text(
            '// between sets',
            style: TextStyle(fontSize: 10, fontFamily: 'monospace', color: AppColors.textSecondary),
          ),
          const SizedBox(height: 10),
          Row(
            children: restTimerOptions.map((s) {
              final active = s == currentSeconds;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: () => onChanged(s),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: active ? AppColors.primary.withAlpha(20) : Colors.transparent,
                      border: Border.all(
                        color: active ? AppColors.primary : AppColors.borderSubtle,
                      ),
                    ),
                    child: Text(
                      '${s}s',
                      style: TextStyle(
                        fontSize: 11,
                        fontFamily: 'monospace',
                        color: active ? AppColors.primary : AppColors.textSecondary,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

// ── Weight reminder setting ───────────────────────────────────

class _WeightReminderSetting extends StatelessWidget {
  const _WeightReminderSetting({required this.currentDays, required this.onChanged});
  final int currentDays;
  final void Function(int) onChanged;

  @override
  Widget build(BuildContext context) {
    const options = [7, 14, 30];
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(border: Border.all(color: AppColors.borderSubtle)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'weight reminder',
            style: TextStyle(fontSize: 13, fontFamily: 'monospace', letterSpacing: 1.5, color: AppColors.textPrimary),
          ),
          const SizedBox(height: 2),
          const Text(
            '// log frequency',
            style: TextStyle(fontSize: 10, fontFamily: 'monospace', color: AppColors.textSecondary),
          ),
          const SizedBox(height: 10),
          Row(
            children: options.map((d) {
              final active = d == currentDays;
              return Padding(
                padding: const EdgeInsets.only(right: 8),
                child: GestureDetector(
                  onTap: () => onChanged(d),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: active ? AppColors.primary.withAlpha(20) : Colors.transparent,
                      border: Border.all(
                        color: active ? AppColors.primary : AppColors.borderSubtle,
                      ),
                    ),
                    child: Text(
                      '${d}d',
                      style: TextStyle(
                        fontSize: 11,
                        fontFamily: 'monospace',
                        color: active ? AppColors.primary : AppColors.textSecondary,
                      ),
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}

// ── Navi switch ───────────────────────────────────────────────

class _NaviSwitch extends StatelessWidget {
  const _NaviSwitch({
    required this.label,
    required this.comment,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final String comment;
  final bool value;
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: const TextStyle(
                    fontSize: 13,
                    fontFamily: 'monospace',
                    letterSpacing: 1.5,
                    color: AppColors.textPrimary),
              ),
              const SizedBox(height: 2),
              Text(
                comment,
                style: const TextStyle(
                    fontSize: 10,
                    fontFamily: 'monospace',
                    color: AppColors.textSecondary),
              ),
            ],
          ),
          const Spacer(),
          Switch(
            value: value,
            onChanged: onChanged,
            activeThumbColor: AppColors.primary,
            inactiveThumbColor: AppColors.textSecondary,
            inactiveTrackColor: AppColors.borderSubtle,
          ),
        ],
      ),
    );
  }
}

// ── Unit toggle ───────────────────────────────────────────────

class _UnitToggle extends StatelessWidget {
  const _UnitToggle({required this.isImperial});
  final bool isImperial;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Row(
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'units',
                style: const TextStyle(
                    fontSize: 13,
                    fontFamily: 'monospace',
                    letterSpacing: 1.5,
                    color: AppColors.textPrimary),
              ),
              const SizedBox(height: 2),
              Text(
                isImperial ? '// lbs · ft · in' : '// kg · cm',
                style: const TextStyle(
                    fontSize: 10,
                    fontFamily: 'monospace',
                    color: AppColors.textSecondary),
              ),
            ],
          ),
          const Spacer(),
          Switch(
            value: isImperial,
            onChanged: (val) => saveUnitPreference(val),
            activeThumbColor: AppColors.primary,
            inactiveThumbColor: AppColors.textSecondary,
            inactiveTrackColor: AppColors.borderSubtle,
          ),
        ],
      ),
    );
  }
}

// ── Settings item ─────────────────────────────────────────────

class _SettingsItem extends StatelessWidget {
  const _SettingsItem({
    required this.label,
    required this.comment,
    required this.onTap,
    this.color,
  });

  final String label;
  final String comment;
  final VoidCallback onTap;
  final Color? color;

  @override
  Widget build(BuildContext context) {
    final textColor = color ?? AppColors.textPrimary;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.borderSubtle),
        ),
        child: Row(
          children: [
            Text(
              label,
              style: TextStyle(
                  fontSize: 13,
                  fontFamily: 'monospace',
                  letterSpacing: 1.5,
                  color: textColor),
            ),
            const Spacer(),
            Text(
              comment,
              style: const TextStyle(
                  fontSize: 10,
                  fontFamily: 'monospace',
                  color: AppColors.textSecondary),
            ),
          ],
        ),
      ),
    );
  }
}
