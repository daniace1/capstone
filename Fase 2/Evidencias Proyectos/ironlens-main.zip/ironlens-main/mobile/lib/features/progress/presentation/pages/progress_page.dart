import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/fitness/one_rep_max.dart';
import '../../../../core/fitness/rank.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/measured_fit_list.dart';
import '../../../../core/widgets/pressable.dart';
import '../../../../core/units/unit_system.dart';

class ProgressPage extends StatefulWidget {
  const ProgressPage({super.key});

  @override
  State<ProgressPage> createState() => _ProgressPageState();
}

class _ProgressPageState extends State<ProgressPage> {
  List<_TrainedMachine> _machines              = [];
  _TrainedMachine?      _bestMachine;
  double?               _bestMachinePrevBest1rm;
  bool                  _loading               = true;
  int                   _page                  = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      setState(() => _loading = false);
      return;
    }

    final rows = (await Supabase.instance.client
        .from('workout_sessions')
        .select(
            'machine_id, started_at, machines(name, muscle_group, baseline_1rm_kg), workout_sets(weight_kg, reps)')
        .eq('user_id', userId)
        .order('started_at', ascending: false)) as List;

    final Map<int, List<Map<String, dynamic>>> byMachine = {};
    for (final row in rows) {
      final sets = row['workout_sets'] as List;
      if (sets.isEmpty) continue;
      final mid = row['machine_id'] as int?;
      if (mid == null) continue;
      byMachine.putIfAbsent(mid, () => []);
      byMachine[mid]!.add(Map<String, dynamic>.from(row));
    }

    final machines = <_TrainedMachine>[];
    for (final entry in byMachine.entries) {
      final sessions = entry.value;
      final first = sessions.first; // most recent (ordered desc)
      final machine = first['machines'] as Map<String, dynamic>?;
      if (machine == null) continue;

      double? peakWeight;
      int? peakReps;
      double? best1rm;
      for (final s in sessions) {
        for (final set in s['workout_sets'] as List) {
          final w = (set['weight_kg'] as num?)?.toDouble();
          final r = set['reps'] as int?;
          if (w != null) peakWeight = peakWeight == null ? w : math.max(peakWeight, w);
          if (r != null) peakReps = peakReps == null ? r : math.max(peakReps, r);
          if (w != null && r != null) {
            final rm = epley1rm(w, r);
            best1rm = best1rm == null ? rm : math.max(best1rm, rm);
          }
        }
      }

      final baseline = (machine['baseline_1rm_kg'] as num?)?.toDouble();
      final rank = (best1rm != null && baseline != null && baseline > 0)
          ? rankFor(best1rm, baseline)
          : null;

      machines.add(_TrainedMachine(
        machineId: entry.key,
        machineName: machine['name'] as String? ?? 'Unknown',
        muscleGroup: machine['muscle_group'] as String? ?? '',
        sessionCount: sessions.length,
        lastAt: DateTime.parse(first['started_at'] as String).toLocal(),
        peakWeightKg: peakWeight,
        peakReps: peakReps,
        rank: rank,
        best1rmKg: best1rm,
        baselineKg: baseline,
      ));
    }

    machines.sort((a, b) => b.lastAt.compareTo(a.lastAt));

    // Best machine = highest score among those with a baseline
    _TrainedMachine? bestMachine;
    double? bestScore;
    for (final m in machines) {
      if (m.best1rmKg != null && m.baselineKg != null && m.baselineKg! > 0) {
        final score = m.best1rmKg! / m.baselineKg! * 100;
        if (bestScore == null || score > bestScore) {
          bestScore = score;
          bestMachine = m;
        }
      }
    }

    // Previous calendar month's best 1RM for the best machine
    double? prevBest1rm;
    if (bestMachine != null) {
      final now            = DateTime.now();
      final prevMonthStart = DateTime(now.year, now.month - 1, 1);
      final prevMonthEnd   = DateTime(now.year, now.month, 1);
      for (final s in byMachine[bestMachine.machineId] ?? []) {
        final startedAt = DateTime.parse(s['started_at'] as String).toLocal();
        if (startedAt.isBefore(prevMonthStart) || !startedAt.isBefore(prevMonthEnd)) continue;
        for (final set in s['workout_sets'] as List) {
          final w = (set['weight_kg'] as num?)?.toDouble();
          final r = set['reps'] as int?;
          if (w != null && r != null) {
            final rm = epley1rm(w, r);
            prevBest1rm = prevBest1rm == null ? rm : math.max(prevBest1rm, rm);
          }
        }
      }
    }

    if (mounted) {
      setState(() {
        _machines               = machines;
        _bestMachine            = bestMachine;
        _bestMachinePrevBest1rm = prevBest1rm;
        _loading                = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(onBack: () => context.go(AppRoutes.home)),
            Expanded(
              child: _loading
                  ? const Center(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 1.5,
                            color: AppColors.textSecondary),
                      ),
                    )
                  : _machines.isEmpty
                      ? RefreshIndicator(
                          onRefresh: _load,
                          color: AppColors.primary,
                          backgroundColor: AppColors.surface,
                          child: _EmptyState(),
                        )
                      : MeasuredFitList<_TrainedMachine>(
                          fixedTop: Column(
                            children: [
                              _MonthlyCard(
                                onTap: () =>
                                    context.push(AppRoutes.monthlyAnalysis),
                              ),
                              if (_bestMachine != null)
                                _BestMachineCard(
                                  machine: _bestMachine!,
                                  prevBest1rm: _bestMachinePrevBest1rm,
                                ),
                              _SectionHeader('// trained machines',
                                  count: _machines.length),
                            ],
                          ),
                          items: _machines,
                          itemBuilder: (context, m) => _MachineRow(
                            machine: m,
                            onTap: () => context.push(
                              AppRoutes.machineProgress,
                              extra: {
                                'machineId': m.machineId,
                                'machineName': m.machineName,
                                'muscleGroup': m.muscleGroup,
                                'best1rmKg': m.best1rmKg,
                                'baselineKg': m.baselineKg,
                              },
                            ),
                          ),
                          page: _page,
                          onPageChanged: (p) => setState(() => _page = p),
                          onRefresh: _load,
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Best machine card ─────────────────────────────────────────

class _BestMachineCard extends StatelessWidget {
  const _BestMachineCard({required this.machine, this.prevBest1rm});
  final _TrainedMachine machine;
  final double?         prevBest1rm;

  @override
  Widget build(BuildContext context) {
    final rank      = machine.rank;
    final rankColor = rank?.color ?? AppColors.textSecondary;
    final best1rm   = machine.best1rmKg!;

    String? deltaLabel;
    Color?  deltaColor;
    if (prevBest1rm != null) {
      final delta = best1rm - prevBest1rm!;
      if (delta.abs() > 0.05) {
        deltaLabel = delta > 0
            ? '↑ +${Units.formatWeight(context, delta.abs())}'
            : '↓ ${Units.formatWeight(context, delta.abs())}';
        deltaColor = delta > 0 ? AppColors.green : AppColors.red;
      }
    }

    return Container(
      margin: const EdgeInsets.fromLTRB(16, 4, 16, 4),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border.all(color: rankColor.withAlpha(80)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '// best machine',
            style: const TextStyle(
                fontSize: 10,
                color: AppColors.textSecondary,
                fontFamily: 'monospace',
                letterSpacing: 1),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              if (rank != null)
                Image.asset(
                  'assets/ranks/${rank.label}.webp',
                  width: 56,
                  height: 56,
                  errorBuilder: (_, _, _) => const SizedBox(width: 56, height: 56),
                ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      machine.machineName,
                      style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.textPrimary),
                    ),
                    const SizedBox(height: 4),
                    if (rank != null)
                      Text(
                        rank.label,
                        style: TextStyle(
                            fontSize: 11,
                            color: rankColor,
                            fontFamily: 'monospace',
                            letterSpacing: 1),
                      ),
                    if (deltaLabel != null) ...[
                      const SizedBox(height: 2),
                      Text(
                        deltaLabel,
                        style: TextStyle(
                            fontSize: 11,
                            color: deltaColor,
                            fontFamily: 'monospace',
                            letterSpacing: 0.5),
                      ),
                    ],
                    const SizedBox(height: 2),
                    Text(
                      'best 1RM: ${Units.formatWeight(context, best1rm)}',
                      style: const TextStyle(
                          fontSize: 10,
                          color: AppColors.textSecondary,
                          fontFamily: 'monospace'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({required this.onBack});
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      child: Row(
        children: [
          Pressable(
            onTap: onBack,
            child: const Text('← back',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace')),
          ),
          const Spacer(),
          const Text('progress',
              style: TextStyle(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ── Monthly analysis card ─────────────────────────────────────

class _MonthlyCard extends StatelessWidget {
  const _MonthlyCard({required this.onTap});
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final now   = DateTime.now();
    final label = '${now.year}-${now.month.toString().padLeft(2, '0')}';
    return Pressable(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.borderSubtle),
        ),
        child: Row(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '// $label',
                  style: const TextStyle(
                      fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 1),
                ),
                const SizedBox(height: 3),
                const Text(
                  'monthly report',
                  style: TextStyle(
                      fontSize: 13, color: AppColors.textPrimary, fontFamily: 'monospace', fontWeight: FontWeight.w500),
                ),
              ],
            ),
            const Spacer(),
            const Text('[ generate ]',
                style: TextStyle(fontSize: 10, color: AppColors.primary, fontFamily: 'monospace', letterSpacing: 0.5)),
          ],
        ),
      ),
    );
  }
}

// ── Section header ────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.label, {required this.count});
  final String label;
  final int count;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
      child: Row(
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 10,
                  color: AppColors.textSecondary,
                  fontFamily: 'monospace',
                  letterSpacing: 1)),
          const SizedBox(width: 8),
          Text('[$count]',
              style: TextStyle(
                  fontSize: 10,
                  color: AppColors.textSecondary.withAlpha(160),
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ── Machine row ───────────────────────────────────────────────

class _MachineRow extends StatelessWidget {
  const _MachineRow({required this.machine, required this.onTap});
  final _TrainedMachine machine;
  final VoidCallback onTap;

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) return 'today';
    if (diff.inDays == 1) return 'yesterday';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final peak = machine.peakWeightKg != null
        ? '↑ ${Units.formatWeight(context, machine.peakWeightKg)}'
        : machine.peakReps != null
            ? '↑ ${machine.peakReps} reps'
            : null;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
        decoration: const BoxDecoration(
          border: Border(
            bottom: BorderSide(color: AppColors.borderSubtle, width: 0.5),
          ),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    machine.machineName,
                    style: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w500,
                        color: AppColors.textPrimary),
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      _Tag(machine.muscleGroup),
                      const SizedBox(width: 10),
                      Text(
                        '${machine.sessionCount} sessions  ·  ${_formatDate(machine.lastAt)}',
                        style: const TextStyle(
                            fontSize: 10,
                            color: AppColors.textSecondary,
                            fontFamily: 'monospace'),
                      ),
                    ],
                  ),
                  if (peak != null) ...[
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        _StatChip(peak),
                        if (machine.rank != null) ...[
                          const SizedBox(width: 6),
                          _RankChip(machine.rank!),
                        ],
                      ],
                    ),
                  ],
                ],
              ),
            ),
            const Text('→',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace')),
          ],
        ),
      ),
    );
  }
}

// ── Stat chip ─────────────────────────────────────────────────

class _StatChip extends StatelessWidget {
  const _StatChip(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.teal.withAlpha(20),
        border: Border.all(color: AppColors.teal.withAlpha(80)),
      ),
      child: Text(
        label,
        style: const TextStyle(
            fontSize: 9,
            color: AppColors.teal,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Rank chip ─────────────────────────────────────────────────

class _RankChip extends StatelessWidget {
  const _RankChip(this.rank);
  final Rank rank;

  @override
  Widget build(BuildContext context) {
    final color = rank.color;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withAlpha(20),
        border: Border.all(color: color.withAlpha(100)),
      ),
      child: Text(
        rank.label,
        style: TextStyle(
            fontSize: 9,
            color: color,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Tag ───────────────────────────────────────────────────────

class _Tag extends StatelessWidget {
  const _Tag(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Text(
        label.toLowerCase(),
        style: const TextStyle(
            fontSize: 9,
            color: AppColors.primary,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        SizedBox(height: 120),
        Center(
          child: Text(
            '// no training data yet\n// complete a workout to see progress',
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
                fontFamily: 'monospace',
                height: 1.8),
          ),
        ),
      ],
    );
  }
}

// ── Data class ────────────────────────────────────────────────

class _TrainedMachine {
  const _TrainedMachine({
    required this.machineId,
    required this.machineName,
    required this.muscleGroup,
    required this.sessionCount,
    required this.lastAt,
    this.peakWeightKg,
    this.peakReps,
    this.rank,  // power rank tier
    this.best1rmKg,
    this.baselineKg,
  });

  final int machineId;
  final String machineName;
  final String muscleGroup;
  final int sessionCount;
  final DateTime lastAt;
  final double? peakWeightKg;
  final int? peakReps;
  final Rank? rank;
  final double? best1rmKg;
  final double? baselineKg;
}
