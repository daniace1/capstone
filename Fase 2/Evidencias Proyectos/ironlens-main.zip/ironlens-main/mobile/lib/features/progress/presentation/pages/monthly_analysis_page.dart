import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/network/api_client.dart';
import 'package:fl_chart/fl_chart.dart';

import '../../../../core/fitness/bmi.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/ai_thinking.dart';
import '../../../../core/widgets/confirm_dialog.dart';
import '../../../../core/widgets/pressable.dart';

// ── Epley 1RM ────────────────────────────────────────────────
double _epley(double weight, int reps) => weight * (1 + reps / 30);

String? _rankLabel(double best1rm, double baseline) {
  final score = best1rm / baseline * 100;
  if (score < 80)  return 'bronze';
  if (score < 100) return 'silver';
  if (score < 130) return 'gold';
  if (score < 170) return 'platinum';
  if (score < 220) return 'diamond';
  return 'master';
}

class MonthlyAnalysisPage extends StatefulWidget {
  const MonthlyAnalysisPage({super.key});

  @override
  State<MonthlyAnalysisPage> createState() => _MonthlyAnalysisPageState();
}

class _MonthlyAnalysisPageState extends State<MonthlyAnalysisPage> {
  Map<String, dynamic>? _data;
  String? _error;
  bool    _loading = true;     // reading the local cache (plain spinner)
  bool    _generating = false; // calling the AI (thinking animation)
  String  _monthKey = '';

  List<Map<String, dynamic>> _weightLogsYear = [];
  double? _heightCm;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _loadChartData() async {
    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;
    if (userId == null) return;

    final yearAgo = DateTime.now().subtract(const Duration(days: 365));

    final weightRows = await supabase
        .from('weight_logs')
        .select('weight_kg, logged_at')
        .eq('user_id', userId)
        .gte('logged_at', yearAgo.toIso8601String())
        .order('logged_at', ascending: true) as List;

    final profileRow = await supabase
        .from('profiles')
        .select('height_cm')
        .eq('id', userId)
        .maybeSingle();

    if (mounted) {
      setState(() {
        _weightLogsYear = weightRows.map((w) => {
          'weight_kg': (w['weight_kg'] as num).toDouble(),
          'logged_at': (w['logged_at'] as String).substring(0, 10),
        }).toList();
        _heightCm = (profileRow?['height_cm'] as num?)?.toDouble();
      });
    }
  }

  Future<void> _load() async {
    final now = DateTime.now();
    _monthKey = '${now.year}-${now.month.toString().padLeft(2, '0')}';

    await _loadChartData();

    final prefs  = await SharedPreferences.getInstance();
    final cached = prefs.getString('monthly_analysis_$_monthKey');
    if (cached != null) {
      try {
        final parsed = jsonDecode(cached) as Map<String, dynamic>;
        if (mounted) setState(() { _data = parsed; _loading = false; });
        return;
      } catch (_) {
        await prefs.remove('monthly_analysis_$_monthKey');
      }
    }
    await _generate();
  }

  Future<void> _regen() async {
    final ok = await showConfirmDialog(
      context,
      title: 'regenerate report',
      message: 'this will replace the current monthly analysis',
    );
    if (!ok) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('monthly_analysis_$_monthKey');
    await _generate();
  }

  Future<void> _generate() async {
    if (mounted) setState(() { _generating = true; _error = null; });

    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;
    if (userId == null) { if (mounted) setState(() => _loading = false); return; }

    try {
      final now        = DateTime.now();
      final monthStart = DateTime(now.year, now.month, 1);
      final monthEnd   = DateTime(now.year, now.month + 1, 1);

      // ── 1. Sessions this month (completed) ──────────────────
      final sessionRows = await supabase
          .from('workout_sessions')
          .select('started_at, machine_id, machines(name), workout_sets(reps, weight_kg)')
          .eq('user_id', userId)
          .gte('started_at', monthStart.toIso8601String())
          .lt('started_at', monthEnd.toIso8601String())
          .not('ended_at', 'is', null) as List;

      final Map<int, int> sessionsPerMachine = {};
      final sessions = <Map<String, dynamic>>[];
      for (final s in sessionRows) {
        final sets = s['workout_sets'] as List;
        if (sets.isEmpty) continue;
        final mid = s['machine_id'] as int?;
        if (mid != null) sessionsPerMachine[mid] = (sessionsPerMachine[mid] ?? 0) + 1;
        double? maxW;
        int?    maxR;
        for (final set in sets) {
          final w = (set['weight_kg'] as num?)?.toDouble();
          final r = set['reps'] as int?;
          if (w != null) maxW = maxW == null ? w : math.max(maxW, w);
          if (r != null) maxR = maxR == null ? r : math.max(maxR, r);
        }
        sessions.add({
          'date':          (s['started_at'] as String).substring(0, 10),
          'machine_name':  (s['machines'] as Map<String, dynamic>?)?['name'] ?? 'Unknown',
          'sets_count':    sets.length,
          'max_weight_kg': maxW,
          'max_reps':      maxR,
        });
      }

      // ── 2. All-time sessions for rank calculation ────────────
      final allRows = await supabase
          .from('workout_sessions')
          .select('machine_id, workout_sets(reps, weight_kg)')
          .eq('user_id', userId) as List;

      final Map<int, double> best1rmPerMachine = {};
      for (final s in allRows) {
        final mid  = s['machine_id'] as int?;
        if (mid == null) continue;
        for (final set in s['workout_sets'] as List) {
          final w = (set['weight_kg'] as num?)?.toDouble();
          final r = set['reps'] as int?;
          if (w != null && r != null) {
            final rm = _epley(w, r);
            best1rmPerMachine[mid] = math.max(best1rmPerMachine[mid] ?? 0, rm);
          }
        }
      }

      // ── 3. Scanned machines with baseline ───────────────────
      final scannedRows = await supabase
          .from('scanned_machines')
          .select('machine_id, machines(id, name, muscle_group, baseline_1rm_kg)')
          .eq('user_id', userId) as List;

      final machineRanks = <Map<String, dynamic>>[];
      for (final row in scannedRows) {
        final m        = row['machines'] as Map<String, dynamic>?;
        if (m == null) continue;
        final mid      = m['id'] as int;
        final baseline = (m['baseline_1rm_kg'] as num?)?.toDouble();
        final best1rm  = best1rmPerMachine[mid];
        String? rank;
        if (best1rm != null && baseline != null && baseline > 0) {
          rank = _rankLabel(best1rm, baseline);
        }
        machineRanks.add({
          'machine_id':           mid,
          'machine_name':         m['name'] as String,
          'muscle_group':         m['muscle_group'] as String,
          'rank':                 rank,
          'sessions_this_month':  sessionsPerMachine[mid] ?? 0,
        });
      }

      // ── 4. Routine completion ────────────────────────────────
      final routineLogs = await supabase
          .from('routine_logs')
          .select('ended_at')
          .eq('user_id', userId)
          .gte('started_at', monthStart.toIso8601String())
          .lt('started_at', monthEnd.toIso8601String()) as List;

      Map<String, dynamic>? routineCompletion;
      if (routineLogs.isNotEmpty) {
        routineCompletion = {
          'days_attempted': routineLogs.length,
          'days_completed': routineLogs.where((l) => l['ended_at'] != null).length,
        };
      }

      // ── 5. Weight logs this month ────────────────────────────
      final weightRows = await supabase
          .from('weight_logs')
          .select('weight_kg, logged_at')
          .eq('user_id', userId)
          .gte('logged_at', monthStart.toIso8601String())
          .lt('logged_at', monthEnd.toIso8601String())
          .order('logged_at', ascending: true) as List;

      final weightLogs = weightRows.map((w) => {
            'weight_kg': (w['weight_kg'] as num).toDouble(),
            'logged_at': (w['logged_at'] as String).substring(0, 10),
          }).toList();

      // ── 6. Profile ───────────────────────────────────────────
      final profile = await supabase
          .from('profiles')
          .select('goal, weight_kg')
          .eq('id', userId)
          .maybeSingle();

      // ── 7. Call API ──────────────────────────────────────────
      final body = {
        'month_start':        monthStart.toIso8601String().substring(0, 10),
        'sessions':           sessions,
        'routine_completion': routineCompletion,
        'weight_logs':        weightLogs,
        'profile': {
          'goal':      profile?['goal'],
          'weight_kg': profile?['weight_kg'],
        },
        'machine_ranks': machineRanks,
      };

      final result = await ApiClient.post('/monthly-analysis', body);

      // Validate weakness machine_ids exist in our scanned list
      final validIds = machineRanks.map((m) => m['machine_id'] as int).toSet();
      final rawWeaknesses = (result['weakness_machines'] as List? ?? [])
          .cast<Map<String, dynamic>>()
          .where((m) => validIds.contains(m['machine_id']))
          .toList();
      result['weakness_machines'] = rawWeaknesses;

      // Enrich weakness machines with muscle_group from scanned list (safety)
      for (final wm in result['weakness_machines'] as List) {
        final match = machineRanks.firstWhere(
          (m) => m['machine_id'] == wm['machine_id'],
          orElse: () => {},
        );
        if (match.isNotEmpty) wm['muscle_group'] = match['muscle_group'];
      }

      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('monthly_analysis_$_monthKey', jsonEncode(result));

      if (mounted) setState(() { _data = result; _generating = false; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = e.toString(); _generating = false; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(monthKey: _monthKey, onBack: () => context.pop(), onRegen: _data != null ? _regen : null),
            Expanded(
              child: _generating
                  ? const AiThinking(messages: [
                      'reading this month',
                      'crunching your sessions',
                      'checking your ranks',
                      'spotting weak points',
                      'writing your analysis',
                    ])
                  : _loading
                      ? const Center(
                          child: SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                                strokeWidth: 1.5,
                                color: AppColors.textSecondary),
                          ),
                        )
                      : _error != null
                          ? _ErrorState(onRetry: _generate)
                      : _AnalysisBody(
                          data: _data!,
                          weightLogsYear: _weightLogsYear,
                          heightCm: _heightCm,
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({required this.monthKey, required this.onBack, this.onRegen});
  final String monthKey;
  final VoidCallback onBack;
  final VoidCallback? onRegen;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      child: Row(
        children: [
          Pressable(
            onTap: onBack,
            child: const Text('← back',
                style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace')),
          ),
          const Spacer(),
          if (onRegen != null)
            GestureDetector(
              onTap: onRegen,
              child: const Text('[ regen ]',
                  style: TextStyle(fontSize: 10, color: AppColors.primary, fontFamily: 'monospace', letterSpacing: 1)),
            ),
          if (monthKey.isNotEmpty) ...[
            const SizedBox(width: 12),
            Text('// $monthKey',
                style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace')),
          ],
        ],
      ),
    );
  }
}

// ── Analysis body ─────────────────────────────────────────────

class _AnalysisBody extends StatelessWidget {
  const _AnalysisBody({
    required this.data,
    required this.weightLogsYear,
    required this.heightCm,
  });
  final Map<String, dynamic> data;
  final List<Map<String, dynamic>> weightLogsYear;
  final double? heightCm;

  @override
  Widget build(BuildContext context) {
    final summary        = data['summary'] as String? ?? '';
    final insights       = (data['insights'] as List? ?? []).cast<Map<String, dynamic>>();
    final weaknesses     = (data['weakness_machines'] as List? ?? []).cast<Map<String, dynamic>>();
    final recommendation = data['recommendation'] as String? ?? '';

    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 40),
      children: [
        const Text('// monthly report',
            style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 1.5)),
        const SizedBox(height: 16),

        // Summary
        Text(summary,
            style: const TextStyle(
                fontSize: 13, color: AppColors.textPrimary, fontFamily: 'monospace', height: 1.65)),
        const SizedBox(height: 20),

        // BMI chart
        if (heightCm != null && weightLogsYear.length >= 2) ...[
          _BmiChart(weightLogs: weightLogsYear, heightCm: heightCm!),
          const SizedBox(height: 24),
        ] else ...[
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10),
            child: const Text(
              '// not enough weight data for bmi chart',
              style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace'),
            ),
          ),
          const SizedBox(height: 16),
        ],

        // Insight chips
        if (insights.isNotEmpty) ...[
          Column(
            children: insights.map((i) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: _InsightChip(
                label: i['label'] as String? ?? '',
                value: i['value'] as String? ?? '',
              ),
            )).toList(),
          ),
          const SizedBox(height: 24),
        ],

        // Weaknesses
        if (weaknesses.isNotEmpty) ...[
          const Text('// weaknesses',
              style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 1.5)),
          const SizedBox(height: 10),
          ...weaknesses.map((m) => Padding(
                padding: const EdgeInsets.only(bottom: 10),
                child: _WeaknessMachineCard(machine: m),
              )),
          const SizedBox(height: 14),
        ],

        // Recommendation
        if (recommendation.isNotEmpty) ...[
          const Text('// recommendation',
              style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 1.5)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.primary.withAlpha(12),
              border: Border.all(color: AppColors.primary.withAlpha(60)),
            ),
            child: Text(recommendation,
                style: const TextStyle(
                    fontSize: 12, color: AppColors.textPrimary, fontFamily: 'monospace', height: 1.6)),
          ),
        ],
      ],
    );
  }
}

// ── BMI chart ─────────────────────────────────────────────────

class _BmiChart extends StatelessWidget {
  const _BmiChart({required this.weightLogs, required this.heightCm});
  final List<Map<String, dynamic>> weightLogs;
  final double heightCm;

  static const _underweight = 18.5;
  static const _overweight  = 25.0;
  static const _obese       = 30.0;

  @override
  Widget build(BuildContext context) {
    final first = DateTime.parse(weightLogs.first['logged_at'] as String);

    final spots = weightLogs.map((w) {
      final date  = DateTime.parse(w['logged_at'] as String);
      final x     = date.difference(first).inDays.toDouble();
      final value = bmi(w['weight_kg'] as double, heightCm);
      return FlSpot(x, double.parse(value.toStringAsFixed(1)));
    }).toList();

    final bmiValues = spots.map((s) => s.y).toList();
    final minY = (bmiValues.reduce(math.min) - 2).floorToDouble().clamp(10.0, 17.0);
    final maxY = (bmiValues.reduce(math.max) + 2).ceilToDouble().clamp(22.0, 40.0);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          '// bmi  ·  last 12 months',
          style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 0.5),
        ),
        const SizedBox(height: 12),
        AspectRatio(
          aspectRatio: 2.2,
          child: LineChart(
            LineChartData(
              minY: minY,
              maxY: maxY,
              clipData: const FlClipData.all(),
              gridData: FlGridData(
                show: true,
                drawVerticalLine: false,
                horizontalInterval: 5,
                getDrawingHorizontalLine: (_) => const FlLine(
                  color: Color(0x28313244),
                  strokeWidth: 0.5,
                ),
              ),
              borderData: FlBorderData(
                show: true,
                border: const Border(
                  bottom: BorderSide(color: Color(0x50313244), width: 0.5),
                  left:   BorderSide(color: Color(0x50313244), width: 0.5),
                ),
              ),
              extraLinesData: ExtraLinesData(horizontalLines: [
                HorizontalLine(
                  y: _underweight,
                  color: AppColors.teal.withAlpha(120),
                  strokeWidth: 0.8,
                  dashArray: [4, 4],
                  label: HorizontalLineLabel(
                    show: true,
                    alignment: Alignment.topRight,
                    labelResolver: (_) => 'underweight',
                    style: const TextStyle(fontSize: 8, color: AppColors.teal, fontFamily: 'monospace'),
                  ),
                ),
                HorizontalLine(
                  y: _overweight,
                  color: AppColors.yellow.withAlpha(120),
                  strokeWidth: 0.8,
                  dashArray: [4, 4],
                  label: HorizontalLineLabel(
                    show: true,
                    alignment: Alignment.topRight,
                    labelResolver: (_) => 'overweight',
                    style: const TextStyle(fontSize: 8, color: AppColors.yellow, fontFamily: 'monospace'),
                  ),
                ),
                HorizontalLine(
                  y: _obese,
                  color: AppColors.red.withAlpha(120),
                  strokeWidth: 0.8,
                  dashArray: [4, 4],
                  label: HorizontalLineLabel(
                    show: true,
                    alignment: Alignment.topRight,
                    labelResolver: (_) => 'obese',
                    style: const TextStyle(fontSize: 8, color: AppColors.red, fontFamily: 'monospace'),
                  ),
                ),
              ]),
              titlesData: FlTitlesData(
                rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                topTitles:   const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                leftTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 36,
                    interval: 5,
                    getTitlesWidget: (v, _) {
                      if (v <= minY || v >= maxY) return const SizedBox.shrink();
                      return Text(
                        v.toInt().toString(),
                        style: const TextStyle(fontSize: 9, color: AppColors.textSecondary, fontFamily: 'monospace'),
                      );
                    },
                  ),
                ),
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    reservedSize: 24,
                    getTitlesWidget: (v, meta) {
                      final date = first.add(Duration(days: v.round()));
                      if (v != meta.min && v != meta.max) {
                        final isFirst = v == spots.first.x;
                        final isLast  = v == spots.last.x;
                        if (!isFirst && !isLast) return const SizedBox.shrink();
                      }
                      final label = '${date.month.toString().padLeft(2,'0')}/${date.year.toString().substring(2)}';
                      return Padding(
                        padding: const EdgeInsets.only(top: 6),
                        child: Text(label, style: const TextStyle(fontSize: 8, color: AppColors.textSecondary, fontFamily: 'monospace')),
                      );
                    },
                  ),
                ),
              ),
              lineBarsData: [
                LineChartBarData(
                  spots: spots,
                  color: AppColors.teal,
                  barWidth: 1.5,
                  isCurved: spots.length > 2,
                  preventCurveOverShooting: true,
                  curveSmoothness: 0.2,
                  dotData: FlDotData(
                    show: true,
                    getDotPainter: (_, _, _, _) => FlDotCirclePainter(
                      radius: 3,
                      color: AppColors.teal,
                      strokeWidth: 0,
                      strokeColor: Colors.transparent,
                    ),
                  ),
                  belowBarData: BarAreaData(show: true, color: AppColors.teal.withAlpha(15)),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

// ── Insight chip ──────────────────────────────────────────────

class _InsightChip extends StatelessWidget {
  const _InsightChip({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(
                  fontSize: 9, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 1)),
          const SizedBox(height: 3),
          Text(value,
              style: const TextStyle(
                  fontSize: 12, color: AppColors.textPrimary, fontFamily: 'monospace', fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

// ── Weakness machine card ─────────────────────────────────────

class _WeaknessMachineCard extends StatelessWidget {
  const _WeaknessMachineCard({required this.machine});
  final Map<String, dynamic> machine;

  @override
  Widget build(BuildContext context) {
    final machineId   = machine['machine_id'] as int;
    final machineName = machine['machine_name'] as String? ?? 'Unknown';
    final muscleGroup = machine['muscle_group'] as String? ?? '';
    final reason      = machine['reason'] as String? ?? '';

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 12, 12, 12),
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(machineName,
                    style: const TextStyle(
                        fontSize: 13, color: AppColors.textPrimary, fontFamily: 'monospace', fontWeight: FontWeight.w500)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _MiniTag(muscleGroup),
                  ],
                ),
                const SizedBox(height: 5),
                Text(reason,
                    style: const TextStyle(
                        fontSize: 11, color: AppColors.textSecondary, fontFamily: 'monospace', height: 1.4)),
              ],
            ),
          ),
          const SizedBox(width: 10),
          GestureDetector(
            onTap: () => context.push(AppRoutes.workout, extra: {
              'machineId':   machineId,
              'machineName': machineName,
              'muscleGroup': muscleGroup,
              'sessionId':   null,
            }),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.primary.withAlpha(120)),
              ),
              child: const Text('start →',
                  style: TextStyle(
                      fontSize: 10, color: AppColors.primary, fontFamily: 'monospace', letterSpacing: 0.5)),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Mini tag ──────────────────────────────────────────────────

class _MiniTag extends StatelessWidget {
  const _MiniTag(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Text(label.toLowerCase(),
          style: const TextStyle(
              fontSize: 9, color: AppColors.primary, fontFamily: 'monospace', letterSpacing: 0.5)),
    );
  }
}

// ── Error state ───────────────────────────────────────────────

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.onRetry});
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text('// analysis failed',
              style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace')),
          const SizedBox(height: 16),
          GestureDetector(
            onTap: onRetry,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              decoration: BoxDecoration(border: Border.all(color: AppColors.borderSubtle)),
              child: const Text('[ retry ]',
                  style: TextStyle(
                      fontSize: 11, color: AppColors.primary, fontFamily: 'monospace', letterSpacing: 1)),
            ),
          ),
        ],
      ),
    );
  }
}
