import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/fitness/rank.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/pressable.dart';
import '../../../../core/units/unit_system.dart';
import '../../../navi/presentation/navi_scope.dart';

class MachineProgressPage extends StatefulWidget {
  const MachineProgressPage({
    required this.machineId,
    required this.machineName,
    required this.muscleGroup,
    this.best1rmKg,
    this.baselineKg,
    super.key,
  });

  final int machineId;
  final String machineName;
  final String muscleGroup;
  final double? best1rmKg;
  final double? baselineKg;

  @override
  State<MachineProgressPage> createState() => _MachineProgressPageState();
}

class _MachineProgressPageState extends State<MachineProgressPage> {
  List<FlSpot> _spots = [];
  Map<int, DateTime> _indexToDate = {};
  bool _hasWeight = false;
  double _peak = 0;
  int _totalSessions = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      setState(() => _loading = false);
      return;
    }

    final now = DateTime.now();
    final thirtyDaysAgo = now.subtract(const Duration(days: 30));
    final refDay = DateTime(thirtyDaysAgo.year, thirtyDaysAgo.month, thirtyDaysAgo.day);

    final rows = (await Supabase.instance.client
        .from('workout_sessions')
        .select('started_at, workout_sets(weight_kg, reps)')
        .eq('user_id', userId)
        .eq('machine_id', widget.machineId)
        .gte('started_at', thirtyDaysAgo.toIso8601String())
        .order('started_at', ascending: true)) as List;

    final Map<int, List<Map<String, dynamic>>> dayBuckets = {};
    int validSessionCount = 0;

    for (final row in rows) {
      final sets = row['workout_sets'] as List;
      if (sets.isEmpty) continue;
      validSessionCount++;

      final date = DateTime.parse(row['started_at'] as String).toLocal();
      final dayDate = DateTime(date.year, date.month, date.day);
      final dayIndex = dayDate.difference(refDay).inDays;
      if (dayIndex < 0) continue;

      dayBuckets.putIfAbsent(dayIndex, () => []);
      for (final set in sets) {
        dayBuckets[dayIndex]!.add(Map<String, dynamic>.from(set));
      }
    }

    final allSets = dayBuckets.values.expand((x) => x).toList();
    final hasWeight = allSets.any((s) => s['weight_kg'] != null);

    final spots = <FlSpot>[];
    final indexToDate = <int, DateTime>{};
    double peak = 0;

    for (final entry in (dayBuckets.entries.toList()
      ..sort((a, b) => a.key.compareTo(b.key)))) {
      final idx = entry.key;
      final sets = entry.value;
      double? value;

      if (hasWeight) {
        final weighted = sets.where((s) => s['weight_kg'] != null).toList();
        if (weighted.isEmpty) continue;
        value = weighted
            .map((s) => (s['weight_kg'] as num).toDouble())
            .reduce(math.max);
      } else {
        final repsList = sets.where((s) => s['reps'] != null).toList();
        if (repsList.isEmpty) continue;
        value = repsList
            .map((s) => (s['reps'] as int).toDouble())
            .reduce((a, b) => a > b ? a : b);
      }

      if (value > peak) peak = value;
      spots.add(FlSpot(idx.toDouble(), value));
      indexToDate[idx] = refDay.add(Duration(days: idx));
    }

    if (mounted) {
      setState(() {
        _spots = spots;
        _indexToDate = indexToDate;
        _hasWeight = hasWeight;
        _peak = peak;
        _totalSessions = validSessionCount;
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return NaviScope(
      activeMachineId: widget.machineId,
      child: Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(
              machineName: widget.machineName,
              muscleGroup: widget.muscleGroup,
              onBack: () {
                if (context.canPop()) {
                  context.pop();
                } else {
                  context.go(AppRoutes.progress);
                }
              },
            ),
            Expanded(
              child: _loading
                  ? const Center(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 1.5,
                            color: AppColors.textSecondary),
                      ),
                    )
                  : _spots.isEmpty
                      ? const _EmptyState()
                      : ListView(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          children: [
                            const SizedBox(height: 8),
                            if (widget.best1rmKg != null && widget.baselineKg != null) ...[
                              _RankHeader(
                                best1rmKg:  widget.best1rmKg!,
                                baselineKg: widget.baselineKg!,
                              ),
                              const SizedBox(height: 20),
                            ],
                            _ChartHeader(
                              hasWeight: _hasWeight,
                              peak: _peak,
                              totalSessions: _totalSessions,
                              lastDate: _indexToDate.isNotEmpty
                                  ? _indexToDate.values.last
                                  : null,
                            ),
                            const SizedBox(height: 24),
                            _spots.length >= 2
                                ? _ProgressChart(
                                    spots: _spots,
                                    indexToDate: _indexToDate,
                                    hasWeight: _hasWeight,
                                    peak: _peak,
                                  )
                                : const _ChartPlaceholder(),
                            const SizedBox(height: 24),
                            _RecommendationSection(
                              machineId:   widget.machineId,
                              machineName: widget.machineName,
                              muscleGroup: widget.muscleGroup,
                            ),
                            const SizedBox(height: 32),
                          ],
                        ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.machineName,
    required this.muscleGroup,
    required this.onBack,
  });

  final String machineName;
  final String muscleGroup;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Pressable(
                onTap: onBack,
                child: const Text('← back',
                    style: TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                        fontFamily: 'monospace')),
              ),
              const Spacer(),
              const Text('machine progress',
                  style: TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                      fontFamily: 'monospace')),
            ],
          ),
          const SizedBox(height: 16),
          Text(
            machineName.toUpperCase(),
            style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w600,
              color: AppColors.textPrimary,
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 4),
          _Tag(muscleGroup),
        ],
      ),
    );
  }
}

// ── Chart header (stats) ──────────────────────────────────────

class _ChartHeader extends StatelessWidget {
  const _ChartHeader({
    required this.hasWeight,
    required this.peak,
    required this.totalSessions,
    required this.lastDate,
  });

  final bool hasWeight;
  final double peak;
  final int totalSessions;
  final DateTime? lastDate;

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) return 'today';
    if (diff.inDays == 1) return 'yesterday';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final peakLabel = hasWeight
        ? '${Units.formatWeightValue(context, peak)} ${Units.weightUnit(context)}'
        : '${peak.toInt()} reps';

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          hasWeight
              ? '// max weight  ·  last 30 days'
              : '// max reps  ·  last 30 days',
          style: const TextStyle(
              fontSize: 10,
              color: AppColors.textSecondary,
              fontFamily: 'monospace',
              letterSpacing: 0.5),
        ),
        const SizedBox(height: 14),
        Row(
          children: [
            _StatBlock(label: 'sessions', value: '$totalSessions'),
            const SizedBox(width: 28),
            _StatBlock(label: 'peak', value: peakLabel),
            if (lastDate != null) ...[
              const SizedBox(width: 28),
              _StatBlock(label: 'last', value: _formatDate(lastDate!)),
            ],
          ],
        ),
      ],
    );
  }
}

class _StatBlock extends StatelessWidget {
  const _StatBlock({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
              fontSize: 9,
              color: AppColors.textSecondary,
              fontFamily: 'monospace',
              letterSpacing: 0.5),
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.w500,
              color: AppColors.textPrimary,
              fontFamily: 'monospace'),
        ),
      ],
    );
  }
}

// ── Progress chart ────────────────────────────────────────────

class _ProgressChart extends StatelessWidget {
  const _ProgressChart({
    required this.spots,
    required this.indexToDate,
    required this.hasWeight,
    required this.peak,
  });

  final List<FlSpot> spots;
  final Map<int, DateTime> indexToDate;
  final bool hasWeight;
  final double peak;

  String _dayLabel(int idx) {
    final dt = indexToDate[idx];
    if (dt == null) return '';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    final minVal = spots.map((s) => s.y).reduce(math.min);
    final rawMinY = (minVal * 0.85).floorToDouble();
    final rawMaxY = (peak * 1.12).ceilToDouble();
    final minY = rawMinY < rawMaxY ? rawMinY : (rawMaxY - 10).floorToDouble();
    final maxY = rawMaxY;
    final range = maxY - minY;
    final yInterval = (range / 4).ceilToDouble().clamp(1.0, double.infinity);

    return AspectRatio(
      aspectRatio: 1.6,
      child: LineChart(
        LineChartData(
          minY: minY,
          maxY: maxY,
          clipData: const FlClipData.all(),
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            horizontalInterval: yInterval,
            getDrawingHorizontalLine: (_) => const FlLine(
              color: Color(0x28313244),
              strokeWidth: 0.5,
            ),
          ),
          borderData: FlBorderData(
            show: true,
            border: const Border(
              bottom: BorderSide(color: Color(0x50313244), width: 0.5),
              left: BorderSide(color: Color(0x50313244), width: 0.5),
            ),
          ),
          titlesData: FlTitlesData(
            rightTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false)),
            topTitles: const AxisTitles(
                sideTitles: SideTitles(showTitles: false)),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 44,
                interval: yInterval,
                getTitlesWidget: (v, meta) {
                  if (v <= minY || v >= maxY) return const SizedBox.shrink();
                  String label;
                  if (hasWeight) {
                    final display = UnitSystemScope.of(context).isImperial
                        ? Units.kgToLbs(v)
                        : v;
                    label = display % 1 == 0
                        ? display.toInt().toString()
                        : display.toStringAsFixed(1);
                  } else {
                    label = v.toInt().toString();
                  }
                  return Text(
                    label,
                    style: const TextStyle(
                        fontSize: 9,
                        color: AppColors.textSecondary,
                        fontFamily: 'monospace'),
                  );
                },
              ),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 28,
                interval: 1,
                getTitlesWidget: (v, meta) {
                  final idx = v.round();
                  if (!indexToDate.containsKey(idx)) {
                    return const SizedBox.shrink();
                  }
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      _dayLabel(idx),
                      style: const TextStyle(
                          fontSize: 8,
                          color: AppColors.textSecondary,
                          fontFamily: 'monospace'),
                    ),
                  );
                },
              ),
            ),
          ),
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              color: AppColors.primary,
              barWidth: 1.5,
              isCurved: spots.length > 2,
              preventCurveOverShooting: true,
              curveSmoothness: 0.25,
              dotData: FlDotData(
                show: true,
                getDotPainter: (spot, pct, bar, idx) => FlDotCirclePainter(
                  radius: 3,
                  color: AppColors.primary,
                  strokeWidth: 0,
                  strokeColor: Colors.transparent,
                ),
              ),
              belowBarData: BarAreaData(
                show: true,
                color: AppColors.primary.withAlpha(18),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Chart placeholder (fewer than 2 sessions) ────────────────

class _ChartPlaceholder extends StatelessWidget {
  const _ChartPlaceholder();

  @override
  Widget build(BuildContext context) {
    return AspectRatio(
      aspectRatio: 1.6,
      child: Center(
        child: Text(
          '// not enough sessions yet\n// log one more to see your trend',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 11,
              color: AppColors.textSecondary,
              fontFamily: 'monospace',
              height: 1.8),
        ),
      ),
    );
  }
}

// ── Rank header ───────────────────────────────────────────────

class _RankHeader extends StatelessWidget {
  const _RankHeader({required this.best1rmKg, required this.baselineKg});
  final double best1rmKg;
  final double baselineKg;

  @override
  Widget build(BuildContext context) {
    final score      = best1rmKg / baselineKg * 100;
    final label      = rankFromScore(score).label;
    final color      = rankFromScore(score).color;
    final next       = nextRankLabel(score);
    final threshold  = nextRankThreshold(score);
    final neededKg   = threshold != null
        ? ((threshold / 100 * baselineKg) - best1rmKg)
        : null;

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: color.withAlpha(80)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'rank',
                  style: const TextStyle(
                    fontSize: 9,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace',
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                    color: color,
                    fontFamily: 'monospace',
                    letterSpacing: 1,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'score: ${score.toStringAsFixed(0)}%  ·  best 1RM: ${best1rmKg.toStringAsFixed(1)} kg',
                  style: const TextStyle(
                    fontSize: 10,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace',
                  ),
                ),
                const SizedBox(height: 3),
                if (next != null && neededKg != null)
                  Text(
                    'next: $next  ↑ +${neededKg.toStringAsFixed(1)} kg',
                    style: const TextStyle(
                      fontSize: 10,
                      color: AppColors.textSecondary,
                      fontFamily: 'monospace',
                    ),
                  )
                else
                  const Text(
                    'max rank achieved',
                    style: TextStyle(
                      fontSize: 10,
                      color: AppColors.textSecondary,
                      fontFamily: 'monospace',
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Image.asset(
            'assets/ranks/$label.webp',
            width: 72,
            height: 72,
            errorBuilder: (_, _, _) => const SizedBox(width: 72, height: 72),
          ),
        ],
      ),
    );
  }
}

// ── Tag ───────────────────────────────────────────────────────

class _Tag extends StatelessWidget {
  const _Tag(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Text(
        label.toLowerCase(),
        style: const TextStyle(
            fontSize: 9,
            color: AppColors.primary,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  const _EmptyState();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        '// no data for the last 30 days\n// complete a session to see progress',
        textAlign: TextAlign.center,
        style: TextStyle(
            fontSize: 12,
            color: AppColors.textSecondary,
            fontFamily: 'monospace',
            height: 1.8),
      ),
    );
  }
}

// ── AI recommendation (weekly, lazy-generated) ────────────────

class _RecommendationSection extends StatefulWidget {
  const _RecommendationSection({
    required this.machineId,
    required this.machineName,
    required this.muscleGroup,
  });

  final int    machineId;
  final String machineName;
  final String muscleGroup;

  @override
  State<_RecommendationSection> createState() => _RecommendationSectionState();
}

class _RecommendationSectionState extends State<_RecommendationSection> {
  String? _content;
  bool    _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  String get _weekStartStr {
    final now = DateTime.now();
    final monday = DateTime(now.year, now.month, now.day - (now.weekday - 1));
    return '${monday.year}-${monday.month.toString().padLeft(2, '0')}-${monday.day.toString().padLeft(2, '0')}';
  }

  Future<void> _load() async {
    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;
    if (userId == null) {
      if (mounted) setState(() => _loading = false);
      return;
    }

    // 1. Return cached recommendation for this week if it exists
    final cached = await supabase
        .from('ai_recommendations')
        .select('content')
        .eq('user_id', userId)
        .eq('machine_id', widget.machineId)
        .eq('week_start', _weekStartStr)
        .maybeSingle();

    if (cached != null) {
      if (mounted) setState(() { _content = cached['content'] as String; _loading = false; });
      return;
    }

    // 2. Gather profile + recent sessions, call API, cache result
    try {
      final thirtyDaysAgo = DateTime.now().subtract(const Duration(days: 30));

      final profile = await supabase
          .from('profiles')
          .select()
          .eq('id', userId)
          .maybeSingle();

      final weightLogs = await supabase
          .from('weight_logs')
          .select('weight_kg, logged_at')
          .eq('user_id', userId)
          .gte('logged_at', thirtyDaysAgo.toIso8601String())
          .order('logged_at', ascending: true) as List;

      final weightHistory = weightLogs.map((w) => {
            'weight_kg': w['weight_kg'],
            'logged_at': (w['logged_at'] as String).substring(0, 10),
          }).toList();

      final sessions = (await supabase
          .from('workout_sessions')
          .select('started_at, workout_sets(reps, weight_kg)')
          .eq('user_id', userId)
          .eq('machine_id', widget.machineId)
          .gte('started_at', thirtyDaysAgo.toIso8601String())
          .order('started_at', ascending: true)) as List;

      final sessionPayload = sessions
          .where((s) => (s['workout_sets'] as List).isNotEmpty)
          .map((s) => {
                'date': (s['started_at'] as String).substring(0, 10),
                'sets': (s['workout_sets'] as List)
                    .map((st) => {'reps': st['reps'], 'weight_kg': st['weight_kg']})
                    .toList(),
              })
          .toList();

      final response = await ApiClient.post('/recommend', {
        'machine_id':   widget.machineId,
        'machine_name': widget.machineName,
        'muscle_group': widget.muscleGroup,
        'week_start':   _weekStartStr,
        'sessions':     sessionPayload,
        'profile': {
          'goal':           profile?['goal'],
          'weight_kg':      profile?['weight_kg'],
          'height_cm':      profile?['height_cm'],
          'medical_notes':  profile?['medical_notes'],
          'weight_history': weightHistory,
        },
      });

      final content = response['content'] as String;

      await supabase.from('ai_recommendations').insert({
        'user_id':    userId,
        'machine_id': widget.machineId,
        'week_start': _weekStartStr,
        'content':    content,
      });

      if (mounted) setState(() { _content = content; _loading = false; });
    } catch (_) {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Padding(
        padding: EdgeInsets.symmetric(vertical: 16),
        child: Center(
          child: SizedBox(
            width: 16,
            height: 16,
            child: CircularProgressIndicator(
                strokeWidth: 1.5, color: AppColors.textSecondary),
          ),
        ),
      );
    }

    if (_content == null) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            '// coach.ai  ·  this week',
            style: TextStyle(
              fontSize: 9,
              color: AppColors.primary,
              fontFamily: 'monospace',
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            _content!,
            style: const TextStyle(
              fontSize: 13,
              color: AppColors.textPrimary,
              height: 1.6,
            ),
          ),
        ],
      ),
    );
  }
}
