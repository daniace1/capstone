import 'package:flutter_riverpod/flutter_riverpod.dart';

/// Holds the machine id of the page the user is currently on, when relevant.
/// Only the four machine-bound pages publish to it via [NaviScope]; everything
/// else leaves it null. The shell-level Navi widget reads this to give the AI
/// the active machine without coupling to any page's internal state.
class NaviContextNotifier extends Notifier<int?> {
  @override
  int? build() => null;

  void set(int? id) => state = id;
  void clear() => state = null;
}

final activeMachineProvider =
    NotifierProvider<NaviContextNotifier, int?>(NaviContextNotifier.new);
