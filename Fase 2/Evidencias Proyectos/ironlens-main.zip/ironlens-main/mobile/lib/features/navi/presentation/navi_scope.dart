import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../providers/navi_context_provider.dart';

/// Observes route transitions within the Navi shell so a [NaviScope] can
/// re-assert its machine when its page is revealed again after a pop.
final RouteObserver<ModalRoute<void>> naviRouteObserver =
    RouteObserver<ModalRoute<void>>();

/// Declarative wrapper that publishes the active machine id to
/// [activeMachineProvider] for the lifetime of a machine-bound page.
///
/// All the lifecycle mechanics live here — pages just declare their machine:
///
/// ```dart
/// NaviScope(activeMachineId: widget.machineId, child: Scaffold(...));
/// ```
///
/// Handles the tricky cases so the published value always reflects the
/// visible page:
/// - mid-page changes (advancing exercises) → `didUpdateWidget`
/// - a deeper machine page popped off → `didPopNext` re-asserts this page
/// - this page popped → `dispose` clears only if it still owns the value
class NaviScope extends ConsumerStatefulWidget {
  const NaviScope({
    required this.activeMachineId,
    required this.child,
    super.key,
  });

  /// Null means "no active machine" (e.g. an unrecognized scan result).
  /// Callers should always mount NaviScope unconditionally and just vary
  /// this value — swapping between "wrapped" and "unwrapped" at the root
  /// forces a full subtree remount, which risks framework-level element
  /// bookkeeping issues (e.g. an InheritedWidget disposed with dependents
  /// still attached) during rapid navigation.
  final int? activeMachineId;
  final Widget child;

  @override
  ConsumerState<NaviScope> createState() => _NaviScopeState();
}

class _NaviScopeState extends ConsumerState<NaviScope> with RouteAware {
  void _publish() {
    ref.read(activeMachineProvider.notifier).set(widget.activeMachineId);
  }

  @override
  void initState() {
    super.initState();
    // Post-frame avoids "provider modified during build" when the shell's
    // Navi widget is building at the same time.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _publish();
    });
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route is PageRoute) {
      naviRouteObserver.subscribe(this, route);
    }
  }

  @override
  void didUpdateWidget(NaviScope oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.activeMachineId != widget.activeMachineId) {
      // Post-frame for the same reason as initState — didUpdateWidget runs
      // during the widget tree build pass, so a direct provider write here
      // throws "Tried to modify a provider while the widget tree was
      // building." (hit when _activeMachineId changes value between
      // rebuilds, e.g. RoutineExecutionPage advancing exercises).
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _publish();
      });
    }
  }

  /// A route pushed on top of this one was popped — this page is visible
  /// again, so re-assert its machine (the popped page cleared the provider).
  @override
  void didPopNext() => _publish();

  @override
  void dispose() {
    naviRouteObserver.unsubscribe(this);
    // Only clear if we still own the value, so we don't clobber a page that
    // already took over.
    if (ref.read(activeMachineProvider) == widget.activeMachineId) {
      ref.read(activeMachineProvider.notifier).clear();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
