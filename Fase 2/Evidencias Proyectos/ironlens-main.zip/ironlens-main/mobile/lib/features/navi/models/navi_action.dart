import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/router/app_router.dart';

/// A structured navigation/action chip returned by the `/chat` backend.
/// The `type` drives where tapping the chip takes the user. `params` carry
/// machine details for the two machine-specific actions.
class NaviAction {
  const NaviAction({required this.type, required this.label, this.params});

  final String type;
  final String label;
  final Map<String, dynamic>? params;

  factory NaviAction.fromJson(Map<String, dynamic> json) {
    return NaviAction(
      type: json['type'] as String,
      label: json['label'] as String? ?? '',
      params: (json['params'] as Map?)?.cast<String, dynamic>(),
    );
  }

  /// Executes the action's navigation. Returns false for unknown types so the
  /// caller can ignore them (the backend already validates, this is defence
  /// in depth).
  bool navigate(BuildContext context) {
    final p = params ?? const {};
    switch (type) {
      case 'nav_scan':
        context.push(AppRoutes.camera);
      case 'nav_sessions':
        context.push(AppRoutes.sessions);
      case 'nav_routine':
        context.push(AppRoutes.routine);
      case 'nav_collection':
        context.push(AppRoutes.scanned);
      case 'nav_progress':
        context.push(AppRoutes.progress);
      case 'nav_profile':
      case 'log_weight':
        context.push(AppRoutes.profile);
      case 'nav_monthly_analysis':
        context.push(AppRoutes.monthlyAnalysis);
      case 'regen_routine':
        context.push(AppRoutes.routine, extra: {'regen': true});
      case 'nav_workout':
        context.push(AppRoutes.workout, extra: {
          'machineId': p['machine_id'],
          'machineName': p['machine_name'],
          'muscleGroup': p['muscle_group'],
          'sessionId': null,
        });
      case 'nav_machine_progress':
        context.push(AppRoutes.machineProgress, extra: {
          'machineId': p['machine_id'],
          'machineName': p['machine_name'],
          'muscleGroup': p['muscle_group'] ?? '',
          'best1rmKg': null,
          'baselineKg': null,
        });
      default:
        return false;
    }
    return true;
  }
}
