import '../../../core/router/app_router.dart';

/// Pure mapping from a router location to the `page_context` the backend
/// expects. Deriving it from the router means pages never have to publish
/// their context — a single source of truth.
String pageContextFromLocation(String location) {
  switch (location) {
    case AppRoutes.home:
      return 'home';
    case AppRoutes.workout:
      return 'workout';
    case AppRoutes.routine:
      return 'routine';
    case AppRoutes.routineExecution:
      return 'routine_execution';
    case AppRoutes.sessions:
      return 'sessions';
    case AppRoutes.progress:
      return 'progress';
    case AppRoutes.machineProgress:
      return 'machine_progress';
    case AppRoutes.scanned:
      return 'collection';
    case AppRoutes.result:
      return 'result';
    case AppRoutes.profile:
      return 'profile';
    case AppRoutes.monthlyAnalysis:
      return 'monthly_analysis';
    default:
      return 'home'; // generic fallback (camera, settings, pickers, auth)
  }
}
