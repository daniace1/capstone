import '../../../core/network/api_client.dart';
import '../models/navi_message.dart';

/// Calls `POST /chat` with the running conversation plus the current page
/// context. All Navi backend access goes through here.
abstract final class NaviService {
  static Future<NaviReply> send({
    required List<NaviMessage> messages,
    required String pageContext,
    int? activeMachineId,
  }) async {
    final json = await ApiClient.post('/chat', {
      'messages': messages.map((m) => m.toRequestJson()).toList(),
      'page_context': pageContext,
      'active_machine_id': activeMachineId,
    });
    return NaviReply.fromJson(json);
  }
}
