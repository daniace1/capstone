import 'navi_action.dart';
import 'navi_report.dart';

/// One turn in the Navi conversation, kept in local widget state only.
class NaviMessage {
  const NaviMessage({
    required this.role,
    required this.content,
    this.actions = const [],
    this.report,
  });

  final String role; // "user" | "assistant"
  final String content;
  final List<NaviAction> actions;
  final NaviReport? report;

  Map<String, dynamic> toRequestJson() => {'role': role, 'content': content};
}

/// Parsed `/chat` response.
class NaviReply {
  const NaviReply({required this.message, required this.actions, this.report});

  final String message;
  final List<NaviAction> actions;
  final NaviReport? report;

  factory NaviReply.fromJson(Map<String, dynamic> json) {
    final rawActions = (json['actions'] as List?) ?? const [];
    final rawReport = json['report'];
    return NaviReply(
      message: json['message'] as String? ?? '',
      actions: rawActions
          .whereType<Map>()
          .map((a) => NaviAction.fromJson(a.cast<String, dynamic>()))
          .toList(),
      report: rawReport is Map
          ? NaviReport.fromJson(rawReport.cast<String, dynamic>())
          : null,
    );
  }
}
