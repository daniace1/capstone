import 'package:flutter/material.dart';

import 'navi_widget.dart';

/// Wraps every app page with the persistent Navi assistant. Navi reserves a
/// docked bar at the bottom and the page renders above it, so the dock never
/// overlaps page content or buttons. Pages outside this shell (camera, auth)
/// get no dock and look unchanged.
class NaviShell extends StatelessWidget {
  const NaviShell({required this.child, super.key});

  final Widget child;

  @override
  Widget build(BuildContext context) => NaviWidget(child: child);
}
