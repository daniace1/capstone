import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:go_router/go_router.dart';

import '../../../core/theme/app_theme.dart';
import '../../../core/widgets/pressable.dart';
import '../../../core/widgets/typing_dots.dart';
import '../data/navi_prefs.dart';
import '../data/navi_service.dart';
import '../models/navi_action.dart';
import '../models/navi_message.dart';
import '../providers/navi_context_provider.dart';
import 'navi_report_view.dart';
import 'page_context.dart';

/// Global Navi assistant. Wraps every shelled page, reserving a docked bar at
/// the bottom (so it never overlaps page content or buttons). Tapping the dock
/// expands a compact conversational panel that floats above everything.
class NaviWidget extends ConsumerStatefulWidget {
  const NaviWidget({required this.child, super.key});

  /// The page being shown beneath the Navi dock.
  final Widget child;

  @override
  ConsumerState<NaviWidget> createState() => _NaviWidgetState();
}

class _NaviWidgetState extends ConsumerState<NaviWidget> {
  static bool _greetedThisSession = false;

  final _input = TextEditingController();
  final List<NaviMessage> _messages = [];
  final FlutterTts _tts = FlutterTts();

  bool _expanded = false;
  bool _loading = false;
  bool _voiceEnabled = false;
  bool _showText = true;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final voice = await getNaviVoiceEnabled();
    final showText = await getNaviShowText();
    if (mounted) {
      setState(() {
        _voiceEnabled = voice;
        _showText = showText;
      });
    }
  }

  @override
  void dispose() {
    _input.dispose();
    _stopVoice();
    super.dispose();
  }

  String get _currentLocation => GoRouterState.of(context).matchedLocation;

  Future<void> _stopVoice() async {
    try {
      await _tts.stop();
    } catch (_) {/* engine may be unavailable */}
  }

  Future<void> _speak(String text) async {
    if (!_voiceEnabled || text.isEmpty) return;
    try {
      await _tts.setLanguage('en-US');
      await _tts.speak(text);
    } catch (_) {/* no-op if TTS engine missing */}
  }

  Future<void> _open() async {
    await _loadPrefs();
    setState(() => _expanded = true);
    if (!_greetedThisSession && _messages.isEmpty) {
      _greetedThisSession = true;
      _send('What should I do now?', display: false);
    }
  }

  void _close() {
    _stopVoice();
    setState(() => _expanded = false);
  }

  Future<void> _send(String text, {bool display = true}) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty || _loading) return;

    final outgoing = [..._messages, NaviMessage(role: 'user', content: trimmed)];
    setState(() {
      if (display) _messages.add(NaviMessage(role: 'user', content: trimmed));
      _loading = true;
      _input.clear();
    });
    await _stopVoice();

    final pageContext = pageContextFromLocation(_currentLocation);
    // Only attach the active machine on pages that are actually machine-bound,
    // so a stale value left in the provider can't leak into other contexts.
    const machineContexts = {
      'workout', 'result', 'machine_progress', 'routine_execution',
    };
    final activeMachineId = machineContexts.contains(pageContext)
        ? ref.read(activeMachineProvider)
        : null;

    try {
      final reply = await NaviService.send(
        messages: outgoing,
        pageContext: pageContext,
        activeMachineId: activeMachineId,
      );
      if (!mounted) return;
      setState(() {
        _messages.add(NaviMessage(
          role: 'assistant',
          content: reply.message,
          actions: reply.actions,
          report: reply.report,
        ));
        _loading = false;
      });
      _speak(reply.message);
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _messages.add(const NaviMessage(
          role: 'assistant',
          content: 'Navi is unavailable right now. Try again shortly.',
        ));
        _loading = false;
      });
    }
  }

  void _runAction(NaviAction action) {
    _close();
    action.navigate(context);
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // The page sits above a reserved dock — content never overlaps Navi.
        Column(
          children: [
            Expanded(
              child: MediaQuery.removePadding(
                context: context,
                removeBottom: true, // the dock owns the bottom safe area now
                child: widget.child,
              ),
            ),
            _dockBar(context),
          ],
        ),
        // The conversation panel floats above the page and the dock.
        if (_expanded) _buildOverlay(context),
      ],
    );
  }

  // ── Docked bar (always visible) ─────────────────────────────

  Widget _dockBar(BuildContext context) {
    final bottomInset = MediaQuery.of(context).viewPadding.bottom;
    return GestureDetector(
      onTap: _open,
      behavior: HitTestBehavior.opaque,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border(
            top: BorderSide(color: AppColors.primary.withAlpha(90)),
          ),
        ),
        padding: EdgeInsets.fromLTRB(24, 0, 20, bottomInset),
        child: Material(
          type: MaterialType.transparency,
          child: SizedBox(
            height: 52,
            child: Row(
              children: [
                const Text('✦',
                    style: TextStyle(color: AppColors.primary, fontSize: 15)),
                const SizedBox(width: 14),
                Text('ask navi...',
                    style: TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 12,
                      letterSpacing: 1.5,
                      color: AppColors.textPrimary.withAlpha(150),
                    )),
                const Spacer(),
                const Text('↑',
                    style: TextStyle(
                      fontFamily: 'monospace',
                      fontSize: 13,
                      color: AppColors.textSecondary,
                    )),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Expanded overlay ────────────────────────────────────────

  Widget _buildOverlay(BuildContext context) {
    final last = _messages.isNotEmpty ? _messages.last : null;
    final showAssistant = last != null && last.role == 'assistant';

    return Positioned.fill(
      child: Stack(
        children: [
          // Scrim — tap outside to close
          GestureDetector(
            onTap: _close,
            child: Container(color: Colors.black.withAlpha(150)),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Padding(
              // Sit above the keyboard when open, otherwise above the dock.
              padding: EdgeInsets.fromLTRB(
                16,
                0,
                16,
                (MediaQuery.of(context).viewInsets.bottom > 0
                        ? MediaQuery.of(context).viewInsets.bottom
                        : 52 + MediaQuery.of(context).viewPadding.bottom) +
                    12,
              ),
              child: Material(
                type: MaterialType.transparency,
                child: Container(
                decoration: BoxDecoration(
                  color: AppColors.crust,
                  border: Border.all(color: AppColors.primary.withAlpha(140)),
                ),
                padding: const EdgeInsets.all(16),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Text('✦ navi',
                            style: TextStyle(
                              fontFamily: 'monospace',
                              fontSize: 12,
                              letterSpacing: 2,
                              color: AppColors.primary,
                            )),
                        const Spacer(),
                        GestureDetector(
                          onTap: _close,
                          child: const Text('×',
                              style: TextStyle(
                                fontFamily: 'monospace',
                                fontSize: 18,
                                color: AppColors.textSecondary,
                              )),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    if (_loading)
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 10),
                        child: TypingDots(color: AppColors.primary),
                      )
                    else
                      ConstrainedBox(
                        constraints: const BoxConstraints(maxHeight: 320),
                        child: SingleChildScrollView(
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (showAssistant) ...[
                                if (_showText && last.content.isNotEmpty)
                                  Text(last.content,
                                      style: const TextStyle(
                                        fontFamily: 'monospace',
                                        fontSize: 13,
                                        height: 1.5,
                                        color: AppColors.textPrimary,
                                      )),
                                if (last.report != null)
                                  NaviReportView(report: last.report!),
                                if (last.actions.isNotEmpty) ...[
                                  const SizedBox(height: 12),
                                  Wrap(
                                    spacing: 8,
                                    runSpacing: 8,
                                    children: last.actions
                                        .map((a) => _ActionChip(
                                              action: a,
                                              onTap: () => _runAction(a),
                                            ))
                                        .toList(),
                                  ),
                                ],
                              ] else
                                Text('Ask me about your training.',
                                    style: TextStyle(
                                      fontFamily: 'monospace',
                                      fontSize: 13,
                                      color: AppColors.textSecondary.withAlpha(200),
                                    )),
                            ],
                          ),
                        ),
                      ),
                    const SizedBox(height: 14),
                    _inputBar(),
                  ],
                ),
              ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _inputBar() {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: AppColors.borderSubtle),
      ),
      padding: const EdgeInsets.only(left: 12, right: 4),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              controller: _input,
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 13,
                color: AppColors.textPrimary,
              ),
              cursorColor: AppColors.primary,
              textInputAction: TextInputAction.send,
              onTap: _stopVoice,
              onSubmitted: _send,
              decoration: const InputDecoration(
                isDense: true,
                border: InputBorder.none,
                hintText: 'type a question...',
                hintStyle: TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 12,
                  color: AppColors.textSecondary,
                ),
              ),
            ),
          ),
          IconButton(
            onPressed: _loading ? null : () => _send(_input.text),
            icon: Icon(Icons.send,
                size: 16,
                color: _loading
                    ? AppColors.textSecondary
                    : AppColors.primary),
          ),
        ],
      ),
    );
  }
}

// ── Action chip ───────────────────────────────────────────────

class _ActionChip extends StatelessWidget {
  const _ActionChip({required this.action, required this.onTap});

  final NaviAction action;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      highlightBorder: true,
      borderColor: AppColors.teal,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: AppColors.teal.withAlpha(20),
          border: Border.all(color: AppColors.teal.withAlpha(150)),
        ),
        child: Text(
          '→ ${action.label}',
          style: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 11,
            letterSpacing: 0.5,
            color: AppColors.teal,
          ),
        ),
      ),
    );
  }
}
