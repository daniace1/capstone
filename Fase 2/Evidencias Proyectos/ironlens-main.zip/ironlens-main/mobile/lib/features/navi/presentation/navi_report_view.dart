import 'dart:math' as math;

import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/fitness/bmi.dart';
import '../../../core/fitness/one_rep_max.dart';
import '../../../core/fitness/rank.dart';
import '../../../core/theme/app_theme.dart';
import '../../../core/units/unit_system.dart';
import '../models/navi_report.dart';

/// Renders the inline data widget requested by a `/chat` report directive.
class NaviReportView extends StatelessWidget {
  const NaviReportView({required this.report, super.key});

  final NaviReport report;

  @override
  Widget build(BuildContext context) {
    switch (report.type) {
      case 'bmi':
        return const _BmiReport();
      case 'weight_trend':
        return const _WeightTrendReport();
      case 'best_machine':
        return const _BestMachineReport();
      case 'machine_rank':
        final id = report.params?['machine_id'] as int?;
        final name = report.params?['machine_name'] as String? ?? 'Machine';
        if (id == null) return const SizedBox.shrink();
        return _MachineRankReport(machineId: id, machineName: name);
      default:
        return const SizedBox.shrink();
    }
  }
}

// ── Shared frame ──────────────────────────────────────────────

class _ReportFrame extends StatelessWidget {
  const _ReportFrame({required this.label, required this.child});
  final String label;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.only(top: 4),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('// $label',
              style: const TextStyle(
                fontFamily: 'monospace',
                fontSize: 9,
                letterSpacing: 0.5,
                color: AppColors.textSecondary,
              )),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}

Widget _loading() => const SizedBox(
      height: 40,
      child: Center(
        child: SizedBox(
          width: 16,
          height: 16,
          child: CircularProgressIndicator(
              strokeWidth: 1.5, color: AppColors.textSecondary),
        ),
      ),
    );

Widget _empty(String text) => Text(text,
    style: const TextStyle(
      fontFamily: 'monospace',
      fontSize: 11,
      color: AppColors.textSecondary,
    ));

Widget _sparkline(List<FlSpot> spots, Color color) {
  if (spots.length < 2) return const SizedBox.shrink();
  final ys = spots.map((s) => s.y).toList();
  final minY = ys.reduce(math.min);
  final maxY = ys.reduce(math.max);
  final pad = (maxY - minY) * 0.15 + 0.5;
  return SizedBox(
    height: 64,
    child: LineChart(LineChartData(
      minY: minY - pad,
      maxY: maxY + pad,
      gridData: const FlGridData(show: false),
      titlesData: const FlTitlesData(show: false),
      borderData: FlBorderData(show: false),
      lineTouchData: const LineTouchData(enabled: false),
      lineBarsData: [
        LineChartBarData(
          spots: spots,
          isCurved: true,
          preventCurveOverShooting: true,
          color: color,
          barWidth: 2,
          dotData: const FlDotData(show: false),
          belowBarData: BarAreaData(
            show: true,
            color: color.withAlpha(24),
          ),
        ),
      ],
    )),
  );
}

String? _uid() => Supabase.instance.client.auth.currentUser?.id;

// ── BMI ───────────────────────────────────────────────────────

class _BmiReport extends StatefulWidget {
  const _BmiReport();
  @override
  State<_BmiReport> createState() => _BmiReportState();
}

class _BmiReportState extends State<_BmiReport> {
  late final Future<({double? current, String? category, List<FlSpot> spots})> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<({double? current, String? category, List<FlSpot> spots})> _load() async {
    final c = Supabase.instance.client;
    final uid = _uid();
    if (uid == null) return (current: null, category: null, spots: <FlSpot>[]);

    final profile =
        await c.from('profiles').select('height_cm, weight_kg').eq('id', uid).maybeSingle();
    final height = (profile?['height_cm'] as num?)?.toDouble();
    if (height == null) return (current: null, category: null, spots: <FlSpot>[]);

    final since = DateTime.now().subtract(const Duration(days: 365));
    final logs = await c
        .from('weight_logs')
        .select('weight_kg, logged_at')
        .eq('user_id', uid)
        .gte('logged_at', since.toIso8601String())
        .order('logged_at', ascending: true) as List;

    final spots = <FlSpot>[];
    if (logs.length >= 2) {
      final first = DateTime.parse(logs.first['logged_at'] as String);
      for (final w in logs) {
        final x = DateTime.parse(w['logged_at'] as String).difference(first).inDays.toDouble();
        final v = bmi((w['weight_kg'] as num).toDouble(), height);
        spots.add(FlSpot(x, double.parse(v.toStringAsFixed(1))));
      }
    }

    final latestW = logs.isNotEmpty
        ? (logs.last['weight_kg'] as num).toDouble()
        : (profile?['weight_kg'] as num?)?.toDouble();
    final current = latestW != null ? bmi(latestW, height) : null;

    return (
      current: current,
      category: current != null ? bmiCategory(current) : null,
      spots: spots,
    );
  }

  @override
  Widget build(BuildContext context) {
    return _ReportFrame(
      label: 'bmi · last 12 months',
      child: FutureBuilder(
        future: _f,
        builder: (context, snap) {
          if (!snap.hasData) return _loading();
          final d = snap.data!;
          if (d.current == null) {
            return _empty('Add your height and weight first.');
          }
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'BMI ${d.current!.toStringAsFixed(1)}  ·  ${d.category}',
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 14,
                  color: AppColors.textPrimary,
                ),
              ),
              if (d.spots.length >= 2) ...[
                const SizedBox(height: 8),
                _sparkline(d.spots, AppColors.teal),
              ],
            ],
          );
        },
      ),
    );
  }
}

// ── Weight trend ──────────────────────────────────────────────

class _WeightTrendReport extends StatefulWidget {
  const _WeightTrendReport();
  @override
  State<_WeightTrendReport> createState() => _WeightTrendReportState();
}

class _WeightTrendReportState extends State<_WeightTrendReport> {
  late final Future<({double? current, double? delta, List<FlSpot> spots})> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<({double? current, double? delta, List<FlSpot> spots})> _load() async {
    final c = Supabase.instance.client;
    final uid = _uid();
    if (uid == null) return (current: null, delta: null, spots: <FlSpot>[]);

    final since = DateTime.now().subtract(const Duration(days: 90));
    final logs = await c
        .from('weight_logs')
        .select('weight_kg, logged_at')
        .eq('user_id', uid)
        .gte('logged_at', since.toIso8601String())
        .order('logged_at', ascending: true) as List;

    if (logs.isEmpty) return (current: null, delta: null, spots: <FlSpot>[]);

    final spots = <FlSpot>[];
    final first = DateTime.parse(logs.first['logged_at'] as String);
    for (final w in logs) {
      final x = DateTime.parse(w['logged_at'] as String).difference(first).inDays.toDouble();
      spots.add(FlSpot(x, (w['weight_kg'] as num).toDouble()));
    }
    final current = (logs.last['weight_kg'] as num).toDouble();
    final delta = current - (logs.first['weight_kg'] as num).toDouble();
    return (current: current, delta: delta, spots: spots);
  }

  @override
  Widget build(BuildContext context) {
    return _ReportFrame(
      label: 'weight · last 90 days',
      child: FutureBuilder(
        future: _f,
        builder: (context, snap) {
          if (!snap.hasData) return _loading();
          final d = snap.data!;
          if (d.current == null) return _empty('No weight logs yet.');
          final sign = d.delta! > 0 ? '+' : '';
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '${Units.formatWeight(context, d.current!)}  ·  $sign${Units.formatWeight(context, d.delta!)} in 90d',
                style: const TextStyle(
                  fontFamily: 'monospace',
                  fontSize: 14,
                  color: AppColors.textPrimary,
                ),
              ),
              if (d.spots.length >= 2) ...[
                const SizedBox(height: 8),
                _sparkline(d.spots, AppColors.accent),
              ],
            ],
          );
        },
      ),
    );
  }
}

// ── Machine rank ──────────────────────────────────────────────

class _MachineRankReport extends StatefulWidget {
  const _MachineRankReport({required this.machineId, required this.machineName});
  final int machineId;
  final String machineName;

  @override
  State<_MachineRankReport> createState() => _MachineRankReportState();
}

class _MachineRankReportState extends State<_MachineRankReport> {
  late final Future<({Rank? rank, double? score, double? best1rm})> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<({Rank? rank, double? score, double? best1rm})> _load() async {
    final c = Supabase.instance.client;
    final uid = _uid();
    if (uid == null) return (rank: null, score: null, best1rm: null);

    final machine =
        await c.from('machines').select('baseline_1rm_kg').eq('id', widget.machineId).maybeSingle();
    final baseline = (machine?['baseline_1rm_kg'] as num?)?.toDouble();

    final sessions = await c
        .from('workout_sessions')
        .select('workout_sets(weight_kg, reps)')
        .eq('user_id', uid)
        .eq('machine_id', widget.machineId) as List;

    double? best1rm;
    for (final s in sessions) {
      for (final set in (s['workout_sets'] as List? ?? const [])) {
        final w = (set['weight_kg'] as num?)?.toDouble();
        final r = set['reps'] as int?;
        if (w != null && r != null) {
          final rm = epley1rm(w, r);
          best1rm = best1rm == null ? rm : math.max(best1rm, rm);
        }
      }
    }

    if (best1rm == null || baseline == null || baseline <= 0) {
      return (rank: null, score: null, best1rm: best1rm);
    }
    return (
      rank: rankFor(best1rm, baseline),
      score: best1rm / baseline * 100,
      best1rm: best1rm,
    );
  }

  @override
  Widget build(BuildContext context) {
    return _ReportFrame(
      label: 'rank · ${widget.machineName.toLowerCase()}',
      child: FutureBuilder(
        future: _f,
        builder: (context, snap) {
          if (!snap.hasData) return _loading();
          final d = snap.data!;
          if (d.rank == null) {
            return _empty('Log a weighted set to earn a rank.');
          }
          return Row(
            children: [
              Image.asset(
                d.rank!.asset,
                width: 40,
                height: 40,
                errorBuilder: (_, _, _) => const SizedBox(width: 40, height: 40),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.rank!.label.toUpperCase(),
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                        color: d.rank!.color,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'score ${d.score!.toStringAsFixed(0)}%  ·  best 1RM ${Units.formatWeight(context, d.best1rm!)}',
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 10,
                        color: AppColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

// ── Best machine ──────────────────────────────────────────────

class _BestMachineReport extends StatefulWidget {
  const _BestMachineReport();
  @override
  State<_BestMachineReport> createState() => _BestMachineReportState();
}

class _BestMachineReportState extends State<_BestMachineReport> {
  late final Future<({String? name, Rank? rank, double? score})> _f;

  @override
  void initState() {
    super.initState();
    _f = _load();
  }

  Future<({String? name, Rank? rank, double? score})> _load() async {
    final c = Supabase.instance.client;
    final uid = _uid();
    if (uid == null) return (name: null, rank: null, score: null);

    final rows = await c
        .from('workout_sessions')
        .select('machine_id, machines(name, baseline_1rm_kg), workout_sets(weight_kg, reps)')
        .eq('user_id', uid) as List;

    final best1rmByMachine = <int, double>{};
    final nameById = <int, String>{};
    final baselineById = <int, double>{};

    for (final s in rows) {
      final mid = s['machine_id'] as int?;
      final machine = s['machines'] as Map?;
      if (mid == null || machine == null) continue;
      nameById[mid] = machine['name'] as String? ?? 'Machine';
      final baseline = (machine['baseline_1rm_kg'] as num?)?.toDouble();
      if (baseline != null) baselineById[mid] = baseline;
      for (final set in (s['workout_sets'] as List? ?? const [])) {
        final w = (set['weight_kg'] as num?)?.toDouble();
        final r = set['reps'] as int?;
        if (w != null && r != null) {
          final rm = epley1rm(w, r);
          best1rmByMachine[mid] =
              best1rmByMachine[mid] == null ? rm : math.max(best1rmByMachine[mid]!, rm);
        }
      }
    }

    int? bestId;
    double bestScore = -1;
    best1rmByMachine.forEach((mid, best1rm) {
      final baseline = baselineById[mid];
      if (baseline != null && baseline > 0) {
        final score = best1rm / baseline * 100;
        if (score > bestScore) {
          bestScore = score;
          bestId = mid;
        }
      }
    });

    if (bestId == null) return (name: null, rank: null, score: null);
    return (
      name: nameById[bestId],
      rank: rankFromScore(bestScore),
      score: bestScore,
    );
  }

  @override
  Widget build(BuildContext context) {
    return _ReportFrame(
      label: 'strongest machine',
      child: FutureBuilder(
        future: _f,
        builder: (context, snap) {
          if (!snap.hasData) return _loading();
          final d = snap.data!;
          if (d.name == null) return _empty('Log weighted sets to rank machines.');
          return Row(
            children: [
              Image.asset(
                d.rank!.asset,
                width: 36,
                height: 36,
                errorBuilder: (_, _, _) => const SizedBox(width: 36, height: 36),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      d.name!,
                      style: const TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 14,
                        color: AppColors.textPrimary,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      '${d.rank!.label}  ·  ${d.score!.toStringAsFixed(0)}%',
                      style: TextStyle(
                        fontFamily: 'monospace',
                        fontSize: 10,
                        color: d.rank!.color,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
