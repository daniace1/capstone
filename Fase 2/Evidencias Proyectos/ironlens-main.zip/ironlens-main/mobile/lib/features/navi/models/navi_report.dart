/// A directive from `/chat` telling Navi to render an inline data widget.
/// The backend only picks the type (+ machine_id for machine reports); the app
/// fetches and draws the data locally.
class NaviReport {
  const NaviReport({required this.type, this.params});

  final String type;
  final Map<String, dynamic>? params;

  factory NaviReport.fromJson(Map<String, dynamic> json) => NaviReport(
        type: json['type'] as String,
        params: (json['params'] as Map?)?.cast<String, dynamic>(),
      );
}
