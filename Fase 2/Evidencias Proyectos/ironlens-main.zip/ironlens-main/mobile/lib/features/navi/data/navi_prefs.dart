import 'package:shared_preferences/shared_preferences.dart';

/// Persisted Navi preferences (Settings toggles).
const _prefVoice    = 'navi_voice_enabled';
const _prefShowText = 'navi_show_text';

Future<bool> getNaviVoiceEnabled() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getBool(_prefVoice) ?? false; // off by default
}

Future<void> setNaviVoiceEnabled(bool value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool(_prefVoice, value);
}

Future<bool> getNaviShowText() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getBool(_prefShowText) ?? true; // text visible by default
}

Future<void> setNaviShowText(bool value) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool(_prefShowText, value);
}
