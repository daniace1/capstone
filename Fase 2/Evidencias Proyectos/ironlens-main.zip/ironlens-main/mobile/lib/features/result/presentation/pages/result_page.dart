import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/pressable.dart';
import '../../../navi/presentation/navi_scope.dart';
import '../../models/scan_result.dart';

class ResultPage extends StatefulWidget {
  const ResultPage({required this.result, super.key});
  final ScanResult result;

  @override
  State<ResultPage> createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  Set<int> _savedIds = {};

  @override
  void initState() {
    super.initState();
    _loadCollection();
  }

  Future<void> _loadCollection() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    final data = await Supabase.instance.client
        .from('scanned_machines')
        .select('machine_id')
        .eq('user_id', userId);
    if (mounted) {
      setState(() {
        _savedIds =
            (data as List).map((r) => r['machine_id'] as int).toSet();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final scaffold = Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(),
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _PhotoCard(result: widget.result, savedIds: _savedIds),
                    if (widget.result.candidates.length > 1) ...[
                      const SizedBox(height: 24),
                      _AlternativesList(
                        candidates:
                            widget.result.candidates.skip(1).toList(),
                        savedIds: _savedIds,
                      ),
                    ],
                    const SizedBox(height: 16),
                    const _ExploreAllButton(),
                    const SizedBox(height: 32),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );

    // Always mount NaviScope — only activeMachineId varies (null for an
    // unrecognized scan result). See navi_scope.dart for why swapping the
    // root widget conditionally is unsafe.
    return NaviScope(activeMachineId: widget.result.top.machineId, child: scaffold);
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          Pressable(
            onTap: () => context.go(AppRoutes.home),
            child: const Text('← back',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace')),
          ),
          const Spacer(),
          const Text('scan',
              style: TextStyle(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ── Main photo card ───────────────────────────────────────────

class _PhotoCard extends StatelessWidget {
  const _PhotoCard({required this.result, required this.savedIds});
  final ScanResult result;
  final Set<int> savedIds;

  @override
  Widget build(BuildContext context) {
    final top = result.top;
    final pct = (top.confidence * 100).toStringAsFixed(0);
    final alreadySaved =
        top.machineId != null && savedIds.contains(top.machineId);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(4),
        child: Stack(
          children: [
            result.imageBytes.isNotEmpty
                ? Image.memory(result.imageBytes,
                    width: double.infinity, height: 280, fit: BoxFit.cover)
                : Container(
                    width: double.infinity,
                    height: 280,
                    color: AppColors.surface,
                    child: const Icon(Icons.fitness_center,
                        color: AppColors.textSecondary, size: 40),
                  ),
            Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.black.withAlpha(200)
                    ],
                    stops: const [0.4, 1.0],
                  ),
                ),
              ),
            ),
            Positioned(
              left: 16,
              right: 16,
              bottom: 16,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          top.machineName.toUpperCase(),
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                            letterSpacing: 2,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          top.muscleGroups.join('  ·  '),
                          style: const TextStyle(
                              fontSize: 11,
                              color: Colors.white70,
                              letterSpacing: 1),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('$pct%',
                          style: TextStyle(
                            fontSize: 13,
                            color: _confidenceColor(top.confidence),
                            fontFamily: 'monospace',
                            fontWeight: FontWeight.w600,
                          )),
                      const SizedBox(height: 8),
                      _SaveButton(
                          candidate: top, alreadySaved: alreadySaved),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Alternatives list ─────────────────────────────────────────

class _AlternativesList extends StatelessWidget {
  const _AlternativesList(
      {required this.candidates, required this.savedIds});
  final List<MachineCandidate> candidates;
  final Set<int> savedIds;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('// other possibilities',
              style: TextStyle(
                  fontSize: 11,
                  color: AppColors.textSecondary,
                  fontFamily: 'monospace',
                  letterSpacing: 1)),
          const SizedBox(height: 12),
          ...candidates.asMap().entries.map((e) {
            final idx = e.key + 1;
            final c = e.value;
            final pct = (c.confidence * 100).toStringAsFixed(0);
            final alreadySaved =
                c.machineId != null && savedIds.contains(c.machineId);
            return Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.symmetric(
                  horizontal: 14, vertical: 12),
              decoration: BoxDecoration(
                color: AppColors.surface,
                border: Border.all(color: AppColors.borderSubtle),
              ),
              child: Row(
                children: [
                  Text('0$idx',
                      style: const TextStyle(
                          fontSize: 11,
                          color: AppColors.textSecondary,
                          fontFamily: 'monospace')),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(c.machineName,
                            style: const TextStyle(
                                fontSize: 13,
                                color: AppColors.textPrimary,
                                fontWeight: FontWeight.w500)),
                        if (c.muscleGroups.isNotEmpty)
                          Text(c.muscleGroups.join(' · '),
                              style: const TextStyle(
                                  fontSize: 10,
                                  color: AppColors.textSecondary,
                                  letterSpacing: 0.5)),
                      ],
                    ),
                  ),
                  Text('$pct%',
                      style: TextStyle(
                          fontSize: 12,
                          color: _confidenceColor(c.confidence),
                          fontFamily: 'monospace')),
                  const SizedBox(width: 12),
                  _SaveButton(
                      candidate: c,
                      compact: true,
                      alreadySaved: alreadySaved),
                ],
              ),
            );
          }),
        ],
      ),
    );
  }
}

// ── Explore all button ────────────────────────────────────────

class _ExploreAllButton extends StatelessWidget {
  const _ExploreAllButton();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Pressable(
        onTap: () => context.push(AppRoutes.machinePicker),
        highlightBorder: true,
        child: Container(
          padding:
              const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          decoration: BoxDecoration(
            border: Border.all(color: AppColors.borderSubtle),
          ),
          child: const Row(
            children: [
              Text('\$  ',
                  style: TextStyle(
                      color: AppColors.primary,
                      fontFamily: 'monospace',
                      fontSize: 13)),
              Text('explore_all_machines',
                  style: TextStyle(
                      color: AppColors.textPrimary,
                      fontFamily: 'monospace',
                      fontSize: 13)),
              Spacer(),
              Text('//',
                  style: TextStyle(
                      color: AppColors.textSecondary,
                      fontFamily: 'monospace',
                      fontSize: 11)),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Save button ───────────────────────────────────────────────

class _SaveButton extends StatefulWidget {
  const _SaveButton({
    required this.candidate,
    required this.alreadySaved,
    this.compact = false,
  });
  final MachineCandidate candidate;
  final bool alreadySaved;
  final bool compact;

  @override
  State<_SaveButton> createState() => _SaveButtonState();
}

class _SaveButtonState extends State<_SaveButton> {
  bool _saved = false;
  bool _loading = false;

  void _goToWorkout(GoRouter router) {
    final c = widget.candidate;
    router.push(AppRoutes.workout, extra: {
      'machineId':  c.machineId!,
      'machineName': c.machineName,
      'muscleGroup': c.muscleGroups.isNotEmpty ? c.muscleGroups.first : '',
      'sessionId':  null,
    });
  }

  Future<void> _save(
      ScaffoldMessengerState messenger, GoRouter router) async {
    if (_saved || _loading) return;
    setState(() => _loading = true);
    try {
      final userId = Supabase.instance.client.auth.currentUser?.id;
      if (userId == null) return;
      if (widget.candidate.machineId == null) {
        messenger.showSnackBar(const SnackBar(
            content: Text('Machine not in catalog — cannot save')));
        return;
      }
      await Supabase.instance.client.from('scanned_machines').upsert(
        {'user_id': userId, 'machine_id': widget.candidate.machineId},
        onConflict: 'user_id, machine_id',
      );
      if (mounted) {
        setState(() => _saved = true);
        // F15: saving a scan adds to the collection — don't force a session.
        // Home reloads its summary on return, so the new machine is reflected.
        router.go(AppRoutes.home);
      }
    } catch (e) {
      messenger.showSnackBar(
          SnackBar(content: Text('Save failed: $e')));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final messenger = ScaffoldMessenger.of(context);
    final router = GoRouter.of(context);
    final inCollection = widget.alreadySaved || _saved;

    // ── compact (alternatives row) ──────────────────────────
    if (widget.compact) {
      return GestureDetector(
        onTap: inCollection
            ? (widget.candidate.machineId != null
                ? () => _goToWorkout(router)
                : null)
            : () => _save(messenger, router),
        child: Icon(
          inCollection ? Icons.check_circle_outline : Icons.add,
          size: 16,
          color: inCollection ? AppColors.green : AppColors.textSecondary,
        ),
      );
    }

    // ── full (main photo card) ──────────────────────────────
    if (inCollection) {
      return GestureDetector(
        onTap: widget.candidate.machineId != null
            ? () => _goToWorkout(router)
            : null,
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            Icon(Icons.check_circle_outline,
                size: 12, color: AppColors.green),
            SizedBox(width: 4),
            Text('in collection',
                style: TextStyle(
                    fontSize: 10,
                    fontFamily: 'monospace',
                    letterSpacing: 1,
                    color: AppColors.green)),
          ],
        ),
      );
    }

    return Pressable(
      onTap: () => _save(messenger, router),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(20),
          border: Border.all(color: Colors.white38),
          borderRadius: BorderRadius.circular(2),
        ),
        child: _loading
            ? const SizedBox(
                width: 12,
                height: 12,
                child: CircularProgressIndicator(
                    strokeWidth: 1.5, color: Colors.white))
            : const Text('save',
                style: TextStyle(
                  fontSize: 11,
                  fontFamily: 'monospace',
                  letterSpacing: 1.5,
                  color: Colors.white,
                )),
      ),
    );
  }
}

Color _confidenceColor(double c) {
  if (c >= 0.75) return AppColors.green;
  if (c >= 0.45) return AppColors.teal;
  return AppColors.textSecondary;
}
