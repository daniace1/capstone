/// Data model for a machine detection event.
///
/// Fields are intentionally minimal for the MVP.
/// Extend with AI confidence scores, muscle-group data, and instructions
/// once [google_generative_ai] is integrated.
class DetectionResult {
  const DetectionResult({
    required this.machineName,
    required this.confidence,
    this.description,
    this.muscleGroups = const [],
  });

  final String machineName;

  /// Confidence score in the range [0.0, 1.0].
  final double confidence;

  final String? description;

  final List<String> muscleGroups;

  /// Placeholder data used during the MVP validation phase.
  /// Replace call sites with AI-returned [DetectionResult] instances.
  factory DetectionResult.dummy() => const DetectionResult(
        machineName: 'Lat Pulldown',
        confidence: 0.94,
        description:
            'Cable machine designed for upper-body pulling movements. '
            'Ideal for developing width and thickness in the back.',
        muscleGroups: ['Latissimus dorsi', 'Biceps brachii', 'Rear deltoid'],
      );
}
