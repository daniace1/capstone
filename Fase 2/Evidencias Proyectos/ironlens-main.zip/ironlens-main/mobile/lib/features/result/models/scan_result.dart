import 'dart:typed_data';

class MachineCandidate {
  const MachineCandidate({
    required this.machineName,
    required this.confidence,
    this.description,
    this.muscleGroups = const [],
    this.machineId,
  });

  final String machineName;
  final double confidence;
  final String? description;
  final List<String> muscleGroups;
  final int? machineId;

  factory MachineCandidate.fromJson(Map<String, dynamic> json) =>
      MachineCandidate(
        machineName: json['machine_name'] as String? ?? 'Unknown',
        confidence: (json['confidence'] as num?)?.toDouble() ?? 0.0,
        description: json['description'] as String?,
        muscleGroups: (json['muscle_groups'] as List<dynamic>?)
                ?.map((e) => e.toString())
                .toList() ??
            [],
        machineId: json['machine_id'] as int?,
      );
}

class ScanResult {
  const ScanResult({
    required this.imageBytes,
    required this.candidates,
  });

  final Uint8List imageBytes;
  final List<MachineCandidate> candidates;

  MachineCandidate get top => candidates.first;

  bool get hasResult =>
      candidates.isNotEmpty && candidates.first.machineName != 'Unknown';

  static ScanResult dummy() => ScanResult(
        imageBytes: Uint8List(0),
        candidates: const [
          MachineCandidate(
            machineName: 'Bench Press',
            confidence: 0.94,
            description: 'Free-weight bench for horizontal pressing movements.',
            muscleGroups: ['Pectoralis major', 'Triceps', 'Anterior deltoid'],
          ),
          MachineCandidate(
            machineName: 'Incline Press',
            confidence: 0.42,
            description: 'Inclined bench targeting upper chest.',
            muscleGroups: ['Upper chest', 'Triceps'],
          ),
        ],
      );
}
