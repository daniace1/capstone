import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/pressable.dart';

class MachinePickerPage extends StatefulWidget {
  const MachinePickerPage({super.key});

  @override
  State<MachinePickerPage> createState() => _MachinePickerPageState();
}

class _MachinePickerPageState extends State<MachinePickerPage> {
  List<Map<String, dynamic>> _machines = [];
  List<Map<String, dynamic>> _filtered = [];
  bool _loading = true;
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load();
    _searchCtrl.addListener(_filter);
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final data = await Supabase.instance.client
        .from('machines')
        .select()
        .order('name', ascending: true);
    setState(() {
      _machines = List<Map<String, dynamic>>.from(data);
      _filtered = _machines;
      _loading = false;
    });
  }

  void _filter() {
    final q = _searchCtrl.text.toLowerCase();
    setState(() {
      _filtered = q.isEmpty
          ? _machines
          : _machines.where((m) {
              final name = (m['name'] as String).toLowerCase();
              final muscle = (m['muscle_group'] as String? ?? '').toLowerCase();
              return name.contains(q) || muscle.contains(q);
            }).toList();
    });
  }

  Future<void> _save(Map<String, dynamic> machine) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    final machineId = machine['id'] as int;
    await Supabase.instance.client.from('scanned_machines').upsert(
      {'user_id': userId, 'machine_id': machineId},
      onConflict: 'user_id, machine_id',
    );
    if (mounted) {
      context.push(AppRoutes.workout, extra: {
        'machineId': machineId,
        'machineName': machine['name'] as String,
        'muscleGroup': machine['muscle_group'] as String? ?? '',
        'sessionId': null,
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
              child: Row(
                children: [
                  Pressable(
                    onTap: () => context.pop(),
                    child: const Text('← back',
                        style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace')),
                  ),
                  const Spacer(),
                  const Text('machines',
                      style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace')),
                ],
              ),
            ),
            const SizedBox(height: 16),
            // Search
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                controller: _searchCtrl,
                style: const TextStyle(fontSize: 13, color: AppColors.textPrimary, fontFamily: 'monospace'),
                decoration: InputDecoration(
                  hintText: 'search...',
                  hintStyle: const TextStyle(color: AppColors.textSecondary, fontFamily: 'monospace', fontSize: 13),
                  isDense: true,
                  contentPadding: const EdgeInsets.symmetric(vertical: 10),
                  enabledBorder: const UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.borderSubtle),
                  ),
                  focusedBorder: const UnderlineInputBorder(
                    borderSide: BorderSide(color: AppColors.textSecondary),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 16),
            // List
            Expanded(
              child: _loading
                  ? const Center(
                      child: SizedBox(
                        width: 20, height: 20,
                        child: CircularProgressIndicator(strokeWidth: 1.5, color: AppColors.textSecondary),
                      ),
                    )
                  : _filtered.isEmpty
                      ? const Center(
                          child: Text('no machines found',
                              style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace')),
                        )
                      : ListView.builder(
                          itemCount: _filtered.length,
                          itemBuilder: (context, i) {
                            final m = _filtered[i];
                            return _MachineRow(
                              name: m['name'] as String,
                              muscleGroup: m['muscle_group'] as String? ?? '',
                              onSave: () => _save(m),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MachineRow extends StatefulWidget {
  const _MachineRow({
    required this.name,
    required this.muscleGroup,
    required this.onSave,
  });

  final String name;
  final String muscleGroup;
  final VoidCallback onSave;

  @override
  State<_MachineRow> createState() => _MachineRowState();
}

class _MachineRowState extends State<_MachineRow> {
  bool _saved = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _saved ? null : () { setState(() => _saved = true); widget.onSave(); },
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: const BoxDecoration(
          border: Border(bottom: BorderSide(color: AppColors.borderSubtle, width: 0.5)),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(widget.name,
                      style: const TextStyle(fontSize: 13, color: AppColors.textPrimary)),
                  Text(widget.muscleGroup,
                      style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, letterSpacing: 0.5)),
                ],
              ),
            ),
            Icon(
              _saved ? Icons.check : Icons.add,
              size: 16,
              color: _saved ? AppColors.green : AppColors.textSecondary,
            ),
          ],
        ),
      ),
    );
  }
}
