import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/confirm_dialog.dart';
import '../../../../core/widgets/measured_fit_list.dart';
import '../../../../core/widgets/pressable.dart';

class ScannedPage extends StatefulWidget {
  const ScannedPage({super.key});

  @override
  State<ScannedPage> createState() => _ScannedPageState();
}

class _ScannedPageState extends State<ScannedPage> {
  List<_ScannedEntry> _entries = [];
  bool _loading = true;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      setState(() => _loading = false);
      return;
    }
    final data = await Supabase.instance.client
        .from('scanned_machines')
        .select('id, scanned_at, machines(id, name, muscle_group)')
        .eq('user_id', userId)
        .order('scanned_at', ascending: false);

    setState(() {
      _entries = (data as List).map((row) {
        final m = row['machines'] as Map<String, dynamic>;
        return _ScannedEntry(
          id: row['id'] as String,
          machineId: m['id'] as int,
          machineName: m['name'] as String,
          muscleGroup: m['muscle_group'] as String? ?? '',
          scannedAt: DateTime.parse(row['scanned_at'] as String).toLocal(),
        );
      }).toList();
      _loading = false;
    });
  }

  Future<void> _delete(String id) async {
    final ok = await showConfirmDialog(
      context,
      title: 'delete machine',
      message: 'remove this machine from your collection?',
    );
    if (!ok) return;
    await Supabase.instance.client
        .from('scanned_machines')
        .delete()
        .eq('id', id);
    if (!mounted) return;
    setState(() => _entries.removeWhere((e) => e.id == id));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(count: _entries.length),
            Expanded(
              child: _loading
                  ? const Center(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 1.5,
                            color: AppColors.textSecondary),
                      ),
                    )
                  : _entries.isEmpty
                      ? _EmptyState()
                      : MeasuredFitList<_ScannedEntry>(
                          fixedTop: const SizedBox.shrink(),
                          items: _entries,
                          itemBuilder: (context, e) => _EntryRow(
                            entry: e,
                            onDelete: () => _delete(e.id),
                          ),
                          page: _page,
                          onPageChanged: (p) => setState(() => _page = p),
                          onRefresh: _load,
                        ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({required this.count});
  final int count;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      child: Row(
        children: [
          Pressable(
            onTap: () => context.go(AppRoutes.home),
            child: const Text('← back',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace')),
          ),
          const Spacer(),
          Text(
            count > 0 ? 'scanned  [$count]' : 'scanned',
            style: const TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
                fontFamily: 'monospace'),
          ),
        ],
      ),
    );
  }
}

// ── Entry row ─────────────────────────────────────────────────

class _EntryRow extends StatelessWidget {
  const _EntryRow({required this.entry, required this.onDelete});
  final _ScannedEntry entry;
  final VoidCallback onDelete;

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) return 'today';
    if (diff.inDays == 1) return 'yesterday';
    if (diff.inDays < 7) return '${diff.inDays}d ago';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      decoration: const BoxDecoration(
        border: Border(
            bottom: BorderSide(color: AppColors.borderSubtle, width: 0.5)),
      ),
      child: Row(
        children: [
          Expanded(
            child: GestureDetector(
              behavior: HitTestBehavior.opaque,
              onTap: () => context.push(AppRoutes.workout, extra: {
                'machineId': entry.machineId,
                'machineName': entry.machineName,
                'muscleGroup': entry.muscleGroup,
                'sessionId': null,
              }),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    entry.machineName,
                    style: const TextStyle(
                        fontSize: 13,
                        color: AppColors.textPrimary,
                        fontWeight: FontWeight.w500),
                  ),
                  const SizedBox(height: 3),
                  Row(
                    children: [
                      _Tag(entry.muscleGroup),
                      const SizedBox(width: 10),
                      Text(
                        _formatDate(entry.scannedAt),
                        style: const TextStyle(
                            fontSize: 10,
                            color: AppColors.textSecondary,
                            fontFamily: 'monospace'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          GestureDetector(
            onTap: onDelete,
            child: const Padding(
              padding: EdgeInsets.only(left: 12),
              child: Icon(Icons.remove,
                  size: 16, color: AppColors.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Muscle group tag ──────────────────────────────────────────

class _Tag extends StatelessWidget {
  const _Tag(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Text(
        label.toLowerCase(),
        style: const TextStyle(
            fontSize: 9,
            color: AppColors.primary,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            '// no machines scanned yet',
            style: TextStyle(
                fontSize: 13,
                color: AppColors.textSecondary,
                fontFamily: 'monospace'),
          ),
          const SizedBox(height: 20),
          GestureDetector(
            onTap: () => context.go(AppRoutes.camera),
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                border: Border.all(color: AppColors.borderSubtle),
              ),
              child: const Text(
                '\$  scan_machine',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.primary,
                    fontFamily: 'monospace',
                    letterSpacing: 1),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Data class ────────────────────────────────────────────────

class _ScannedEntry {
  const _ScannedEntry({
    required this.id,
    required this.machineId,
    required this.machineName,
    required this.muscleGroup,
    required this.scannedAt,
  });

  final String id;
  final int machineId;
  final String machineName;
  final String muscleGroup;
  final DateTime scannedAt;
}
