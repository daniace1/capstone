import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/confirm_dialog.dart';
import '../../../../core/widgets/pressable.dart';
import '../../../../core/units/unit_system.dart';
import '../../../auth/presentation/widgets/auth_widgets.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final _nameCtrl    = TextEditingController();
  final _weightCtrl  = TextEditingController();
  final _heightCtrl  = TextEditingController();
  final _ftCtrl      = TextEditingController();
  final _inCtrl      = TextEditingController();
  final _medicalCtrl = TextEditingController();

  String                     _goal       = 'general';
  Set<String>                _days       = {};
  bool                       _loading    = true;
  bool                       _saving     = false;
  List<Map<String, dynamic>> _weightLogs = [];

  static const _goals = ['strength', 'hypertrophy', 'endurance', 'general'];

  static const _weekDays = [
    ('monday',    'MON'),
    ('tuesday',   'TUE'),
    ('wednesday', 'WED'),
    ('thursday',  'THU'),
    ('friday',    'FRI'),
    ('saturday',  'SAT'),
    ('sunday',    'SUN'),
  ];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _weightCtrl.dispose();
    _heightCtrl.dispose();
    _ftCtrl.dispose();
    _inCtrl.dispose();
    _medicalCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final supabase = Supabase.instance.client;
    final userId = supabase.auth.currentUser?.id;
    if (userId == null) { setState(() => _loading = false); return; }

    try {
      final since = DateTime.now().subtract(const Duration(days: 30));

      final data = await supabase
          .from('profiles')
          .select()
          .eq('id', userId)
          .maybeSingle();

      final logs = await supabase
          .from('weight_logs')
          .select('id, weight_kg, logged_at')
          .eq('user_id', userId)
          .gte('logged_at', since.toIso8601String())
          .order('logged_at', ascending: false)
          .limit(3) as List;

      if (data != null && mounted) {
        _nameCtrl.text    = data['name']          as String? ?? '';
        _medicalCtrl.text = data['medical_notes']  as String? ?? '';
        _goal             = data['goal']           as String? ?? 'general';
        final rawDays     = data['training_days']  as List?;
        _days = rawDays != null
            ? rawDays.map((d) => d as String).toSet()
            : {'monday', 'wednesday', 'friday'};

        final weightKg = (data['weight_kg'] as num?)?.toDouble();
        final heightCm = (data['height_cm'] as num?)?.toDouble();

        if (weightKg != null) _weightCtrl.text = weightKg.toString();
        if (heightCm != null) {
          _heightCtrl.text = heightCm.toString();
          final ftIn = Units.cmToFtIn(heightCm);
          _ftCtrl.text = ftIn.ft.toString();
          _inCtrl.text = ftIn.inches.toString();
        }
      }

      if (mounted) setState(() => _weightLogs = List<Map<String, dynamic>>.from(logs));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _save() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    final isImperial = UnitSystemScope.of(context).isImperial;
    final supabase = Supabase.instance.client;

    double? weightKg;
    double? heightCm;

    if (isImperial) {
      final lbs = double.tryParse(_weightCtrl.text);
      if (lbs != null) weightKg = Units.lbsToKg(lbs);
      final ft = int.tryParse(_ftCtrl.text) ?? 0;
      final inches = int.tryParse(_inCtrl.text) ?? 0;
      if (ft > 0 || inches > 0) heightCm = Units.ftInToCm(ft, inches);
    } else {
      weightKg = double.tryParse(_weightCtrl.text);
      heightCm = double.tryParse(_heightCtrl.text);
    }

    // Confirm before logging a new weight entry — everything else saves
    // silently, only a weight change asks for confirmation.
    var weightChanged = false;
    if (weightKg != null) {
      final lastLog = await supabase
          .from('weight_logs')
          .select('weight_kg')
          .eq('user_id', userId)
          .order('logged_at', ascending: false)
          .limit(1)
          .maybeSingle();
      final lastWeight = (lastLog?['weight_kg'] as num?)?.toDouble();
      weightChanged = lastWeight == null || (lastWeight - weightKg).abs() > 0.01;

      if (weightChanged) {
        if (!mounted) return;
        final ok = await showConfirmDialog(
          context,
          title: 'log new weight',
          message: 'save ${Units.formatWeight(context, weightKg)} to your weight history?',
        );
        if (!ok) return;
      }
    }

    if (!mounted) return;
    setState(() => _saving = true);
    try {
      final notes = _medicalCtrl.text.trim();
      await supabase.from('profiles').upsert({
        'id':            userId,
        'name':          _nameCtrl.text.trim(),
        'weight_kg':     weightKg,
        'height_cm':     heightCm,
        'goal':          _goal,
        'training_days': _days.toList(),
        'medical_notes': notes.isEmpty ? null : notes,
      });

      if (weightChanged) {
        await supabase.from('weight_logs').insert({'user_id': userId, 'weight_kg': weightKg});
      }

      if (mounted) {
        if (context.canPop()) { context.pop(); }
        else { context.go(AppRoutes.home); }
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _deleteWeightLog(String id) async {
    final ok = await showConfirmDialog(
      context,
      title: 'delete entry',
      message: 'remove this entry from your weight history?',
    );
    if (!ok) return;
    await Supabase.instance.client.from('weight_logs').delete().eq('id', id);
    if (!mounted) return;
    setState(() => _weightLogs.removeWhere((l) => l['id'] == id));
  }

  @override
  Widget build(BuildContext context) {
    final isImperial = UnitSystemScope.of(context).isImperial;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(),
            if (_loading)
              const Expanded(
                child: Center(
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(strokeWidth: 1.5, color: AppColors.textSecondary),
                  ),
                ),
              )
            else
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 36),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(height: 32),
                      const AuthHeader(title: 'PROFILE'),
                      const SizedBox(height: 40),

                      TermField(label: 'name', controller: _nameCtrl),
                      const SizedBox(height: 16),
                      TermField(
                        label: isImperial ? 'weight  lbs' : 'weight  kg',
                        controller: _weightCtrl,
                        keyboardType: TextInputType.number,
                      ),
                      const SizedBox(height: 12),
                      _WeightHistorySection(logs: _weightLogs, onDelete: _deleteWeightLog),
                      const SizedBox(height: 16),

                      if (isImperial)
                        Row(
                          children: [
                            Expanded(
                              child: TermField(label: 'height  ft', controller: _ftCtrl, keyboardType: TextInputType.number),
                            ),
                            const SizedBox(width: 12),
                            SizedBox(
                              width: 80,
                              child: TermField(label: 'in', controller: _inCtrl, keyboardType: TextInputType.number),
                            ),
                          ],
                        )
                      else
                        TermField(label: 'height  cm', controller: _heightCtrl, keyboardType: TextInputType.number),

                      const SizedBox(height: 28),
                      const _Label('goal'),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _goals.map((g) {
                          final sel = g == _goal;
                          return GestureDetector(
                            onTap: () => setState(() => _goal = g),
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              decoration: BoxDecoration(
                                border: Border.all(color: sel ? AppColors.textPrimary : AppColors.borderSubtle),
                              ),
                              child: Text(
                                g,
                                style: TextStyle(
                                  fontSize: 11,
                                  fontFamily: 'monospace',
                                  letterSpacing: 1.5,
                                  color: sel ? AppColors.textPrimary : AppColors.textSecondary,
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),

                      const SizedBox(height: 28),
                      const _Label('training days'),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _weekDays.map((day) {
                          final sel = _days.contains(day.$1);
                          return GestureDetector(
                            onTap: () => setState(() {
                              if (sel) { _days.remove(day.$1); }
                              else { _days.add(day.$1); }
                            }),
                            child: Container(
                              width: 44,
                              padding: const EdgeInsets.symmetric(vertical: 8),
                              decoration: BoxDecoration(
                                color: sel ? AppColors.primary.withAlpha(20) : Colors.transparent,
                                border: Border.all(color: sel ? AppColors.primary : AppColors.borderSubtle),
                              ),
                              child: Center(
                                child: Text(
                                  day.$2,
                                  style: TextStyle(
                                    fontSize: 10,
                                    fontFamily: 'monospace',
                                    letterSpacing: 1,
                                    color: sel ? AppColors.primary : AppColors.textSecondary,
                                  ),
                                ),
                              ),
                            ),
                          );
                        }).toList(),
                      ),

                      const SizedBox(height: 28),
                      const _Label('medical notes  (optional)'),
                      const SizedBox(height: 12),
                      TextField(
                        controller: _medicalCtrl,
                        maxLines: 3,
                        style: const TextStyle(fontSize: 13, color: AppColors.textPrimary, fontFamily: 'monospace', height: 1.5),
                        decoration: const InputDecoration(
                          isDense: true,
                          hintText: 'e.g. right knee pain, avoid heavy squats...',
                          hintStyle: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace'),
                          enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: AppColors.borderSubtle)),
                          focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: AppColors.textSecondary)),
                          contentPadding: EdgeInsets.all(12),
                        ),
                      ),

                      const SizedBox(height: 36),
                      TermButton(label: 'save', loading: _saving, onTap: _save),
                      const SizedBox(height: 48),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ── Weight history section ────────────────────────────────────

class _WeightHistorySection extends StatelessWidget {
  const _WeightHistorySection({required this.logs, required this.onDelete});
  final List<Map<String, dynamic>> logs;
  final ValueChanged<String> onDelete;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('history', style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 2)),
        const SizedBox(height: 6),
        if (logs.isEmpty)
          const Text('no entries yet', style: TextStyle(fontSize: 11, color: AppColors.textSecondary, fontFamily: 'monospace'))
        else
          ...logs.take(3).map((log) {
            final id   = log['id'] as String;
            final date = (log['logged_at'] as String).substring(0, 10);
            final kg   = (log['weight_kg'] as num).toDouble();
            return Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Row(
                children: [
                  Text(date, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary, fontFamily: 'monospace')),
                  const Spacer(),
                  Text(
                    Units.formatWeight(context, kg),
                    style: const TextStyle(fontSize: 11, color: AppColors.textPrimary, fontFamily: 'monospace'),
                  ),
                  GestureDetector(
                    onTap: () => onDelete(id),
                    child: const Padding(
                      padding: EdgeInsets.only(left: 10),
                      child: Icon(Icons.remove, size: 14, color: AppColors.textSecondary),
                    ),
                  ),
                ],
              ),
            );
          }),
      ],
    );
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          Pressable(
            onTap: () => context.go(AppRoutes.home),
            child: const Text('← back', style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace')),
          ),
          const Spacer(),
          const Text('profile', style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ── Section label ─────────────────────────────────────────────

class _Label extends StatelessWidget {
  const _Label(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 2),
    );
  }
}
