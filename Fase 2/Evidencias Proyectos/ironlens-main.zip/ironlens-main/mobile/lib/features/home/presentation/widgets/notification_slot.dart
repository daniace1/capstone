import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/widgets/pressable.dart';
import '../../../../core/widgets/weight_log_dialog.dart';
import '../../data/home_notification.dart';
import '../../data/home_summary.dart';
import '../../data/log_weight.dart';
import 'mood_indicator.dart';

/// Right side of the summary panel: shows the highest-priority active
/// notification, or the mood when none is active.
class NotificationSlot extends StatelessWidget {
  const NotificationSlot({
    required this.summary,
    required this.onRefresh,
    super.key,
  });

  final HomeSummary summary;
  final VoidCallback onRefresh;

  Future<void> _handleTap(BuildContext context, HomeNotification notif) async {
    switch (notif.action) {
      case NotificationAction.navigate:
        if (notif.route != null) context.push(notif.route!);
      case NotificationAction.logWeight:
        final kg = await showWeightLogDialog(context);
        if (kg != null) {
          await logWeight(kg);
          onRefresh(); // reload summary so the notification clears
        }
    }
  }

  @override
  Widget build(BuildContext context) {
    final notif = resolveNotification(summary);
    if (notif == null) {
      return MoodIndicator(daysSince: summary.daysSinceLastSession);
    }
    return Pressable(
      onTap: () => _handleTap(context, notif),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Icon(notif.icon, size: 22, color: notif.color),
          const SizedBox(height: 4),
          SizedBox(
            width: 64,
            child: Text(
              notif.label,
              textAlign: TextAlign.center,
              style: TextStyle(
                fontFamily: 'monospace',
                fontSize: 9,
                fontWeight: FontWeight.w700,
                letterSpacing: 1,
                color: notif.color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
