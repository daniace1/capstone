import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../core/fitness/bmi.dart' as fit;
import '../../../core/notifications/weight_reminder.dart';

/// Aggregated, in-memory snapshot of everything the redesigned home shows.
/// Loaded once via parallel Supabase queries (see [load]).
class HomeSummary {
  const HomeSummary({
    required this.name,
    required this.bmi,
    required this.weightKg,
    required this.weightDeltaKg,
    required this.streak,
    required this.daysSinceLastSession,
    required this.volume7d,
    required this.volumeDeltaPct,
    required this.routineDone,
    required this.routineTotal,
    required this.routineDueToday,
    required this.routineMissed,
    required this.scannedCount,
    required this.weightOverdue,
    required this.weightOverdueDays,
  });

  final String name;
  final double? bmi;
  final double? weightKg;
  final double? weightDeltaKg;
  final int streak;
  final int? daysSinceLastSession;
  final double volume7d;
  final double? volumeDeltaPct;
  final int routineDone;
  final int routineTotal;
  final bool routineDueToday;
  final bool routineMissed; // a scheduled day before today wasn't completed
  final int scannedCount;
  final bool weightOverdue;
  final int weightOverdueDays;

  static const empty = HomeSummary(
    name: '', bmi: null, weightKg: null, weightDeltaKg: null,
    streak: 0, daysSinceLastSession: null, volume7d: 0, volumeDeltaPct: null,
    routineDone: 0, routineTotal: 0, routineDueToday: false, routineMissed: false,
    scannedCount: 0, weightOverdue: false, weightOverdueDays: 0,
  );

  /// Typical-looking values shown (boned) by Skeletonizer while loading, so the
  /// skeleton shapes match the real layout's sizes.
  static const placeholder = HomeSummary(
    name: 'Athlete', bmi: 22.5, weightKg: 72, weightDeltaKg: 0.4,
    streak: 3, daysSinceLastSession: 1, volume7d: 12000, volumeDeltaPct: 8,
    routineDone: 2, routineTotal: 3, routineDueToday: false, routineMissed: false,
    scannedCount: 24, weightOverdue: false, weightOverdueDays: 0,
  );

  static Future<HomeSummary> load() async {
    final c = Supabase.instance.client;
    final uid = c.auth.currentUser?.id;
    if (uid == null) return empty;

    final since14 = DateTime.now().subtract(const Duration(days: 14));

    final res = await Future.wait<dynamic>([
      c.from('profiles').select('name, weight_kg, height_cm').eq('id', uid).maybeSingle(),
      c.from('weight_logs').select('weight_kg, logged_at').eq('user_id', uid)
          .order('logged_at', ascending: false).limit(2),
      c.from('workout_sessions').select('started_at, workout_sets(weight_kg, reps)')
          .eq('user_id', uid).gte('started_at', since14.toIso8601String()),
      c.from('scanned_machines').select('id').eq('user_id', uid),
      _loadRoutine(c, uid),
    ]);

    final profile  = res[0] as Map<String, dynamic>?;
    final weights  = (res[1] as List).cast<Map<String, dynamic>>();
    final sessions = (res[2] as List).cast<Map<String, dynamic>>();
    final scanned  = res[3] as List;
    final routine  = res[4] as ({int done, int total, bool dueToday, bool missed});

    // Weight + delta
    final height = (profile?['height_cm'] as num?)?.toDouble();
    final latestW = weights.isNotEmpty ? (weights.first['weight_kg'] as num?)?.toDouble() : (profile?['weight_kg'] as num?)?.toDouble();
    final prevW   = weights.length >= 2 ? (weights[1]['weight_kg'] as num?)?.toDouble() : null;
    final weightDelta = (latestW != null && prevW != null) ? latestW - prevW : null;
    final bmiValue = (latestW != null && height != null) ? fit.bmi(latestW, height) : null;

    // Overdue check needs the real last-logged date, not a local cache —
    // computed after the weight_logs query resolves, using the same data
    // already fetched above (see weight_reminder.dart for why).
    final lastLoggedAt = weights.isNotEmpty
        ? DateTime.tryParse(weights.first['logged_at'] as String)
        : null;
    final overdue = await checkWeightOverdue(lastLoggedAt);

    // Sessions → volume (7d vs prior 7d), streak, recency
    final now = DateTime.now();
    double v7 = 0, vPrev = 0;
    final sessionDays = <DateTime>{};
    for (final s in sessions) {
      final started = DateTime.tryParse(s['started_at'] as String? ?? '')?.toLocal();
      if (started == null) continue;
      sessionDays.add(DateTime(started.year, started.month, started.day));
      double vol = 0;
      for (final set in (s['workout_sets'] as List? ?? const [])) {
        final w = (set['weight_kg'] as num?)?.toDouble();
        final r = set['reps'] as int?;
        if (w != null && r != null) vol += w * r;
      }
      final ageDays = now.difference(started).inDays;
      if (ageDays < 7) {
        v7 += vol;
      } else if (ageDays < 14) {
        vPrev += vol;
      }
    }
    final volumeDeltaPct = vPrev > 0 ? (v7 - vPrev) / vPrev * 100 : null;

    final today = DateTime(now.year, now.month, now.day);
    final yesterday = today.subtract(const Duration(days: 1));
    int streak = 0;
    int? daysSince;
    if (sessionDays.isNotEmpty) {
      final last = sessionDays.reduce((a, b) => a.isAfter(b) ? a : b);
      daysSince = today.difference(last).inDays;
      if (sessionDays.contains(today) || sessionDays.contains(yesterday)) {
        var cursor = sessionDays.contains(today) ? today : yesterday;
        while (sessionDays.contains(cursor)) {
          streak++;
          cursor = cursor.subtract(const Duration(days: 1));
        }
      }
    }

    return HomeSummary(
      name: (profile?['name'] as String?) ?? '',
      bmi: bmiValue,
      weightKg: latestW,
      weightDeltaKg: weightDelta,
      streak: streak,
      daysSinceLastSession: daysSince,
      volume7d: v7,
      volumeDeltaPct: volumeDeltaPct,
      routineDone: routine.done,
      routineTotal: routine.total,
      routineDueToday: routine.dueToday,
      routineMissed: routine.missed,
      scannedCount: scanned.length,
      weightOverdue: overdue.show,
      weightOverdueDays: overdue.daysSince,
    );
  }

  static Future<({int done, int total, bool dueToday, bool missed})> _loadRoutine(
      SupabaseClient c, String uid) async {
    final routine = await c.from('routines').select('id').eq('user_id', uid)
        .order('week_start', ascending: false).limit(1).maybeSingle();
    if (routine == null) return (done: 0, total: 0, dueToday: false, missed: false);
    final rid = routine['id'];

    final days = await c.from('routine_days').select('id, scheduled_date').eq('routine_id', rid);
    final daysList = (days as List).cast<Map<String, dynamic>>();
    final total = daysList.length;

    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final weekStart = today.subtract(Duration(days: now.weekday - 1));
    final logs = await c.from('routine_logs').select('routine_day_id')
        .eq('routine_id', rid).gte('ended_at', weekStart.toIso8601String());
    final doneDayIds = (logs as List).map((l) => l['routine_day_id']).toSet();
    final done = doneDayIds.length;

    // Any day this week that's not done: today → dueToday, before today → missed.
    var dueToday = false;
    var missed   = false;
    for (final d in daysList) {
      if (doneDayIds.contains(d['id'])) continue;
      final raw = d['scheduled_date'] as String?;
      if (raw == null) continue;
      final date = DateTime.parse(raw);
      if (date.year == today.year && date.month == today.month && date.day == today.day) {
        dueToday = true;
      } else if (date.isBefore(today)) {
        missed = true;
      }
    }

    return (done: done, total: total, dueToday: dueToday, missed: missed);
  }
}
