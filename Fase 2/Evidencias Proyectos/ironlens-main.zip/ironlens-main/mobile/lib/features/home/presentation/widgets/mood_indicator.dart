import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';

/// Fallback for the notification slot: a monospace emoticon reflecting training
/// recency. Green = trained recently, gray = a few days, blue = been a while.
class MoodIndicator extends StatelessWidget {
  const MoodIndicator({required this.daysSince, super.key});

  final int? daysSince;

  @override
  Widget build(BuildContext context) {
    final (face, color, caption) = _mood(daysSince);
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          face,
          style: TextStyle(
            fontFamily: 'monospace',
            fontSize: 22,
            fontWeight: FontWeight.w600,
            color: color,
          ),
        ),
        const SizedBox(height: 3),
        Text(
          caption,
          style: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 8,
            letterSpacing: 0.5,
            color: AppColors.textSecondary,
          ),
        ),
      ],
    );
  }

  (String, Color, String) _mood(int? d) {
    if (d == null || d >= 5) return ('):', AppColors.accent, 'come back');
    if (d <= 1) return ('(:', AppColors.green, 'on track');
    return ('|:', AppColors.textSecondary, 'keep going');
  }
}
