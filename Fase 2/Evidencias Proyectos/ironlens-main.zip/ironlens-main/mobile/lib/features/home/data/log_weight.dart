import 'package:supabase_flutter/supabase_flutter.dart';

/// Records a bodyweight entry: appends to `weight_logs` and syncs the
/// profile's current weight. Same effect as logging weight from the profile
/// page. The overdue reminder re-derives itself from this row on the next
/// Home load — nothing to reset locally.
Future<void> logWeight(double kg) async {
  final c = Supabase.instance.client;
  final uid = c.auth.currentUser?.id;
  if (uid == null) return;

  await c.from('weight_logs').insert({'user_id': uid, 'weight_kg': kg});
  await c.from('profiles').update({'weight_kg': kg}).eq('id', uid);
}
