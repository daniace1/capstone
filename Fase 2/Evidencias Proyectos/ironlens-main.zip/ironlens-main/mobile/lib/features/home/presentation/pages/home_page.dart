import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:skeletonizer/skeletonizer.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/units/unit_system.dart';
import '../../../../core/widgets/pressable.dart';
import '../../../navi/presentation/navi_scope.dart';
import '../../../workout/providers/sessions_provider.dart';
import '../../data/home_summary.dart';
import '../widgets/home_summary_panel.dart';

class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> with RouteAware {
  HomeSummary _summary = HomeSummary.placeholder;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadSummary();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route is PageRoute) naviRouteObserver.subscribe(this, route);
  }

  /// Returned to home after a pushed route was popped — refresh the dashboard
  /// so stats and the notification slot reflect any changes (e.g. weight log).
  @override
  void didPopNext() => _loadSummary();

  @override
  void dispose() {
    naviRouteObserver.unsubscribe(this);
    super.dispose();
  }

  Future<void> _loadSummary() async {
    final summary = await HomeSummary.load();
    if (mounted) {
      setState(() {
        _summary = summary;
        _loading = false;
      });
    }
  }

  /// Camera lives outside the shell, so its pop doesn't reach [didPopNext];
  /// refresh manually on return.
  Future<void> _scan() async {
    await context.push(AppRoutes.camera);
    if (mounted) _loadSummary();
  }

  @override
  Widget build(BuildContext context) {
    final activeCount = ref.watch(activeSessionsCountProvider).valueOrNull ?? 0;

    final routineValue = '${_summary.routineDone}/${_summary.routineTotal}';
    final progressValue = Units.formatVolume(context, _summary.volume7d);
    final scannedValue = '${_summary.scannedCount}';

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 44),
            const _AppHeader(),
            const SizedBox(height: 56),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  children: [
                    HomeSummaryPanel(
                      summary: _summary,
                      loading: _loading,
                      onRefresh: _loadSummary,
                    ),
                    const SizedBox(height: 12),
                    _HubCard(
                      icon: Icons.fitness_center_outlined,
                      label: 'SESSIONS',
                      sublabel: activeCount > 0
                          ? '$activeCount active'
                          : 'Workout history',
                      isActive: activeCount > 0,
                      onTap: () => context.push(AppRoutes.sessions),
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _StatTile(
                            icon: Icons.calendar_month_outlined,
                            label: 'ROUTINE',
                            value: routineValue,
                            sublabel: 'Completed',
                            loading: _loading,
                            onTap: () => context.push(AppRoutes.routine),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _StatTile(
                            icon: Icons.bar_chart,
                            label: 'PROGRESS',
                            value: progressValue,
                            valueColor: AppColors.teal,
                            sublabel: 'Volume moved (7d)',
                            loading: _loading,
                            onTap: () => context.push(AppRoutes.progress),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _StatTile(
                            icon: Icons.center_focus_strong,
                            label: 'SCAN',
                            sublabel: 'Scan a machine',
                            onTap: _scan,
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _StatTile(
                            icon: Icons.view_list_outlined,
                            label: 'SCANNED',
                            value: scannedValue,
                            sublabel: 'Machines',
                            loading: _loading,
                            onTap: () => context.push(AppRoutes.scanned),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: _MiniTile(
                            icon: Icons.person_outline,
                            label: 'PROFILE',
                            sublabel: 'Your account',
                            onTap: () => context.push(AppRoutes.profile),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: _MiniTile(
                            icon: Icons.tune,
                            label: 'SETTINGS',
                            sublabel: 'App preferences',
                            onTap: () => context.push(AppRoutes.settings),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 24),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── App header ────────────────────────────────────────────────

class _AppHeader extends StatelessWidget {
  const _AppHeader();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text(
        'IRON LENS',
        style: TextStyle(
          fontFamily: 'FiraCode',
          fontSize: 22,
          fontWeight: FontWeight.w300,
          color: AppColors.textPrimary,
          letterSpacing: 10,
        ),
      ),
    );
  }
}

// ── Wide hub card (SESSIONS) ──────────────────────────────────

class _HubCard extends StatelessWidget {
  const _HubCard({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.onTap,
    this.isActive = false,
  });

  final IconData icon;
  final String label;
  final String sublabel;
  final VoidCallback onTap;
  final bool isActive;

  @override
  Widget build(BuildContext context) {
    final borderColor = isActive
        ? AppColors.green.withAlpha(160)
        : Colors.white.withAlpha(20);
    final iconColor = isActive ? AppColors.green : Colors.white;
    final labelColor = isActive ? AppColors.green : Colors.white;
    final sublabelColor = isActive
        ? AppColors.green.withAlpha(180)
        : Colors.white.withAlpha(140);

    return Pressable(
      onTap: onTap,
      highlightBorder: true,
      borderColor: isActive ? AppColors.green : AppColors.primary,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          color: isActive ? AppColors.green.withAlpha(12) : AppColors.surface,
          border: Border.all(color: borderColor),
        ),
        child: Padding(
          padding: const EdgeInsets.fromLTRB(18, 0, 16, 0),
          child: Row(
            children: [
              Icon(icon, size: 18, color: iconColor),
              const SizedBox(width: 16),
              Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: labelColor,
                        letterSpacing: 2.5,
                      )),
                  const SizedBox(height: 2),
                  Text(sublabel,
                      style: TextStyle(
                          fontSize: 10, color: sublabelColor, letterSpacing: 1)),
                ],
              ),
              const Spacer(),
              Text(
                isActive ? '●' : '//--',
                style: TextStyle(
                    fontSize: isActive ? 7 : 9,
                    color: isActive
                        ? AppColors.green.withAlpha(200)
                        : Colors.white.withAlpha(60),
                    letterSpacing: 1),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Tall stat tile (ROUTINE / PROGRESS / SCAN / SCANNED) ───────

class _StatTile extends StatelessWidget {
  const _StatTile({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.onTap,
    this.value,
    this.valueColor,
    this.loading = false,
  });

  final IconData icon;
  final String label;
  final String sublabel;
  final VoidCallback onTap;
  final String? value;
  final Color? valueColor;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      highlightBorder: true,
      child: Container(
        height: 140,
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border.all(color: Colors.white.withAlpha(20)),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, size: 20, color: AppColors.primary),
                const Spacer(),
                Text('//--',
                    style: TextStyle(
                        fontSize: 9,
                        color: Colors.white.withAlpha(60),
                        letterSpacing: 1)),
              ],
            ),
            const Spacer(),
            Text(label,
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: Colors.white,
                  letterSpacing: 2,
                )),
            // Value slot is always reserved so the label lines up across tiles,
            // even when a tile has no live value (e.g. SCAN). Only the value —
            // the queried data — is boned while loading; label/icon stay static.
            const SizedBox(height: 4),
            Skeletonizer(
              enabled: loading && (value ?? '').isNotEmpty,
              child: Text(value ?? '',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w300,
                    color: valueColor ?? AppColors.primary,
                  )),
            ),
            const SizedBox(height: 4),
            Text(sublabel,
                style: TextStyle(
                    fontSize: 10,
                    color: Colors.white.withAlpha(140),
                    letterSpacing: 0.5)),
          ],
        ),
      ),
    );
  }
}

// ── Compact tile (PROFILE / SETTINGS) ─────────────────────────

class _MiniTile extends StatelessWidget {
  const _MiniTile({
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final String sublabel;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      highlightBorder: true,
      child: Container(
        height: 58,
        decoration: BoxDecoration(
          color: AppColors.surface,
          border: Border.all(color: Colors.white.withAlpha(20)),
        ),
        padding: const EdgeInsets.symmetric(horizontal: 14),
        child: Row(
          children: [
            Icon(icon, size: 17, color: Colors.white),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label,
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                        letterSpacing: 2,
                      )),
                  const SizedBox(height: 2),
                  Text(sublabel,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: 9,
                          color: Colors.white.withAlpha(140),
                          letterSpacing: 0.5)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
