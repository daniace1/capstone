import 'package:flutter/material.dart';
import 'package:skeletonizer/skeletonizer.dart';

import '../../../../core/theme/app_theme.dart';
import '../../../../core/units/unit_system.dart';
import '../../data/home_summary.dart';
import 'notification_slot.dart';

/// Top dashboard panel: identity + key stats on the left, notification/mood
/// on the right.
class HomeSummaryPanel extends StatelessWidget {
  const HomeSummaryPanel({
    required this.summary,
    required this.onRefresh,
    this.loading = false,
    super.key,
  });

  final HomeSummary summary;
  final VoidCallback onRefresh;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: Colors.white.withAlpha(20)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 110),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Skeletonizer(
                  enabled: loading,
                  child: Text(
                    summary.name.isEmpty ? 'athlete' : summary.name,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                      color: AppColors.textPrimary,
                    ),
                  ),
                ),
                const SizedBox(height: 3),
                Skeletonizer(
                  enabled: loading,
                  child: Text(
                    summary.bmi != null ? 'BMI ${summary.bmi!.toStringAsFixed(1)}' : '—',
                    style: const TextStyle(
                      fontSize: 11,
                      fontFamily: 'monospace',
                      color: AppColors.primary,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(width: 20),
          // weight + streak share a line, and so do their values
          Row(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _StatCol(
                label: 'weight',
                loading: loading,
                value: summary.weightKg != null
                    ? Units.formatWeight(context, summary.weightKg!)
                    : '—',
                delta: summary.weightDeltaKg != null && summary.weightDeltaKg != 0
                    ? _Delta(
                        up: summary.weightDeltaKg! > 0,
                        text: Units.formatWeight(context, summary.weightDeltaKg!.abs()),
                      )
                    : null,
              ),
              const SizedBox(width: 18),
              _StatCol(
                label: 'streak',
                loading: loading,
                value: '${summary.streak} ${summary.streak == 1 ? 'day' : 'days'}',
              ),
            ],
          ),
          const Spacer(),
          Container(
            width: 1,
            height: 40,
            color: Colors.white.withAlpha(28),
          ),
          const SizedBox(width: 14),
          Skeletonizer(
            enabled: loading,
            child: NotificationSlot(summary: summary, onRefresh: onRefresh),
          ),
        ],
      ),
    );
  }
}

class _StatCol extends StatelessWidget {
  const _StatCol({
    required this.label,
    required this.value,
    this.delta,
    this.loading = false,
  });
  final String label;
  final String value;
  final Widget? delta;
  final bool loading;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      mainAxisSize: MainAxisSize.min,
      children: [
        // label is static; only the queried value/delta are boned
        Text(
          label,
          style: const TextStyle(
            fontSize: 9,
            fontFamily: 'monospace',
            letterSpacing: 0.5,
            color: AppColors.textSecondary,
          ),
        ),
        const SizedBox(height: 3),
        Skeletonizer(
          enabled: loading,
          child: Text(
            value,
            style: const TextStyle(
              fontSize: 14,
              color: AppColors.textPrimary,
            ),
          ),
        ),
        if (delta != null) ...[
          const SizedBox(height: 2),
          Skeletonizer(enabled: loading, child: delta!),
        ],
      ],
    );
  }
}

class _Delta extends StatelessWidget {
  const _Delta({required this.up, required this.text});
  final bool up;
  final String text;

  @override
  Widget build(BuildContext context) {
    final color = up ? AppColors.green : AppColors.peach;
    return Text(
      '${up ? '▲' : '▼'} $text',
      style: TextStyle(
        fontSize: 9,
        fontFamily: 'monospace',
        color: color,
      ),
    );
  }
}
