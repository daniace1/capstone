import 'package:flutter/material.dart';

import '../../../core/router/app_router.dart';
import '../../../core/theme/app_theme.dart';
import 'home_summary.dart';

/// What tapping a notification does: navigate to a route, or run an in-place
/// action (e.g. open the weight dialog). Extend with more actions as needed.
enum NotificationAction { navigate, logWeight }

/// A single, tappable notification shown in the home summary panel's right slot.
class HomeNotification {
  const HomeNotification({
    required this.label,
    required this.icon,
    required this.color,
    required this.action,
    this.route,
  });

  final String label;
  final IconData icon; // Material icon — renders as a monochrome vector
  final Color color;
  final NotificationAction action;
  final String? route; // required when action == navigate
}

/// A rule maps the loaded home summary to a notification, or null if inactive.
typedef HomeNotificationRule = HomeNotification? Function(HomeSummary s);

// ── Rules (ordered = priority) ────────────────────────────────
// Add a future notification by appending a rule here — nothing else changes.

HomeNotification? _weightOverdueRule(HomeSummary s) {
  if (!s.weightOverdue) return null;
  return const HomeNotification(
    label: 'LOG WEIGHT',
    icon: Icons.warning_amber_rounded,
    color: AppColors.peach,
    action: NotificationAction.logWeight,
  );
}

/// A day before today was never completed — more urgent than a same-day
/// reminder, so it takes priority within this rule.
HomeNotification? _routineAttentionRule(HomeSummary s) {
  if (s.routineMissed) {
    return const HomeNotification(
      label: 'MISSED WORKOUT',
      icon: Icons.warning_amber_rounded,
      color: AppColors.red,
      action: NotificationAction.navigate,
      route: AppRoutes.routine,
    );
  }
  if (s.routineDueToday) {
    return const HomeNotification(
      label: 'TRAINING TODAY',
      icon: Icons.fitness_center,
      color: AppColors.yellow,
      action: NotificationAction.navigate,
      route: AppRoutes.routine,
    );
  }
  return null;
}

// Future extension points (left as a guide):
// HomeNotification? _streakAtRiskRule(HomeSummary s) { ... }

const List<HomeNotificationRule> _rules = [
  _weightOverdueRule, // weight takes priority over routine when both fire
  _routineAttentionRule,
];

/// First active notification by priority, or null → the slot shows the mood.
HomeNotification? resolveNotification(HomeSummary s) {
  for (final rule in _rules) {
    final n = rule(s);
    if (n != null) return n;
  }
  return null;
}
