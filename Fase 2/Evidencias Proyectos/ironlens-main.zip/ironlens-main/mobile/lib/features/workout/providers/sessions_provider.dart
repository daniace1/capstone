import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

/// Count of sessions started today that have at least one set and are not ended.
/// autoDispose: re-fetches automatically when the home screen re-enters the tree.
final activeSessionsCountProvider = FutureProvider.autoDispose<int>((ref) async {
  final userId = Supabase.instance.client.auth.currentUser?.id;
  if (userId == null) return 0;

  final today = DateTime.now();
  final dayStart =
      DateTime(today.year, today.month, today.day).toUtc().toIso8601String();

  final rows = (await Supabase.instance.client
      .from('workout_sessions')
      .select('id, workout_sets(id)')
      .eq('user_id', userId)
      .filter('ended_at', 'is', null)
      .gte('started_at', dayStart)) as List;

  return rows
      .where((r) => (r['workout_sets'] as List).isNotEmpty)
      .length;
});
