import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/preferences/rest_timer.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/widgets/pressable.dart';
import '../../../../core/units/unit_system.dart';
import '../../../navi/presentation/navi_scope.dart';
import '../../providers/sessions_provider.dart';

class WorkoutPage extends ConsumerStatefulWidget {
  const WorkoutPage({
    required this.machineId,
    required this.machineName,
    required this.muscleGroup,
    this.existingSessionId,
    super.key,
  });

  final int machineId;
  final String machineName;
  final String muscleGroup;
  final String? existingSessionId;

  @override
  ConsumerState<WorkoutPage> createState() => _WorkoutPageState();
}

class _WorkoutPageState extends ConsumerState<WorkoutPage> {
  String? _sessionId;
  bool _creatingSession = true;
  final List<_SetEntry> _sets = [];

  final _weightCtrl = TextEditingController();
  final _repsCtrl = TextEditingController();
  bool _addingSet = false;

  double? _recommendedWeightKg;
  double? _safeMaxWeightKg;
  bool    _statsIsAi = false;

  // Rest timer between sets
  int     _restTotal     = 90;
  int?    _restRemaining;
  Timer?  _restTimer;

  @override
  void initState() {
    super.initState();
    if (widget.existingSessionId != null) {
      _sessionId = widget.existingSessionId;
      _loadExistingSets();
    } else {
      _createSession();
    }
    _loadWeightGuidance();
    getRestTimerSeconds().then((s) {
      if (mounted) setState(() => _restTotal = s);
    });
  }

  @override
  void dispose() {
    _restTimer?.cancel();
    _weightCtrl.dispose();
    _repsCtrl.dispose();
    super.dispose();
  }

  void _startRestTimer() {
    _restTimer?.cancel();
    setState(() => _restRemaining = _restTotal);
    _restTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      final left = (_restRemaining ?? 0) - 1;
      if (left <= 0) {
        timer.cancel();
        HapticFeedback.mediumImpact();
        if (mounted) setState(() => _restRemaining = null);
      } else {
        if (mounted) setState(() => _restRemaining = left);
      }
    });
  }

  void _cancelRestTimer() {
    _restTimer?.cancel();
    if (mounted) setState(() => _restRemaining = null);
  }

  Future<void> _createSession() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    final data = await Supabase.instance.client
        .from('workout_sessions')
        .insert({'user_id': userId, 'machine_id': widget.machineId})
        .select('id')
        .single();
    if (mounted) {
      setState(() {
        _sessionId = data['id'] as String;
        _creatingSession = false;
      });
    }
  }

  Future<void> _loadExistingSets() async {
    final data = await Supabase.instance.client
        .from('workout_sets')
        .select()
        .eq('session_id', _sessionId!)
        .order('set_number', ascending: true);
    if (mounted) {
      setState(() {
        _sets.addAll((data as List).map((s) => _SetEntry(
              setNumber: s['set_number'] as int,
              reps: s['reps'] as int,
              weightKg: (s['weight_kg'] as num?)?.toDouble(),
            )));
        _creatingSession = false;
      });
    }
  }

  Future<void> _loadWeightGuidance() async {
    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;
    if (userId == null) return;

    final results = await Future.wait([
      supabase
          .from('machines')
          .select('base_recommended_weight_kg')
          .eq('id', widget.machineId)
          .single(),
      supabase
          .from('user_machine_stats')
          .select('recommended_weight_kg, safe_max_weight_kg')
          .eq('user_id', userId)
          .eq('machine_id', widget.machineId)
          .maybeSingle(),
    ]);

    final machineRow = results[0] as Map<String, dynamic>;
    final statsRow   = results[1];

    if (!mounted) return;

    if (statsRow != null) {
      setState(() {
        _recommendedWeightKg = (statsRow['recommended_weight_kg'] as num?)?.toDouble();
        _safeMaxWeightKg     = (statsRow['safe_max_weight_kg']    as num?)?.toDouble();
        _statsIsAi           = true;
      });
    } else {
      final base = (machineRow['base_recommended_weight_kg'] as num?)?.toDouble();
      if (base != null) {
        setState(() {
          _recommendedWeightKg = base;
          _statsIsAi           = false;
        });
      }
    }
  }

  Future<void> _addSet() async {
    final reps = int.tryParse(_repsCtrl.text.trim());
    if (reps == null || reps <= 0 || _sessionId == null) return;
    final weight = Units.parseWeightInput(context, _weightCtrl.text.trim());
    setState(() => _addingSet = true);
    try {
      final setNumber = _sets.length + 1;
      await Supabase.instance.client.from('workout_sets').insert({
        'session_id': _sessionId,
        'machine_id': widget.machineId,
        'set_number': setNumber,
        'reps': reps,
        'weight_kg': weight,
      });
      setState(() {
        _sets.add(_SetEntry(
            setNumber: setNumber, reps: reps, weightKg: weight));
        _weightCtrl.clear();
        _repsCtrl.clear();
      });
      _startRestTimer();
    } finally {
      if (mounted) setState(() => _addingSet = false);
    }
  }

  Future<void> _done() async {
    if (_sessionId != null) {
      if (_sets.isEmpty) {
        await Supabase.instance.client
            .from('workout_sessions')
            .delete()
            .eq('id', _sessionId!);
      } else {
        await Supabase.instance.client
            .from('workout_sessions')
            .update({'ended_at': DateTime.now().toUtc().toIso8601String()})
            .eq('id', _sessionId!);
      }
    }
    ref.invalidate(activeSessionsCountProvider);
    if (mounted) context.go('/');
  }

  void _goBack() {
    ref.invalidate(activeSessionsCountProvider);
    context.go('/');
  }

  @override
  Widget build(BuildContext context) {
    return NaviScope(
      activeMachineId: widget.machineId,
      child: Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(
              machineName: widget.machineName,
              muscleGroup: widget.muscleGroup,
              sessionActive: !_creatingSession,
              setCount: _sets.length,
              onBack: _goBack,
              onDone: _done,
            ),
            if (_recommendedWeightKg != null || _safeMaxWeightKg != null)
              _WeightHintBar(
                recommended: _recommendedWeightKg,
                safeMax: _safeMaxWeightKg,
                isAi: _statsIsAi,
              ),
            Expanded(
              child: _creatingSession
                  ? const Center(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 1.5,
                            color: AppColors.textSecondary),
                      ),
                    )
                  : Column(
                      children: [
                        Expanded(child: _SetsList(sets: _sets)),
                        if (_restRemaining != null)
                          _RestTimer(
                            remaining: _restRemaining!,
                            total: _restTotal,
                            onCancel: _cancelRestTimer,
                          ),
                        _InputRow(
                          weightCtrl: _weightCtrl,
                          repsCtrl: _repsCtrl,
                          loading: _addingSet,
                          onAdd: _addSet,
                        ),
                      ],
                    ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.machineName,
    required this.muscleGroup,
    required this.sessionActive,
    required this.setCount,
    required this.onBack,
    required this.onDone,
  });

  final String machineName;
  final String muscleGroup;
  final bool sessionActive;
  final int setCount;
  final VoidCallback onBack;
  final VoidCallback onDone;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Pressable(
                onTap: onBack,
                child: const Text('← back',
                    style: TextStyle(
                        fontSize: 12,
                        color: AppColors.textSecondary,
                        fontFamily: 'monospace')),
              ),
              const Spacer(),
              const Text('workout',
                  style: TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                      fontFamily: 'monospace')),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      machineName.toUpperCase(),
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w600,
                        color: AppColors.textPrimary,
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        _MuscleTag(muscleGroup),
                        const SizedBox(width: 10),
                        if (sessionActive)
                          Text(
                            setCount > 0
                                ? '// $setCount sets logged'
                                : '// session active',
                            style: const TextStyle(
                                fontSize: 10,
                                color: AppColors.green,
                                fontFamily: 'monospace'),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: onDone,
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 7),
                  decoration: BoxDecoration(
                    border: Border.all(color: AppColors.borderSubtle),
                  ),
                  child: const Text('done',
                      style: TextStyle(
                          fontSize: 11,
                          fontFamily: 'monospace',
                          letterSpacing: 1.5,
                          color: AppColors.textPrimary)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Sets list ─────────────────────────────────────────────────

class _SetsList extends StatelessWidget {
  const _SetsList({required this.sets});
  final List<_SetEntry> sets;

  @override
  Widget build(BuildContext context) {
    if (sets.isEmpty) {
      return const Center(
        child: Text(
          '// no sets yet\n// add your first set below',
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 12,
              color: AppColors.textSecondary,
              fontFamily: 'monospace',
              height: 1.8),
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      itemCount: sets.length,
      itemBuilder: (context, i) {
        final s = sets[i];
        final setNum = s.setNumber.toString().padLeft(2, '0');
        final weight = Units.formatWeight(context, s.weightKg);
        return Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(
            children: [
              Text(setNum,
                  style: const TextStyle(
                      fontSize: 11,
                      color: AppColors.textSecondary,
                      fontFamily: 'monospace')),
              const SizedBox(width: 14),
              Text(weight,
                  style: const TextStyle(
                      fontSize: 13,
                      color: AppColors.primary,
                      fontFamily: 'monospace',
                      fontWeight: FontWeight.w500)),
              const SizedBox(width: 14),
              Text('${s.reps} reps',
                  style: const TextStyle(
                      fontSize: 13,
                      color: AppColors.textPrimary,
                      fontFamily: 'monospace')),
            ],
          ),
        );
      },
    );
  }
}

// ── Input row ─────────────────────────────────────────────────

class _RestTimer extends StatelessWidget {
  const _RestTimer({
    required this.remaining,
    required this.total,
    required this.onCancel,
  });

  final int remaining;
  final int total;
  final VoidCallback onCancel;

  String _fmt(int s) => '${s ~/ 60}:${(s % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final progress = total > 0 ? remaining / total : 0.0;
    return GestureDetector(
      onTap: onCancel,
      behavior: HitTestBehavior.opaque,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 10),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: AppColors.teal.withAlpha(12),
          border: Border.all(color: AppColors.teal.withAlpha(90)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Text('// rest',
                    style: TextStyle(
                      fontSize: 10,
                      fontFamily: 'monospace',
                      color: AppColors.teal,
                      letterSpacing: 1,
                    )),
                const Spacer(),
                Text(_fmt(remaining),
                    style: const TextStyle(
                      fontSize: 13,
                      fontFamily: 'monospace',
                      color: AppColors.teal,
                      fontWeight: FontWeight.w600,
                    )),
                const SizedBox(width: 12),
                const Text('tap to skip',
                    style: TextStyle(
                      fontSize: 9,
                      fontFamily: 'monospace',
                      color: AppColors.textSecondary,
                    )),
              ],
            ),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: progress,
              minHeight: 2,
              backgroundColor: AppColors.borderSubtle,
              valueColor: const AlwaysStoppedAnimation(AppColors.teal),
            ),
          ],
        ),
      ),
    );
  }
}

class _InputRow extends StatelessWidget {
  const _InputRow({
    required this.weightCtrl,
    required this.repsCtrl,
    required this.loading,
    required this.onAdd,
  });

  final TextEditingController weightCtrl;
  final TextEditingController repsCtrl;
  final bool loading;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    const labelStyle = TextStyle(
        fontSize: 10,
        color: AppColors.textSecondary,
        fontFamily: 'monospace',
        letterSpacing: 0.5);
    const fieldStyle =
        TextStyle(fontSize: 14, color: AppColors.textPrimary, fontFamily: 'monospace');
    const border = UnderlineInputBorder(
        borderSide: BorderSide(color: AppColors.borderSubtle));
    const focusBorder = UnderlineInputBorder(
        borderSide: BorderSide(color: AppColors.textSecondary));

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 16),
      decoration: const BoxDecoration(
        border: Border(top: BorderSide(color: AppColors.borderSubtle)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Expanded(
            flex: 3,
            child: TextField(
              controller: weightCtrl,
              style: fieldStyle,
              keyboardType:
                  const TextInputType.numberWithOptions(decimal: true),
              inputFormatters: [
                FilteringTextInputFormatter.allow(RegExp(r'[\d.,]'))
              ],
              decoration: InputDecoration(
                labelText: Units.weightLabel(context),
                labelStyle: labelStyle,
                hintText: '0',
                hintStyle: TextStyle(
                    color: AppColors.textSecondary, fontFamily: 'monospace'),
                isDense: true,
                enabledBorder: border,
                focusedBorder: focusBorder,
              ),
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            flex: 2,
            child: TextField(
              controller: repsCtrl,
              style: fieldStyle,
              keyboardType: TextInputType.number,
              inputFormatters: [FilteringTextInputFormatter.digitsOnly],
              decoration: const InputDecoration(
                labelText: 'reps',
                labelStyle: labelStyle,
                hintText: '0',
                hintStyle: TextStyle(
                    color: AppColors.textSecondary, fontFamily: 'monospace'),
                isDense: true,
                enabledBorder: border,
                focusedBorder: focusBorder,
              ),
            ),
          ),
          const SizedBox(width: 16),
          GestureDetector(
            onTap: loading ? null : onAdd,
            child: Container(
              padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              decoration: BoxDecoration(
                color: AppColors.primary.withAlpha(30),
                border: Border.all(color: AppColors.primary),
              ),
              child: loading
                  ? const SizedBox(
                      width: 14,
                      height: 14,
                      child: CircularProgressIndicator(
                          strokeWidth: 1.5, color: AppColors.primary))
                  : const Text('+',
                      style: TextStyle(
                          fontSize: 16,
                          color: AppColors.primary,
                          fontFamily: 'monospace',
                          fontWeight: FontWeight.w600)),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Muscle tag ────────────────────────────────────────────────

class _MuscleTag extends StatelessWidget {
  const _MuscleTag(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Text(
        label.toLowerCase(),
        style: const TextStyle(
            fontSize: 9,
            color: AppColors.primary,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Weight hint bar ───────────────────────────────────────────

class _WeightHintBar extends StatelessWidget {
  const _WeightHintBar({
    required this.recommended,
    required this.safeMax,
    required this.isAi,
  });

  final double? recommended;
  final double? safeMax;
  final bool    isAi;

  @override
  Widget build(BuildContext context) {
    final label = isAi ? 'aim for' : 'base ref';
    final color = isAi ? AppColors.teal : AppColors.textSecondary;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Row(
        children: [
          if (isAi)
            const Text('✦ ',
                style: TextStyle(
                    fontSize: 9,
                    color: AppColors.teal,
                    fontFamily: 'monospace')),
          if (recommended != null)
            _HintChip(
              '$label  ${Units.formatWeight(context, recommended)}',
              color: color,
            ),
          if (recommended != null && safeMax != null)
            const SizedBox(width: 8),
          if (safeMax != null)
            _HintChip(
              'max  ${Units.formatWeight(context, safeMax)}',
              color: AppColors.yellow,
            ),
        ],
      ),
    );
  }
}

class _HintChip extends StatelessWidget {
  const _HintChip(this.label, {required this.color});
  final String label;
  final Color  color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        border: Border.all(color: color.withAlpha(80)),
      ),
      child: Text(
        label,
        style: TextStyle(
            fontSize: 9,
            color: color,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Data class ────────────────────────────────────────────────

class _SetEntry {
  const _SetEntry(
      {required this.setNumber, required this.reps, required this.weightKg});
  final int setNumber;
  final int reps;
  final double? weightKg;
}
