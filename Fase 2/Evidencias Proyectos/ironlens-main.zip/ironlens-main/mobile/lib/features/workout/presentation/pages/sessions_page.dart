import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/units/unit_system.dart';
import '../../../../core/widgets/confirm_dialog.dart';
import '../../../../core/widgets/measured_fit_list.dart';
import '../../../../core/widgets/pressable.dart';
import '../../providers/sessions_provider.dart';

/// History date-range filter. Active sessions always show regardless.
enum _Range { week, month, threeMonths, all }

extension _RangeX on _Range {
  String get label => switch (this) {
        _Range.week => '1w',
        _Range.month => '1m',
        _Range.threeMonths => '3m',
        _Range.all => 'all',
      };

  Duration? get duration => switch (this) {
        _Range.week => const Duration(days: 7),
        _Range.month => const Duration(days: 30),
        _Range.threeMonths => const Duration(days: 90),
        _Range.all => null,
      };
}

class SessionsPage extends ConsumerStatefulWidget {
  const SessionsPage({super.key});

  @override
  ConsumerState<SessionsPage> createState() => _SessionsPageState();
}

class _SessionsPageState extends ConsumerState<SessionsPage> {
  List<_SessionEntry> _active = [];
  List<_SessionEntry> _history = [];
  bool _loading = true;
  _Range _range = _Range.week;
  int _page = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) {
      setState(() => _loading = false);
      return;
    }

    var query = Supabase.instance.client
        .from('workout_sessions')
        .select(
            'id, machine_id, started_at, ended_at, machines(name, muscle_group), workout_sets(reps, weight_kg)')
        .eq('user_id', userId);

    // Active sessions (ended_at null) always show; history is limited to the
    // selected range.
    final dur = _range.duration;
    if (dur != null) {
      final since = DateTime.now().subtract(dur).toUtc().toIso8601String();
      query = query.or('ended_at.is.null,started_at.gte.$since');
    }

    final rows = (await query.order('started_at', ascending: false)) as List;

    final active = <_SessionEntry>[];
    final history = <_SessionEntry>[];
    final abandonedIds = <String>[];

    for (final row in rows) {
      final sets = row['workout_sets'] as List;
      final machine = row['machines'] as Map<String, dynamic>?;
      final endedRaw = row['ended_at'] as String?;

      if (endedRaw == null && sets.isEmpty) {
        abandonedIds.add(row['id'] as String);
        continue;
      }

      double? maxWeight;
      int? maxReps;
      for (final s in sets) {
        final w = (s['weight_kg'] as num?)?.toDouble();
        final r = s['reps'] as int?;
        if (w != null && (maxWeight == null || w > maxWeight)) maxWeight = w;
        if (r != null && (maxReps == null || r > maxReps)) maxReps = r;
      }

      final entry = _SessionEntry(
        id: row['id'] as String,
        machineId: (row['machine_id'] as int?) ?? 0,
        machineName: machine?['name'] as String? ?? 'Unknown',
        muscleGroup: machine?['muscle_group'] as String? ?? '',
        startedAt: DateTime.parse(row['started_at'] as String).toLocal(),
        endedAt: endedRaw != null ? DateTime.parse(endedRaw).toLocal() : null,
        setCount: sets.length,
        maxWeightKg: maxWeight,
        maxReps: maxReps,
      );

      if (entry.endedAt == null) {
        active.add(entry);
      } else {
        history.add(entry);
      }
    }

    // Delete abandoned empty sessions (fire-and-forget)
    for (final id in abandonedIds) {
      Supabase.instance.client
          .from('workout_sessions')
          .delete()
          .eq('id', id)
          .then((_) {});
    }

    if (mounted) {
      setState(() {
        _active = active;
        _history = history;
        _loading = false;
      });
    }
  }

  Future<void> _deleteSession(String id) async {
    final ok = await showConfirmDialog(
      context,
      title: 'delete session',
      message: 'remove this session and its sets?',
    );
    if (!ok || !mounted) return;
    final messenger = ScaffoldMessenger.of(context);
    try {
      await Supabase.instance.client
          .from('workout_sessions')
          .delete()
          .eq('id', id);
    } catch (e) {
      // A delete can fail silently otherwise — e.g. a routine-linked session
      // blocked by a foreign key — leaving the row visibly "deleted" in the
      // UI while it's still in the database.
      messenger.showSnackBar(SnackBar(content: Text('Delete failed: $e')));
      return;
    }
    if (!mounted) return;
    ref.invalidate(activeSessionsCountProvider);
    setState(() {
      _active.removeWhere((s) => s.id == id);
      _history.removeWhere((s) => s.id == id);
    });
  }

  void _setRange(_Range r) {
    if (r == _range) return;
    setState(() {
      _range = r;
      _page = 0;
    });
    _load();
  }

  @override
  Widget build(BuildContext context) {
    // Active sessions always show in full, never paginated; only the
    // history rows below them are paginated by MeasuredFitList.
    final fixedTop = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_active.isNotEmpty) ...[
          _SectionHeader('// active',
              count: _active.length, color: AppColors.green),
          ..._active.map((s) => _SessionRow(
                entry: s,
                isActive: true,
                onResume: () => context.push(AppRoutes.workout, extra: {
                  'machineId': s.machineId,
                  'machineName': s.machineName,
                  'muscleGroup': s.muscleGroup,
                  'sessionId': s.id,
                }),
                onDelete: () => _deleteSession(s.id),
              )),
        ],
        if (_history.isNotEmpty)
          _SectionHeader('// history', count: _history.length),
      ],
    );

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(
              activeCount: _active.length,
              historyCount: _history.length,
              onBack: () {
                ref.invalidate(activeSessionsCountProvider);
                context.go(AppRoutes.home);
              },
            ),
            _DateChips(selected: _range, onSelect: _setRange),
            Expanded(
              child: _loading
                  ? const Center(
                      child: SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                            strokeWidth: 1.5,
                            color: AppColors.textSecondary),
                      ),
                    )
                  : (_active.isEmpty && _history.isEmpty)
                      ? RefreshIndicator(
                          onRefresh: _load,
                          color: AppColors.primary,
                          backgroundColor: AppColors.surface,
                          child: _EmptyState(),
                        )
                      : _history.isEmpty
                          // Only active sessions — nothing to paginate.
                          ? RefreshIndicator(
                              onRefresh: _load,
                              color: AppColors.primary,
                              backgroundColor: AppColors.surface,
                              child: SingleChildScrollView(
                                physics: const AlwaysScrollableScrollPhysics(),
                                child: fixedTop,
                              ),
                            )
                          : MeasuredFitList<_SessionEntry>(
                              fixedTop: fixedTop,
                              items: _history,
                              itemBuilder: (context, s) => _SessionRow(
                                entry: s,
                                isActive: false,
                                onDelete: () => _deleteSession(s.id),
                              ),
                              page: _page,
                              onPageChanged: (p) => setState(() => _page = p),
                              onRefresh: _load,
                            ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({
    required this.activeCount,
    required this.historyCount,
    required this.onBack,
  });
  final int activeCount;
  final int historyCount;
  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final total = activeCount + historyCount;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 16),
      child: Row(
        children: [
          Pressable(
            onTap: onBack,
            child: const Text('← back',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace')),
          ),
          const Spacer(),
          Text(
            total > 0 ? 'sessions  [$total]' : 'sessions',
            style: const TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
                fontFamily: 'monospace'),
          ),
        ],
      ),
    );
  }
}

// ── Date range chips ──────────────────────────────────────────

class _DateChips extends StatelessWidget {
  const _DateChips({required this.selected, required this.onSelect});
  final _Range selected;
  final ValueChanged<_Range> onSelect;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Row(
        children: _Range.values.map((r) {
          final isSel = r == selected;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: Pressable(
              onTap: () => onSelect(r),
              highlightBorder: true,
              child: Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: isSel
                      ? AppColors.primary.withAlpha(20)
                      : AppColors.surface,
                  border: Border.all(
                    color: isSel ? AppColors.primary : AppColors.borderSubtle,
                  ),
                ),
                child: Text(
                  r.label,
                  style: TextStyle(
                    fontSize: 11,
                    fontFamily: 'monospace',
                    letterSpacing: 1,
                    color: isSel ? AppColors.primary : AppColors.textSecondary,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

// ── Section header ────────────────────────────────────────────

class _SectionHeader extends StatelessWidget {
  const _SectionHeader(this.label,
      {required this.count, this.color = AppColors.textSecondary});
  final String label;
  final int count;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
      child: Row(
        children: [
          Text(label,
              style: TextStyle(
                  fontSize: 10,
                  color: color,
                  fontFamily: 'monospace',
                  letterSpacing: 1)),
          const SizedBox(width: 8),
          Text('[$count]',
              style: TextStyle(
                  fontSize: 10,
                  color: color.withAlpha(160),
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ── Session row ───────────────────────────────────────────────

class _SessionRow extends StatelessWidget {
  const _SessionRow({
    required this.entry,
    required this.isActive,
    required this.onDelete,
    this.onResume,
  });

  final _SessionEntry entry;
  final bool isActive;
  final VoidCallback onDelete;
  final VoidCallback? onResume;

  String _formatTime(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }

  String _formatDate(DateTime dt) {
    final now = DateTime.now();
    final diff = now.difference(dt);
    if (diff.inDays == 0) return 'today ${_formatTime(dt)}';
    if (diff.inDays == 1) return 'yesterday';
    return '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
      decoration: BoxDecoration(
        border: Border(
          left: isActive
              ? const BorderSide(color: AppColors.green, width: 2)
              : BorderSide.none,
          bottom:
              const BorderSide(color: AppColors.borderSubtle, width: 0.5),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  entry.machineName,
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w500,
                    color: isActive
                        ? AppColors.textPrimary
                        : AppColors.textPrimary,
                  ),
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    _Tag(entry.muscleGroup,
                        color: isActive ? AppColors.green : AppColors.primary),
                    const SizedBox(width: 10),
                    Text(
                      '${entry.setCount} sets  ·  ${_formatDate(entry.startedAt)}',
                      style: const TextStyle(
                          fontSize: 10,
                          color: AppColors.textSecondary,
                          fontFamily: 'monospace'),
                    ),
                  ],
                ),
                if (entry.maxWeightKg != null || entry.maxReps != null) ...[
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      if (entry.maxWeightKg != null)
                        _StatChip('↑ ${Units.formatWeight(context, entry.maxWeightKg)}'),
                      if (entry.maxWeightKg != null && entry.maxReps != null)
                        const SizedBox(width: 6),
                      if (entry.maxReps != null)
                        _StatChip('↑ ${entry.maxReps} reps'),
                    ],
                  ),
                ],
              ],
            ),
          ),
          if (isActive && onResume != null)
            Pressable(
              onTap: onResume,
              highlightBorder: true,
              borderColor: AppColors.green,
              child: Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  border: Border.all(
                      color: AppColors.green.withAlpha(120)),
                ),
                child: const Text('resume →',
                    style: TextStyle(
                        fontSize: 10,
                        color: AppColors.green,
                        fontFamily: 'monospace',
                        letterSpacing: 0.5)),
              ),
            )
          else
            GestureDetector(
              onTap: onDelete,
              child: const Padding(
                padding: EdgeInsets.only(left: 12),
                child: Icon(Icons.remove,
                    size: 16, color: AppColors.textSecondary),
              ),
            ),
        ],
      ),
    );
  }
}

// ── Stat chip ─────────────────────────────────────────────────

class _StatChip extends StatelessWidget {
  const _StatChip(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.teal.withAlpha(20),
        border: Border.all(color: AppColors.teal.withAlpha(80)),
      ),
      child: Text(
        label,
        style: const TextStyle(
            fontSize: 9,
            color: AppColors.teal,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Tag ───────────────────────────────────────────────────────

class _Tag extends StatelessWidget {
  const _Tag(this.label, {this.color = AppColors.primary});
  final String label;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.surface,
        border: Border.all(color: AppColors.borderSubtle),
      ),
      child: Text(
        label.toLowerCase(),
        style: TextStyle(
            fontSize: 9,
            color: color,
            fontFamily: 'monospace',
            letterSpacing: 0.5),
      ),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: const [
        SizedBox(height: 120),
        Center(
          child: Text(
            '// no sessions yet\n// scan a machine to start',
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
                fontFamily: 'monospace',
                height: 1.8),
          ),
        ),
      ],
    );
  }
}

// ── Data class ────────────────────────────────────────────────

class _SessionEntry {
  const _SessionEntry({
    required this.id,
    required this.machineId,
    required this.machineName,
    required this.muscleGroup,
    required this.startedAt,
    required this.endedAt,
    required this.setCount,
    required this.maxWeightKg,
    required this.maxReps,
  });

  final String id;
  final int machineId;
  final String machineName;
  final String muscleGroup;
  final DateTime startedAt;
  final DateTime? endedAt;
  final int setCount;
  final double? maxWeightKg;
  final int? maxReps;
}
