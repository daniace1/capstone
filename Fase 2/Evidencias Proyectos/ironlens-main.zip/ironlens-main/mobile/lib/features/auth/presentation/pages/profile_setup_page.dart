import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/units/unit_system.dart';
import '../widgets/auth_widgets.dart';

class ProfileSetupPage extends StatefulWidget {
  const ProfileSetupPage({super.key});

  @override
  State<ProfileSetupPage> createState() => _ProfileSetupPageState();
}

class _ProfileSetupPageState extends State<ProfileSetupPage> {
  final _nameCtrl   = TextEditingController();
  final _weightCtrl = TextEditingController();
  final _heightCtrl = TextEditingController();
  final _ftCtrl     = TextEditingController();
  final _inCtrl     = TextEditingController();
  String _goal = 'general';
  bool _loading = false;
  String? _error;

  static const _goals = ['strength', 'hypertrophy', 'endurance', 'general'];

  @override
  void dispose() {
    _nameCtrl.dispose();
    _weightCtrl.dispose();
    _heightCtrl.dispose();
    _ftCtrl.dispose();
    _inCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final userId = Supabase.instance.client.auth.currentUser?.id;
    if (userId == null) return;
    final isImperial = UnitSystemScope.of(context).isImperial;

    setState(() { _loading = true; _error = null; });
    try {
      double? weightKg;
      double? heightCm;

      if (isImperial) {
        final lbs = double.tryParse(_weightCtrl.text);
        if (lbs != null) weightKg = Units.lbsToKg(lbs);
        final ft = int.tryParse(_ftCtrl.text) ?? 0;
        final inches = int.tryParse(_inCtrl.text) ?? 0;
        if (ft > 0 || inches > 0) heightCm = Units.ftInToCm(ft, inches);
      } else {
        weightKg = double.tryParse(_weightCtrl.text);
        heightCm = double.tryParse(_heightCtrl.text);
      }

      final supabase = Supabase.instance.client;

      await supabase.from('profiles').upsert({
        'id':        userId,
        'name':      _nameCtrl.text.trim(),
        'weight_kg': weightKg,
        'height_cm': heightCm,
        'goal':      _goal,
      });

      final defaults = await supabase
          .from('machines')
          .select('id')
          .eq('is_default', true) as List;

      if (defaults.isNotEmpty) {
        await supabase.from('scanned_machines').upsert(
          defaults.map((m) => {
            'user_id':    userId,
            'machine_id': m['id'] as int,
          }).toList(),
          onConflict: 'user_id,machine_id',
          ignoreDuplicates: true,
        );
      }

      if (mounted) context.go(AppRoutes.home);
    } on PostgrestException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final isImperial = UnitSystemScope.of(context).isImperial;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 36),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 64),
              const AuthHeader(title: 'PROFILE'),
              const SizedBox(height: 48),
              TermField(
                label: isImperial ? 'weight  lbs' : 'weight  kg',
                controller: _weightCtrl,
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 16),
              if (isImperial)
                Row(
                  children: [
                    Expanded(
                      child: TermField(
                        label: 'height  ft',
                        controller: _ftCtrl,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                    const SizedBox(width: 12),
                    SizedBox(
                      width: 80,
                      child: TermField(
                        label: 'in',
                        controller: _inCtrl,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ],
                )
              else
                TermField(
                  label: 'height  cm',
                  controller: _heightCtrl,
                  keyboardType: TextInputType.number,
                ),
              const SizedBox(height: 16),
              TermField(label: 'name', controller: _nameCtrl),
              const SizedBox(height: 28),
              const Text(
                'goal',
                style: TextStyle(fontSize: 10, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 2),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: _goals.map((g) {
                  final selected = g == _goal;
                  return GestureDetector(
                    onTap: () => setState(() => _goal = g),
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: selected ? AppColors.textPrimary : AppColors.borderSubtle,
                        ),
                      ),
                      child: Text(
                        g,
                        style: TextStyle(
                          fontSize: 11,
                          fontFamily: 'monospace',
                          letterSpacing: 1.5,
                          color: selected ? AppColors.textPrimary : AppColors.textSecondary,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(fontSize: 12, color: Colors.redAccent, fontFamily: 'monospace')),
              ],
              const SizedBox(height: 32),
              TermButton(label: 'save', loading: _loading, onTap: _submit),
              const SizedBox(height: 48),
            ],
          ),
        ),
      ),
    );
  }
}
