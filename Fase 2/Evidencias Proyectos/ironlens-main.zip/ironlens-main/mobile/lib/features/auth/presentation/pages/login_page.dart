import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../widgets/auth_widgets.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailCtrl    = TextEditingController();
  final _passwordCtrl = TextEditingController();
  bool _loading = false;
  String? _error;

  @override
  void dispose() {
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    setState(() { _loading = true; _error = null; });
    try {
      await Supabase.instance.client.auth.signInWithPassword(
        email: _emailCtrl.text.trim(),
        password: _passwordCtrl.text,
      );
    } on AuthException catch (e) {
      setState(() => _error = e.message);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 36),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 64),
              const AuthHeader(title: 'IRONLENS'),
              const SizedBox(height: 48),
              TermField(label: 'email',    controller: _emailCtrl,    keyboardType: TextInputType.emailAddress),
              const SizedBox(height: 16),
              TermField(label: 'password', controller: _passwordCtrl, obscure: true),
              if (_error != null) ...[
                const SizedBox(height: 12),
                Text(_error!, style: const TextStyle(fontSize: 12, color: Colors.redAccent, fontFamily: 'monospace')),
              ],
              const SizedBox(height: 32),
              TermButton(label: 'sign in', loading: _loading, onTap: _submit),
              const Spacer(),
              GestureDetector(
                onTap: () => context.push(AppRoutes.register),
                child: Padding(
                  padding: const EdgeInsets.only(bottom: 32),
                  child: Text(
                    '→  create account',
                    style: TextStyle(fontSize: 12, color: AppColors.textSecondary, fontFamily: 'monospace', letterSpacing: 1),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
