import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/network/api_client.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/units/unit_system.dart';
import '../../../../core/utils/weekday.dart';
import '../../../../core/widgets/ai_thinking.dart';
import '../../../../core/widgets/confirm_dialog.dart';
import '../../../../core/widgets/pressable.dart';
import '../../../navi/presentation/navi_scope.dart';

// ── Data classes ──────────────────────────────────────────────

class _RoutineExercise {
  const _RoutineExercise({
    required this.machineId,
    required this.machineName,
    required this.muscleGroup,
    required this.sets,
    required this.repsRange,
    required this.orderIndex,
    this.suggestedWeightKg,
  });
  final int     machineId;
  final String  machineName;
  final String  muscleGroup;
  final int     sets;
  final String  repsRange;
  final int     orderIndex;
  final double? suggestedWeightKg;
}

enum _DayStatus { done, inProgress, today, missed, upcoming }

class _RoutineDay {
  const _RoutineDay({
    required this.id,
    required this.dayOfWeek,
    required this.dayLabel,
    required this.exercises,
    required this.orderIndex,
    this.isCompleted = false,
    this.isInProgress = false,
    this.scheduledDate,
  });
  final String                 id;
  final String                 dayOfWeek;
  final String                 dayLabel;
  final List<_RoutineExercise> exercises;
  final int                    orderIndex;
  final bool                   isCompleted;
  final bool                   isInProgress; // has an unfinished attempt with logged sets
  final DateTime?              scheduledDate;

  // In-progress work always wins — resuming what's already started is more
  // actionable than a date-based label, regardless of whether that date
  // has since passed (validated with the user).
  _DayStatus get status {
    if (isCompleted)  return _DayStatus.done;
    if (isInProgress) return _DayStatus.inProgress;
    final d = scheduledDate;
    if (d == null) return _DayStatus.upcoming; // no date yet (older routine) — neutral
    final today = DateTime.now();
    final todayDate = DateTime(today.year, today.month, today.day);
    if (d.isAtSameMomentAs(todayDate)) return _DayStatus.today;
    if (d.isBefore(todayDate)) return _DayStatus.missed;
    return _DayStatus.upcoming;
  }
}

// ── Page ──────────────────────────────────────────────────────

class RoutinePage extends StatefulWidget {
  const RoutinePage({this.autoRegen = false, super.key});

  /// When true (set by Navi's `regen_routine` action), regenerate immediately
  /// without the confirmation dialog — the intent was already explicit.
  final bool autoRegen;

  @override
  State<RoutinePage> createState() => _RoutinePageState();
}

class _RoutinePageState extends State<RoutinePage> with RouteAware {
  List<_RoutineDay> _days       = [];
  bool              _loading    = true;
  bool              _generating = false;
  bool              _hasFailed  = false;

  DateTime get _weekStartDate {
    final now = DateTime.now();
    return DateTime(now.year, now.month, now.day - (now.weekday - 1));
  }

  String get _weekStartStr {
    final monday = _weekStartDate;
    return '${monday.year}-${monday.month.toString().padLeft(2, '0')}-${monday.day.toString().padLeft(2, '0')}';
  }

  @override
  void initState() {
    super.initState();
    if (widget.autoRegen) {
      _generate(); // skip dialog: triggered explicitly from Navi
    } else {
      _load();
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route is PageRoute) naviRouteObserver.subscribe(this, route);
  }

  /// GoRouter can reuse this page's State (matching key) instead of
  /// recreating it when navigating back here — e.g. RoutineExecutionPage's
  /// `context.go(AppRoutes.routine)` after finishing. When that happens,
  /// initState never re-runs, so _days would keep showing stale status.
  /// didPopNext fires on "became visible again" regardless of whether the
  /// State was fresh or reused, so refreshing here is reliable either way.
  @override
  void didPopNext() => _load();

  @override
  void dispose() {
    naviRouteObserver.unsubscribe(this);
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;
    if (userId == null) { setState(() => _loading = false); return; }

    final routineRow = await supabase
        .from('routines')
        .select('id, week_start')
        .eq('user_id', userId)
        .maybeSingle();

    // Generate if no routine exists or it belongs to a previous week
    if (routineRow == null || (routineRow['week_start'] as String) != _weekStartStr) {
      await _generate();
      return;
    }

    await _loadDays(routineRow['id'] as String);
    if (mounted) setState(() => _loading = false);
  }

  Future<void> _loadDays(String routineId) async {
    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;

    final rawDays = (await supabase
        .from('routine_days')
        .select('id, day_of_week, day_label, order_index, scheduled_date, routine_exercises(machine_id, sets, reps_range, suggested_weight_kg, order_index, machines(name, muscle_group))')
        .eq('routine_id', routineId)
        .order('order_index', ascending: true)) as List;

    // Find which days have a completed log this week
    Set<String> completedDayIds = {};
    // Find which days have an unfinished attempt with real logged work —
    // an empty routine_logs row (created then immediately abandoned) does
    // NOT count, so it stays indistinguishable from "never touched".
    Set<String> inProgressDayIds = {};
    if (userId != null && rawDays.isNotEmpty) {
      final dayIds = rawDays.map((d) => d['id'] as String).toList();
      final logs = (await supabase
          .from('routine_logs')
          .select('routine_day_id, ended_at, routine_log_items(id)')
          .eq('user_id', userId)
          .inFilter('routine_day_id', dayIds)) as List;
      for (final l in logs) {
        final dayId = l['routine_day_id'] as String;
        if (l['ended_at'] != null) {
          completedDayIds.add(dayId);
        } else if ((l['routine_log_items'] as List).isNotEmpty) {
          inProgressDayIds.add(dayId);
        }
      }
    }

    _days = rawDays.map((d) {
      final exRaw = (d['routine_exercises'] as List)
        ..sort((a, b) => (a['order_index'] as int).compareTo(b['order_index'] as int));
      final rawDate = d['scheduled_date'] as String?;
      final dayId   = d['id'] as String;
      return _RoutineDay(
        id:            dayId,
        dayOfWeek:     d['day_of_week'] as String,
        dayLabel:      d['day_label']   as String,
        orderIndex:    d['order_index'] as int,
        isCompleted:   completedDayIds.contains(dayId),
        isInProgress:  inProgressDayIds.contains(dayId),
        scheduledDate: rawDate != null ? DateTime.parse(rawDate) : null,
        exercises:     exRaw.map((e) {
          final m = e['machines'] as Map<String, dynamic>;
          return _RoutineExercise(
            machineId:   e['machine_id']   as int,
            machineName:        m['name']                              as String,
            muscleGroup:        m['muscle_group']                      as String,
            sets:               e['sets']                              as int,
            repsRange:          e['reps_range']                        as String,
            orderIndex:         e['order_index']                       as int,
            suggestedWeightKg: (e['suggested_weight_kg'] as num?)?.toDouble(),
          );
        }).toList(),
      );
    }).toList();
  }

  Future<void> _generate() async {
    setState(() { _loading = false; _generating = true; _hasFailed = false; });
    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;
    if (userId == null) { setState(() => _generating = false); return; }

    try {
      final profile = await supabase
          .from('profiles')
          .select()
          .eq('id', userId)
          .maybeSingle();

      final since = DateTime.now().subtract(const Duration(days: 30));
      final weightLogs = await supabase
          .from('weight_logs')
          .select('weight_kg, logged_at')
          .eq('user_id', userId)
          .gte('logged_at', since.toIso8601String())
          .order('logged_at', ascending: true) as List;

      final weightHistory = weightLogs.map((w) => {
            'weight_kg': w['weight_kg'],
            'logged_at': (w['logged_at'] as String).substring(0, 10),
          }).toList();

      final sessionRows = await supabase
          .from('workout_sessions')
          .select('machine_id, started_at, machines(name), workout_sets(reps, weight_kg)')
          .eq('user_id', userId)
          .gte('started_at', since.toIso8601String()) as List;

      final Map<int, Map<String, dynamic>> mMap = {};
      for (final s in sessionRows) {
        final mid  = s['machine_id'] as int?;
        if (mid == null) continue;
        final name = (s['machines'] as Map<String, dynamic>?)?['name'] as String? ?? '';
        final sets = s['workout_sets'] as List;
        if (sets.isEmpty) continue;
        mMap.putIfAbsent(mid, () => {
          'machine_id': mid, 'name': name, 'sessions_count': 0,
          '_w': <double>[], '_r': <int>[],
          'last_used': (s['started_at'] as String).substring(0, 10),
        });
        mMap[mid]!['sessions_count'] = (mMap[mid]!['sessions_count'] as int) + 1;
        for (final set in sets) {
          final w = (set['weight_kg'] as num?)?.toDouble();
          final r = set['reps'] as int?;
          if (w != null) (mMap[mid]!['_w'] as List<double>).add(w);
          if (r != null) (mMap[mid]!['_r'] as List<int>).add(r);
        }
      }
      final machineHistory = mMap.values.map((m) {
        final ws = m['_w'] as List<double>;
        final rs = m['_r'] as List<int>;
        return {
          'machine_id':     m['machine_id'],
          'name':           m['name'],
          'sessions_count': m['sessions_count'],
          'max_weight_kg':  ws.isEmpty ? null : ws.reduce((a, b) => a > b ? a : b),
          'avg_weight_kg':  ws.isEmpty ? null : ws.reduce((a, b) => a + b) / ws.length,
          'avg_reps':       rs.isEmpty ? null : rs.reduce((a, b) => a + b) / rs.length,
          'last_used':      m['last_used'],
        };
      }).toList();

      final rawDays = (await ApiClient.post('/generate-routine', {
        'week_start': _weekStartStr,
        'profile': {
          'goal':            profile?['goal'],
          'weight_kg':       profile?['weight_kg'],
          'height_cm':       profile?['height_cm'],
          'training_days':   profile?['training_days'] ?? ['monday', 'wednesday', 'friday'],
          'medical_notes':   profile?['medical_notes'],
          'weight_history':  weightHistory,
          'machine_history': machineHistory,
        },
      }))['days'] as List;

      await _saveRoutine(userId, rawDays, machineHistory);
      final routineRow = await supabase
          .from('routines')
          .select('id')
          .eq('user_id', userId)
          .single();
      await _loadDays(routineRow['id'] as String);
      if (mounted) setState(() {});
    } catch (_) {
      if (mounted) setState(() => _hasFailed = true);
    } finally {
      if (mounted) setState(() => _generating = false);
    }
  }

  Future<void> _regen() async {
    final confirmed = await showConfirmDialog(
      context,
      title: 'regenerate routine',
      message: 'this will replace your current week routine',
    );
    if (!confirmed) return;
    setState(() { _days = []; _hasFailed = false; });
    await _generate();
  }

  Future<void> _saveRoutine(
    String userId,
    List rawDays,
    List<Map<String, dynamic>> machineHistory,
  ) async {
    final supabase = Supabase.instance.client;

    // Delete old routine — cascade removes days + exercises
    await supabase.from('routines').delete().eq('user_id', userId);

    final routineRow = await supabase
        .from('routines')
        .insert({'user_id': userId, 'week_start': _weekStartStr})
        .select('id')
        .single();
    final routineId = routineRow['id'] as String;

    for (final day in rawDays) {
      day as Map<String, dynamic>;
      // order_index and scheduled_date are both derived from the weekday
      // itself — never from the AI response's array position, which isn't
      // guaranteed chronological.
      final dow = day['day_of_week'] as String;
      final scheduledDate = _weekStartDate.add(Duration(days: weekdayIndex(dow)));
      final dayRow = await supabase
          .from('routine_days')
          .insert({
            'routine_id':     routineId,
            'day_of_week':    dow,
            'day_label':      day['day_label'],
            'order_index':    weekdayIndex(dow),
            'scheduled_date': '${scheduledDate.year}-${scheduledDate.month.toString().padLeft(2, '0')}-${scheduledDate.day.toString().padLeft(2, '0')}',
          })
          .select('id')
          .single();
      final dayId = dayRow['id'] as String;

      final exercises = day['exercises'] as List;
      if (exercises.isEmpty) continue;
      await supabase.from('routine_exercises').insert(
        List.generate(exercises.length, (j) {
          final e = exercises[j] as Map<String, dynamic>;
          return {
            'routine_day_id':      dayId,
            'machine_id':          e['machine_id'],
            'sets':                e['sets'],
            'reps_range':          e['reps_range'],
            'suggested_weight_kg': e['suggested_weight_kg'],
            'order_index':         j,
          };
        }),
      );
    }

    // Upsert user_machine_stats — recommended = suggested by AI, safe_max = personal best * 1.15
    final maxWeightMap = <int, double?>{
      for (final m in machineHistory)
        m['machine_id'] as int: (m['max_weight_kg'] as num?)?.toDouble(),
    };

    final Map<int, double?> recommendedMap = {};
    for (final day in rawDays) {
      for (final e in (day as Map<String, dynamic>)['exercises'] as List) {
        final mid       = e['machine_id'] as int;
        final suggested = (e['suggested_weight_kg'] as num?)?.toDouble();
        if (suggested != null) {
          final current = recommendedMap[mid];
          if (current == null || suggested > current) recommendedMap[mid] = suggested;
        }
      }
    }

    final allMachineIds = <int>{
      for (final day in rawDays)
        for (final e in (day as Map<String, dynamic>)['exercises'] as List)
          e['machine_id'] as int,
    };

    final now     = DateTime.now().toUtc().toIso8601String();
    final upserts = allMachineIds
        .map((mid) {
          final recommended = recommendedMap[mid];
          final maxWeight   = maxWeightMap[mid];
          final safeMax     = maxWeight != null
              ? double.parse((maxWeight * 1.15).toStringAsFixed(1))
              : null;
          return {
            'user_id':               userId,
            'machine_id':            mid,
            'recommended_weight_kg': recommended,
            'safe_max_weight_kg':    safeMax,
            'computed_at':           now,
          };
        })
        .where((e) =>
            e['recommended_weight_kg'] != null || e['safe_max_weight_kg'] != null)
        .toList();

    if (upserts.isNotEmpty) {
      await supabase.from('user_machine_stats').upsert(upserts);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(onRegen: _days.isNotEmpty ? _regen : null),
            if (_loading || _generating)
              Expanded(child: _LoadingState(generating: _generating))
            else if (_days.isEmpty)
              Expanded(child: _EmptyState(onGenerate: _hasFailed ? _generate : null))
            else
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 32),
                  children: [
                    const SizedBox(height: 32),
                    _WeekHeader(weekStart: _weekStartStr),
                    const SizedBox(height: 24),
                    ..._days.map((day) => Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: _DayCard(day: day),
                        )),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({this.onRegen});
  final VoidCallback? onRegen;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          Pressable(
            onTap: () => context.go(AppRoutes.home),
            child: const Text('← back',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace')),
          ),
          const Spacer(),
          if (onRegen != null)
            Pressable(
              onTap: onRegen,
              child: const Text('[ regen ]',
                  style: TextStyle(
                      fontSize: 12,
                      color: AppColors.textSecondary,
                      fontFamily: 'monospace')),
            )
          else
            const Text('routine',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ── Week header ───────────────────────────────────────────────

class _WeekHeader extends StatelessWidget {
  const _WeekHeader({required this.weekStart});
  final String weekStart;

  String get _label {
    final parts = weekStart.split('-');
    if (parts.length < 3) return weekStart;
    return '${parts[2]}/${parts[1]}/${parts[0]}';
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('ROUTINE',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w200,
              color: AppColors.textPrimary,
              letterSpacing: 8,
              fontFamily: 'monospace',
            )),
        const SizedBox(height: 6),
        Text('// week of $_label',
            style: const TextStyle(
                fontSize: 10,
                color: AppColors.textSecondary,
                fontFamily: 'monospace',
                letterSpacing: 1)),
      ],
    );
  }
}

// ── Day card ──────────────────────────────────────────────────

Color _statusColor(_DayStatus status) => switch (status) {
      _DayStatus.done       => AppColors.green,
      _DayStatus.inProgress => AppColors.teal,
      _DayStatus.today      => AppColors.yellow,
      _DayStatus.missed     => AppColors.red,
      _DayStatus.upcoming   => AppColors.textSecondary,
    };

class _DayCard extends StatelessWidget {
  const _DayCard({required this.day});
  final _RoutineDay day;

  @override
  Widget build(BuildContext context) {
    final status = day.status;
    final done   = status == _DayStatus.done;
    final color  = _statusColor(status);
    // Upcoming stays visually neutral — only today/missed/done get a tinted
    // card, so the week doesn't turn into a wall of grey chips.
    final tinted = status != _DayStatus.upcoming;

    return Container(
      decoration: BoxDecoration(
        color: tinted ? color.withAlpha(8) : AppColors.surface,
        border: Border.all(color: tinted ? color.withAlpha(60) : AppColors.borderSubtle),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Day header
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 10),
            child: Row(
              children: [
                _WeekdayChip(dayOfWeek: day.dayOfWeek, color: color),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    day.dayLabel.toUpperCase(),
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: tinted ? color : AppColors.textPrimary,
                      letterSpacing: 2,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                if (done)
                  Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.check_circle_outline, size: 12, color: color),
                      const SizedBox(width: 4),
                      Text('done',
                          style: TextStyle(
                              fontSize: 9,
                              color: color,
                              fontFamily: 'monospace',
                              letterSpacing: 1)),
                    ],
                  )
                else if (status == _DayStatus.inProgress)
                  Text('in progress',
                      style: TextStyle(
                          fontSize: 9,
                          color: color,
                          fontFamily: 'monospace',
                          letterSpacing: 1))
                else if (status == _DayStatus.today)
                  Text('today',
                      style: TextStyle(
                          fontSize: 9,
                          color: color,
                          fontFamily: 'monospace',
                          letterSpacing: 1))
                else if (status == _DayStatus.missed)
                  Text('missed',
                      style: TextStyle(
                          fontSize: 9,
                          color: color,
                          fontFamily: 'monospace',
                          letterSpacing: 1))
                else
                  Text('${day.exercises.length} exercises',
                      style: const TextStyle(
                          fontSize: 9,
                          color: AppColors.textSecondary,
                          fontFamily: 'monospace')),
              ],
            ),
          ),
          const Divider(height: 1, color: AppColors.borderSubtle),
          // Exercises
          ...day.exercises.map((ex) => _ExerciseRow(exercise: ex, muted: done)),
          // Breathing room so the last exercise isn't glued to the action button.
          const SizedBox(height: 12),
          // Action button
          Pressable(
            onTap: () => context.push(AppRoutes.routineExecution, extra: {
              'routineDayId': day.id,
              'dayLabel':     day.dayLabel,
            }),
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 11),
              decoration: const BoxDecoration(
                border:
                    Border(top: BorderSide(color: AppColors.borderSubtle)),
              ),
              child: Center(
                child: Text(
                  done
                      ? 'redo  →'
                      : status == _DayStatus.inProgress
                          ? 'resume  →'
                          : 'start  →',
                  style: TextStyle(
                    fontSize: 11,
                    color: done
                        ? AppColors.textSecondary
                        : status == _DayStatus.inProgress
                            ? AppColors.teal
                            : AppColors.primary,
                    fontFamily: 'monospace',
                    letterSpacing: 2,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Weekday chip ──────────────────────────────────────────────

/// Small colored chip showing the 3-letter weekday (MON, TUE, ...), so a
/// routine card reads as "this day, this status" at a glance.
class _WeekdayChip extends StatelessWidget {
  const _WeekdayChip({required this.dayOfWeek, required this.color});
  final String dayOfWeek;
  final Color  color;

  @override
  Widget build(BuildContext context) {
    final label = dayOfWeek.length >= 3
        ? dayOfWeek.substring(0, 3).toUpperCase()
        : dayOfWeek.toUpperCase();
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
      decoration: BoxDecoration(
        color: color.withAlpha(20),
        border: Border.all(color: color.withAlpha(120)),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 9,
          fontWeight: FontWeight.w700,
          color: color,
          fontFamily: 'monospace',
          letterSpacing: 1,
        ),
      ),
    );
  }
}

// ── Exercise row ──────────────────────────────────────────────

class _ExerciseRow extends StatelessWidget {
  const _ExerciseRow({required this.exercise, this.muted = false});
  final _RoutineExercise exercise;
  final bool             muted;

  @override
  Widget build(BuildContext context) {
    final nameColor = muted ? AppColors.textSecondary : AppColors.textPrimary;
    final metaColor = muted ? AppColors.textSecondary : AppColors.primary;

    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(exercise.machineName,
                    style: TextStyle(
                        fontSize: 13,
                        color: nameColor,
                        fontWeight: FontWeight.w500)),
                const SizedBox(height: 2),
                _MuscleTag(exercise.muscleGroup, muted: muted),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '${exercise.sets} × ${exercise.repsRange}',
                style: TextStyle(
                    fontSize: 12,
                    color: metaColor,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w500),
              ),
              if (exercise.suggestedWeightKg != null) ...[
                const SizedBox(height: 3),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    border: Border.all(
                      color: muted
                          ? AppColors.borderSubtle.withAlpha(80)
                          : AppColors.borderSubtle,
                    ),
                  ),
                  child: Text(
                    Units.formatWeight(context, exercise.suggestedWeightKg),
                    style: TextStyle(
                      fontSize: 9,
                      color: muted ? AppColors.primary.withAlpha(120) : AppColors.primary,
                      fontFamily: 'monospace',
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ],
            ],
          ),
        ],
      ),
    );
  }
}

// ── Muscle tag ────────────────────────────────────────────────

class _MuscleTag extends StatelessWidget {
  const _MuscleTag(this.label, {this.muted = false});
  final String label;
  final bool   muted;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
      decoration: BoxDecoration(
        border: Border.all(
          color: muted
              ? AppColors.borderSubtle.withAlpha(80)
              : AppColors.borderSubtle,
        ),
      ),
      child: Text(label.toLowerCase(),
          style: TextStyle(
              fontSize: 9,
              color: muted
                  ? AppColors.textSecondary.withAlpha(100)
                  : AppColors.textSecondary,
              fontFamily: 'monospace',
              letterSpacing: 0.5)),
    );
  }
}

// ── Loading / generating states ───────────────────────────────

class _LoadingState extends StatelessWidget {
  const _LoadingState({required this.generating});
  final bool generating;

  @override
  Widget build(BuildContext context) {
    if (generating) {
      return const AiThinking(messages: [
        'reading your profile',
        'analyzing training history',
        'balancing muscle groups',
        'setting weights & reps',
        'generating your week',
      ]);
    }
    return const Center(
      child: SizedBox(
        width: 20,
        height: 20,
        child: CircularProgressIndicator(
            strokeWidth: 1.5, color: AppColors.textSecondary),
      ),
    );
  }
}

// ── Empty state ───────────────────────────────────────────────

class _EmptyState extends StatelessWidget {
  const _EmptyState({this.onGenerate});
  final VoidCallback? onGenerate;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Text(
            '// could not generate routine\n// check your connection and try again',
            textAlign: TextAlign.center,
            style: TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
                fontFamily: 'monospace',
                height: 1.8),
          ),
          if (onGenerate != null) ...[
            const SizedBox(height: 24),
            Pressable(
              onTap: onGenerate,
              highlightBorder: true,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                decoration: BoxDecoration(
                  border: Border.all(color: AppColors.primary),
                ),
                child: const Text('[ generate ]',
                    style: TextStyle(
                        fontSize: 11,
                        color: AppColors.primary,
                        fontFamily: 'monospace',
                        letterSpacing: 1)),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
