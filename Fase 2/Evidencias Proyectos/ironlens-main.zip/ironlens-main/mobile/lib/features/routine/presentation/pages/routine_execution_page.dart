import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../../../core/units/unit_system.dart';
import '../../../navi/presentation/navi_scope.dart';
import '../../../workout/providers/sessions_provider.dart';

// ── Status enum ───────────────────────────────────────────────

enum _ExStatus { pending, done, skipped }

// ── Single logged set ─────────────────────────────────────────

class _LoggedSet {
  const _LoggedSet({required this.setNumber, required this.reps, this.weightKg});
  final int     setNumber;
  final int     reps;
  final double? weightKg;
}

// ── Per-exercise mutable state ────────────────────────────────

class _ExState {
  _ExState({
    required this.exerciseId,
    required this.machineId,
    required this.machineName,
    required this.muscleGroup,
    required this.targetSets,
    required this.repsRange,
    this.suggestedWeightKg,
    this.safeMaxWeightKg,
  })  : weightCtrl = TextEditingController(),
        repsCtrl   = TextEditingController();

  final String  exerciseId;
  final int     machineId;
  final String  machineName;
  final String  muscleGroup;
  final int     targetSets;
  final String  repsRange;
  final double? suggestedWeightKg;
  final double? safeMaxWeightKg;
  final TextEditingController weightCtrl;
  final TextEditingController repsCtrl;

  _ExStatus            status    = _ExStatus.pending;
  bool                 saving    = false;
  bool                 addingSet = false;
  String?              sessionId;
  String?              logItemId; // routine_log_items row — created on first set, resumed on re-entry
  final List<_LoggedSet> loggedSets = [];

  void dispose() {
    weightCtrl.dispose();
    repsCtrl.dispose();
  }
}

// ── Page ──────────────────────────────────────────────────────

class RoutineExecutionPage extends ConsumerStatefulWidget {
  const RoutineExecutionPage({
    required this.routineDayId,
    required this.dayLabel,
    super.key,
  });

  final String routineDayId;
  final String dayLabel;

  @override
  ConsumerState<RoutineExecutionPage> createState() =>
      _RoutineExecutionPageState();
}

class _RoutineExecutionPageState extends ConsumerState<RoutineExecutionPage> {
  List<_ExState> _exercises = [];
  String?        _logId;
  bool           _loading   = true;
  bool           _finishing = false;
  int?           _expanded;

  @override
  void initState() {
    super.initState();
    _init();
  }

  @override
  void dispose() {
    for (final ex in _exercises) {
      ex.dispose();
    }
    super.dispose();
  }

  int get _doneCount =>
      _exercises.where((e) => e.status == _ExStatus.done).length;

  int get _actedCount =>
      _exercises.where((e) => e.status != _ExStatus.pending).length;

  /// The machine Navi should treat as active: the next exercise still to do,
  /// or the last one once everything is done. Updates as exercises complete.
  int? get _activeMachineId {
    for (final e in _exercises) {
      if (e.status != _ExStatus.done) return e.machineId;
    }
    return _exercises.isNotEmpty ? _exercises.last.machineId : null;
  }

  Future<void> _init() async {
    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;
    if (userId == null) { setState(() => _loading = false); return; }

    final raw = (await supabase
        .from('routine_exercises')
        .select('id, machine_id, sets, reps_range, suggested_weight_kg, order_index, machines(name, muscle_group)')
        .eq('routine_day_id', widget.routineDayId)
        .order('order_index', ascending: true)) as List;

    final dayRow = await supabase
        .from('routine_days')
        .select('routine_id')
        .eq('id', widget.routineDayId)
        .single();

    // Resume an unfinished attempt for this day if one exists, instead of
    // always starting a fresh routine_logs row. Without this, leaving
    // mid-workout and coming back would silently orphan the earlier
    // session (never closed — still counted as "active" on Home) and
    // create a duplicate routine_logs row on top of it.
    final existingLog = await supabase
        .from('routine_logs')
        .select('id')
        .eq('routine_day_id', widget.routineDayId)
        .eq('user_id', userId)
        .isFilter('ended_at', null)
        .order('started_at', ascending: false)
        .limit(1)
        .maybeSingle();

    String logId;
    final itemsByExercise = <String, Map<String, dynamic>>{};
    if (existingLog != null) {
      logId = existingLog['id'] as String;
      final items = (await supabase
          .from('routine_log_items')
          .select('id, routine_exercise_id, status, session_id, '
              'workout_sessions(workout_sets(set_number, reps, weight_kg))')
          .eq('routine_log_id', logId)) as List;
      for (final item in items) {
        itemsByExercise[item['routine_exercise_id'] as String] =
            item as Map<String, dynamic>;
      }
    } else {
      final logRow = await supabase
          .from('routine_logs')
          .insert({
            'routine_id':     dayRow['routine_id'],
            'user_id':        userId,
            'routine_day_id': widget.routineDayId,
          })
          .select('id')
          .single();
      logId = logRow['id'] as String;
    }

    // Fetch personal safe max for each machine in one query
    final machineIds = raw.map((e) => e['machine_id'] as int).toList();
    Map<int, double?> statsMap = {};
    if (machineIds.isNotEmpty) {
      final statsRows = await supabase
          .from('user_machine_stats')
          .select('machine_id, safe_max_weight_kg')
          .eq('user_id', userId)
          .inFilter('machine_id', machineIds);
      statsMap = {
        for (final r in statsRows as List)
          (r['machine_id'] as int): (r['safe_max_weight_kg'] as num?)?.toDouble(),
      };
    }

    if (mounted) {
      setState(() {
        _logId = logId;
        _exercises = raw.map((e) {
          final m            = e['machines'] as Map<String, dynamic>;
          final machineId    = e['machine_id'] as int;
          final exerciseId   = e['id'] as String;
          final suggested    = (e['suggested_weight_kg'] as num?)?.toDouble();
          final safeMax      = statsMap[machineId];
          final ex = _ExState(
            exerciseId:        exerciseId,
            machineId:         machineId,
            machineName:       m['name']         as String,
            muscleGroup:       m['muscle_group'] as String,
            targetSets:        e['sets']         as int,
            repsRange:         e['reps_range']   as String,
            suggestedWeightKg: suggested,
            safeMaxWeightKg:   (safeMax != null && (suggested == null || safeMax > suggested))
                                   ? safeMax
                                   : null,
          );

          final item = itemsByExercise[exerciseId];
          if (item != null) {
            ex.logItemId = item['id'] as String;
            ex.sessionId = item['session_id'] as String?;
            final status = item['status'] as String;
            if (status == 'done')    ex.status = _ExStatus.done;
            if (status == 'skipped') ex.status = _ExStatus.skipped;
            final session = item['workout_sessions'] as Map<String, dynamic>?;
            final sets = (session?['workout_sets'] as List?) ?? const [];
            for (final s in sets) {
              ex.loggedSets.add(_LoggedSet(
                setNumber: s['set_number'] as int,
                reps:      s['reps']       as int,
                weightKg:  (s['weight_kg'] as num?)?.toDouble(),
              ));
            }
            ex.loggedSets.sort((a, b) => a.setNumber.compareTo(b.setNumber));
          }
          return ex;
        }).toList();
        _loading = false;
      });
    }
  }

  // Creates workout_session lazily on first set; inserts set immediately to DB.
  Future<void> _addSet(int idx) async {
    final ex   = _exercises[idx];
    final reps = int.tryParse(ex.repsCtrl.text.trim());
    if (reps == null || reps <= 0) return;
    final weight = Units.parseWeightInput(context, ex.weightCtrl.text.trim());

    final supabase = Supabase.instance.client;
    final userId   = supabase.auth.currentUser?.id;
    if (userId == null) return;

    setState(() => ex.addingSet = true);
    try {
      if (ex.sessionId == null) {
        final row = await supabase
            .from('workout_sessions')
            .insert({'user_id': userId, 'machine_id': ex.machineId})
            .select('id')
            .single();
        ex.sessionId = row['id'] as String;

        // Record the attempt as 'pending' immediately (not just on "done →")
        // so re-entering this day can find and resume it instead of
        // orphaning the session and starting a duplicate one.
        final itemRow = await supabase.from('routine_log_items').insert({
          'routine_log_id':      _logId,
          'routine_exercise_id': ex.exerciseId,
          'session_id':          ex.sessionId,
          'status':              'pending',
        }).select('id').single();
        ex.logItemId = itemRow['id'] as String;
      }

      final setNumber = ex.loggedSets.length + 1;
      await supabase.from('workout_sets').insert({
        'session_id': ex.sessionId,
        'machine_id': ex.machineId,
        'set_number': setNumber,
        'reps':       reps,
        'weight_kg':  weight,
      });

      if (mounted) {
        setState(() {
          ex.loggedSets.add(_LoggedSet(
            setNumber: setNumber,
            reps:      reps,
            weightKg:  weight,
          ));
          ex.repsCtrl.clear(); // keep weight pre-filled for next set
        });
      }
    } finally {
      if (mounted) setState(() => ex.addingSet = false);
    }
  }

  // Closes the session and marks routine_log_item as done.
  Future<void> _markDone(int idx) async {
    final ex = _exercises[idx];
    if (ex.loggedSets.isEmpty || _logId == null) return;

    final supabase = Supabase.instance.client;
    setState(() => ex.saving = true);
    try {
      await supabase
          .from('workout_sessions')
          .update({'ended_at': DateTime.now().toUtc().toIso8601String()})
          .eq('id', ex.sessionId!);

      if (ex.logItemId != null) {
        await supabase
            .from('routine_log_items')
            .update({'status': 'done'})
            .eq('id', ex.logItemId!);
      }

      if (mounted) {
        setState(() {
          ex.status = _ExStatus.done;
          ex.saving = false;
          _expanded = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => ex.saving = false);
    }
  }

  // Only callable when no sets have been logged yet.
  Future<void> _markSkipped(int idx) async {
    final ex = _exercises[idx];
    if (ex.loggedSets.isNotEmpty || _logId == null) return;
    setState(() => ex.saving = true);
    try {
      await Supabase.instance.client.from('routine_log_items').insert({
        'routine_log_id':      _logId,
        'routine_exercise_id': ex.exerciseId,
        'status':              'skipped',
      });
      if (mounted) {
        setState(() {
          ex.status = _ExStatus.skipped;
          ex.saving = false;
          if (_expanded == idx) _expanded = null;
        });
      }
    } catch (_) {
      if (mounted) setState(() => ex.saving = false);
    }
  }

  Future<void> _finish() async {
    if (_logId == null) { context.go(AppRoutes.routine); return; }
    setState(() => _finishing = true);
    try {
      final supabase = Supabase.instance.client;
      final now = DateTime.now().toUtc().toIso8601String();

      // Close any sessions started but not explicitly marked done
      for (final ex in _exercises) {
        if (ex.sessionId != null && ex.status == _ExStatus.pending) {
          await supabase
              .from('workout_sessions')
              .update({'ended_at': now})
              .eq('id', ex.sessionId!);
          if (ex.logItemId != null) {
            await supabase
                .from('routine_log_items')
                .update({'status': 'done'})
                .eq('id', ex.logItemId!);
          }
        }
      }

      final completedCount = _exercises
          .where((e) => e.status == _ExStatus.done || e.loggedSets.isNotEmpty)
          .length;
      final pct = _exercises.isEmpty ? 0.0 : completedCount / _exercises.length;

      await supabase
          .from('routine_logs')
          .update({'ended_at': now, 'completed_pct': pct})
          .eq('id', _logId!);

      ref.invalidate(activeSessionsCountProvider);
    } finally {
      if (mounted) context.go(AppRoutes.routine);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scaffold = Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _TopBar(dayLabel: widget.dayLabel),
            if (_loading)
              const Expanded(
                child: Center(
                  child: SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 1.5, color: AppColors.textSecondary),
                  ),
                ),
              )
            else ...[
              _ProgressBar(done: _doneCount, total: _exercises.length),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
                  itemCount: _exercises.length,
                  itemBuilder: (context, i) => _ExerciseCard(
                    ex:       _exercises[i],
                    index:    i,
                    expanded: _expanded == i,
                    onTap:    () => setState(() =>
                        _expanded = _expanded == i ? null : i),
                    onAddSet: () => _addSet(i),
                    onDone:   () => _markDone(i),
                    onSkip:   () => _markSkipped(i),
                  ),
                ),
              ),
              _FinishButton(
                actedCount: _actedCount,
                total:      _exercises.length,
                finishing:  _finishing,
                onTap:      _finish,
              ),
            ],
          ],
        ),
      ),
    );

    // Always mount NaviScope — only activeMachineId varies (null while
    // exercises are still loading). Conditionally swapping the root widget
    // instead risks framework element bookkeeping bugs on rapid navigation.
    return NaviScope(activeMachineId: _activeMachineId, child: scaffold);
  }
}

// ── Top bar ───────────────────────────────────────────────────

class _TopBar extends StatelessWidget {
  const _TopBar({required this.dayLabel});
  final String dayLabel;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          GestureDetector(
            onTap: () => context.go(AppRoutes.routine),
            child: const Text('← routine',
                style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSecondary,
                    fontFamily: 'monospace')),
          ),
          const Spacer(),
          const Text('execution',
              style: TextStyle(
                  fontSize: 12,
                  color: AppColors.textSecondary,
                  fontFamily: 'monospace')),
        ],
      ),
    );
  }
}

// ── Progress bar ──────────────────────────────────────────────

class _ProgressBar extends StatelessWidget {
  const _ProgressBar({required this.done, required this.total});
  final int done;
  final int total;

  @override
  Widget build(BuildContext context) {
    final pct = total == 0 ? 0.0 : done / total;
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                '$done / $total',
                style: const TextStyle(
                    fontSize: 11,
                    color: AppColors.textPrimary,
                    fontFamily: 'monospace',
                    fontWeight: FontWeight.w600),
              ),
              const SizedBox(width: 8),
              const Text('exercises done',
                  style: TextStyle(
                      fontSize: 10,
                      color: AppColors.textSecondary,
                      fontFamily: 'monospace')),
            ],
          ),
          const SizedBox(height: 8),
          LinearProgressIndicator(
            value: pct,
            backgroundColor: AppColors.borderSubtle,
            color: AppColors.green,
            minHeight: 2,
          ),
        ],
      ),
    );
  }
}

// ── Exercise card ─────────────────────────────────────────────

class _ExerciseCard extends StatelessWidget {
  const _ExerciseCard({
    required this.ex,
    required this.index,
    required this.expanded,
    required this.onTap,
    required this.onAddSet,
    required this.onDone,
    required this.onSkip,
  });

  final _ExState     ex;
  final int          index;
  final bool         expanded;
  final VoidCallback onTap;
  final VoidCallback onAddSet;
  final VoidCallback onDone;
  final VoidCallback onSkip;

  @override
  Widget build(BuildContext context) {
    final isDone    = ex.status == _ExStatus.done;
    final isSkipped = ex.status == _ExStatus.skipped;
    final isActed   = isDone || isSkipped;

    return GestureDetector(
      onTap: isActed ? null : onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          color: isDone ? AppColors.green.withAlpha(10) : AppColors.surface,
          border: Border.all(
            color: isDone
                ? AppColors.green.withAlpha(80)
                : isSkipped
                    ? AppColors.borderSubtle.withAlpha(80)
                    : AppColors.borderSubtle,
          ),
        ),
        child: Column(
          children: [
            // Header row
            Padding(
              padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
              child: Row(
                children: [
                  Text(
                    (index + 1).toString().padLeft(2, '0'),
                    style: TextStyle(
                        fontSize: 11,
                        color: isSkipped
                            ? AppColors.textSecondary.withAlpha(80)
                            : AppColors.textSecondary,
                        fontFamily: 'monospace'),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          ex.machineName,
                          style: TextStyle(
                            fontSize: 13,
                            color: isSkipped
                                ? AppColors.textSecondary
                                : AppColors.textPrimary,
                            fontWeight: FontWeight.w500,
                            decoration: isSkipped
                                ? TextDecoration.lineThrough
                                : null,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(ex.muscleGroup.toLowerCase(),
                            style: const TextStyle(
                                fontSize: 9,
                                color: AppColors.textSecondary,
                                fontFamily: 'monospace')),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  if (isDone)
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        const Icon(Icons.check_circle_outline,
                            size: 12, color: AppColors.green),
                        const SizedBox(width: 4),
                        Text('${ex.loggedSets.length} sets',
                            style: const TextStyle(
                                fontSize: 10,
                                color: AppColors.green,
                                fontFamily: 'monospace')),
                      ],
                    )
                  else if (isSkipped)
                    const Text('// skip',
                        style: TextStyle(
                            fontSize: 9,
                            color: AppColors.textSecondary,
                            fontFamily: 'monospace'))
                  else
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          '${ex.targetSets} × ${ex.repsRange}',
                          style: const TextStyle(
                              fontSize: 12,
                              color: AppColors.primary,
                              fontFamily: 'monospace',
                              fontWeight: FontWeight.w500),
                        ),
                        if (ex.suggestedWeightKg != null) ...[
                          const SizedBox(height: 3),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: AppColors.surface,
                              border: Border.all(color: AppColors.borderSubtle),
                            ),
                            child: Text(
                              Units.formatWeight(context, ex.suggestedWeightKg),
                              style: const TextStyle(
                                  fontSize: 9,
                                  color: AppColors.primary,
                                  fontFamily: 'monospace',
                                  letterSpacing: 0.5),
                            ),
                          ),
                        ],
                        if (ex.safeMaxWeightKg != null) ...[
                          const SizedBox(height: 3),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Text('✦ ',
                                  style: TextStyle(
                                      fontSize: 7,
                                      color: AppColors.yellow,
                                      fontFamily: 'monospace')),
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 6, vertical: 2),
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      color: AppColors.yellow.withAlpha(80)),
                                ),
                                child: Text(
                                  'max ${Units.formatWeight(context, ex.safeMaxWeightKg)}',
                                  style: const TextStyle(
                                      fontSize: 9,
                                      color: AppColors.yellow,
                                      fontFamily: 'monospace',
                                      letterSpacing: 0.5),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ],
                    ),
                ],
              ),
            ),

            // Inline logging (expanded, pending only)
            if (expanded && !isActed) ...[
              const Divider(height: 1, color: AppColors.borderSubtle),
              Padding(
                padding: const EdgeInsets.fromLTRB(14, 12, 14, 14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Target reminder
                    Text(
                      '// target: ${ex.targetSets} × ${ex.repsRange}'
                      '${ex.suggestedWeightKg != null ? "  ~${Units.formatWeight(context, ex.suggestedWeightKg)}" : ""}'
                      '${ex.safeMaxWeightKg != null ? "  ✦ max ${Units.formatWeight(context, ex.safeMaxWeightKg)}" : ""}',
                      style: const TextStyle(
                          fontSize: 9,
                          color: AppColors.textSecondary,
                          fontFamily: 'monospace',
                          letterSpacing: 1),
                    ),

                    // Logged sets growing list
                    if (ex.loggedSets.isNotEmpty) ...[
                      const SizedBox(height: 10),
                      ...ex.loggedSets.map((s) => _SetRow(set: s)),
                    ],

                    const SizedBox(height: 12),

                    // Input row + add button
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        _InputField(
                          controller: ex.weightCtrl,
                          label: Units.weightLabel(context),
                          hint: ex.suggestedWeightKg != null
                              ? Units.formatWeightValue(context, ex.suggestedWeightKg!)
                              : 'bw',
                          decimal: true,
                        ),
                        const SizedBox(width: 12),
                        _InputField(
                          controller: ex.repsCtrl,
                          label: 'reps',
                          hint: ex.repsRange,
                          decimal: false,
                        ),
                        const SizedBox(width: 12),
                        GestureDetector(
                          onTap: ex.addingSet ? null : onAddSet,
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 14, vertical: 10),
                            decoration: BoxDecoration(
                              color: AppColors.primary.withAlpha(30),
                              border: Border.all(color: AppColors.primary),
                            ),
                            child: ex.addingSet
                                ? const SizedBox(
                                    width: 14,
                                    height: 14,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 1.5,
                                        color: AppColors.primary))
                                : const Text('+',
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: AppColors.primary,
                                        fontFamily: 'monospace',
                                        fontWeight: FontWeight.w600)),
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 14),

                    // Skip (only when no sets) / Done (only when ≥1 set)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        if (ex.loggedSets.isEmpty)
                          GestureDetector(
                            onTap: ex.saving ? null : onSkip,
                            child: const Padding(
                              padding: EdgeInsets.symmetric(
                                  horizontal: 4, vertical: 8),
                              child: Text('skip',
                                  style: TextStyle(
                                      fontSize: 10,
                                      color: AppColors.textSecondary,
                                      fontFamily: 'monospace',
                                      letterSpacing: 1)),
                            ),
                          ),
                        if (ex.loggedSets.isEmpty) const SizedBox(width: 12),
                        if (ex.saving)
                          const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(
                                  strokeWidth: 1.5,
                                  color: AppColors.textSecondary))
                        else
                          GestureDetector(
                            onTap: ex.loggedSets.isNotEmpty ? onDone : null,
                            child: Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 8),
                              decoration: BoxDecoration(
                                color: ex.loggedSets.isNotEmpty
                                    ? AppColors.green.withAlpha(25)
                                    : AppColors.borderSubtle.withAlpha(20),
                                border: Border.all(
                                  color: ex.loggedSets.isNotEmpty
                                      ? AppColors.green
                                      : AppColors.borderSubtle,
                                ),
                              ),
                              child: Text(
                                'done  →',
                                style: TextStyle(
                                    fontSize: 11,
                                    color: ex.loggedSets.isNotEmpty
                                        ? AppColors.green
                                        : AppColors.textSecondary,
                                    fontFamily: 'monospace',
                                    letterSpacing: 1.5),
                              ),
                            ),
                          ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ── Logged set row ────────────────────────────────────────────

class _SetRow extends StatelessWidget {
  const _SetRow({required this.set});
  final _LoggedSet set;

  @override
  Widget build(BuildContext context) {
    final setNum = set.setNumber.toString().padLeft(2, '0');
    final weight = Units.formatWeight(context, set.weightKg);
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        children: [
          Text(setNum,
              style: const TextStyle(
                  fontSize: 10,
                  color: AppColors.textSecondary,
                  fontFamily: 'monospace')),
          const SizedBox(width: 12),
          Text(weight,
              style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.primary,
                  fontFamily: 'monospace',
                  fontWeight: FontWeight.w500)),
          const SizedBox(width: 12),
          Text('${set.reps} reps',
              style: const TextStyle(
                  fontSize: 12,
                  color: AppColors.textPrimary,
                  fontFamily: 'monospace')),
          const Spacer(),
          const Icon(Icons.check, size: 10, color: AppColors.green),
        ],
      ),
    );
  }
}

// ── Inline input field ────────────────────────────────────────

class _InputField extends StatelessWidget {
  const _InputField({
    required this.controller,
    required this.label,
    required this.hint,
    required this.decimal,
  });

  final TextEditingController controller;
  final String label;
  final String hint;
  final bool   decimal;

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: TextField(
        controller: controller,
        keyboardType: decimal
            ? const TextInputType.numberWithOptions(decimal: true)
            : TextInputType.number,
        inputFormatters: [
          FilteringTextInputFormatter.allow(
              decimal ? RegExp(r'[\d.,]') : RegExp(r'\d')),
        ],
        style: const TextStyle(
            fontSize: 14,
            color: AppColors.textPrimary,
            fontFamily: 'monospace'),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(
              fontSize: 10,
              color: AppColors.textSecondary,
              fontFamily: 'monospace'),
          hintText: hint,
          hintStyle: const TextStyle(
              color: AppColors.textSecondary, fontFamily: 'monospace'),
          isDense: true,
          enabledBorder: const UnderlineInputBorder(
              borderSide: BorderSide(color: AppColors.borderSubtle)),
          focusedBorder: const UnderlineInputBorder(
              borderSide: BorderSide(color: AppColors.textSecondary)),
        ),
      ),
    );
  }
}

// ── Finish button ─────────────────────────────────────────────

class _FinishButton extends StatelessWidget {
  const _FinishButton({
    required this.actedCount,
    required this.total,
    required this.finishing,
    required this.onTap,
  });

  final int          actedCount;
  final int          total;
  final bool         finishing;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final label = actedCount < total
        ? 'finish early  ($actedCount/$total)'
        : 'finish workout';
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
      child: GestureDetector(
        onTap: finishing ? null : onTap,
        child: Container(
          height: 48,
          decoration: BoxDecoration(
            border: Border.all(color: AppColors.borderSubtle),
          ),
          child: Center(
            child: finishing
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                        strokeWidth: 1.5, color: AppColors.textSecondary))
                : Text(
                    label,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: AppColors.textPrimary,
                      fontFamily: 'monospace',
                      letterSpacing: 2,
                    ),
                  ),
          ),
        ),
      ),
    );
  }
}
