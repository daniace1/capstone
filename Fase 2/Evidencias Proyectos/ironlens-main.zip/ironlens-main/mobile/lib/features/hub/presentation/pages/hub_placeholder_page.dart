import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';

class HubPlaceholderPage extends StatelessWidget {
  const HubPlaceholderPage({required this.label, super.key});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Stack(
          children: [
            // Back — top left, same pattern as result page
            Positioned(
              top: 16,
              left: 16,
              child: GestureDetector(
                onTap: () => context.go(AppRoutes.home),
                child: Text(
                  '← back',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.white.withAlpha(120),
                    fontFamily: 'monospace',
                    letterSpacing: 0.5,
                  ),
                ),
              ),
            ),
            // Section label — top right
            Positioned(
              top: 16,
              right: 16,
              child: Text(
                label.toLowerCase(),
                style: TextStyle(
                  fontSize: 13,
                  color: Colors.white.withAlpha(80),
                  fontFamily: 'monospace',
                  letterSpacing: 0.5,
                ),
              ),
            ),
            // Center content
            const Center(
              child: Text(
                '//--',
                style: TextStyle(
                  fontSize: 22,
                  color: Colors.white,
                  fontFamily: 'monospace',
                  letterSpacing: 4,
                  fontWeight: FontWeight.w300,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
