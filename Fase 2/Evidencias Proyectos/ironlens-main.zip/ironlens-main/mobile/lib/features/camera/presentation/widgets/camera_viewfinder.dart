import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

/// Full-screen camera preview. Stretches to fill the available space.
class CameraViewfinder extends StatelessWidget {
  const CameraViewfinder({required this.controller, super.key});

  final CameraController controller;

  @override
  Widget build(BuildContext context) {
    return SizedBox.expand(
      child: FittedBox(
        fit: BoxFit.cover,
        child: SizedBox(
          width: controller.value.previewSize?.height ?? 1,
          height: controller.value.previewSize?.width ?? 1,
          child: CameraPreview(controller),
        ),
      ),
    );
  }
}
