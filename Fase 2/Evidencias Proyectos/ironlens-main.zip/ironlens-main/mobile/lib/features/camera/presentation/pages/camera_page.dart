import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:permission_handler/permission_handler.dart';

import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_theme.dart';
import '../../services/camera_service.dart';
import '../widgets/camera_viewfinder.dart';
import '../widgets/scan_overlay.dart';

class CameraPage extends StatefulWidget {
  const CameraPage({super.key});

  @override
  State<CameraPage> createState() => _CameraPageState();
}

class _CameraPageState extends State<CameraPage> {
  final _cameraService = CameraService();
  _PageState _state = _PageState.loading;
  String? _errorMessage;

  // While scanning we freeze the captured frame and show the sweep overlay.
  bool _scanning = false;
  Uint8List? _captured;

  @override
  void initState() {
    super.initState();
    _initCamera();
  }

  Future<void> _initCamera() async {
    final status = await Permission.camera.request();

    if (!mounted) return;

    if (!status.isGranted) {
      setState(() {
        _state = _PageState.error;
        _errorMessage = 'Camera permission is required.';
      });
      return;
    }

    try {
      await _cameraService.initialize();
      if (!mounted) return;
      setState(() => _state = _PageState.ready);
    } on CameraException catch (e) {
      if (!mounted) return;
      setState(() {
        _state = _PageState.error;
        _errorMessage = e.description ?? 'Failed to initialise camera.';
      });
    }
  }

  Future<void> _capture() async {
    if (_scanning || _state != _PageState.ready) return;

    try {
      final bytes = await _cameraService.capture();
      if (!mounted) return;
      setState(() {
        _captured = bytes;
        _scanning = true;
      });

      final result = await _cameraService.scan(bytes);
      if (!mounted) return;
      context.pushReplacement(AppRoutes.result, extra: result);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _scanning = false;
        _captured = null;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Scan failed. Try again.')),
      );
    }
  }

  @override
  void dispose() {
    _cameraService.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // Live preview, or the frozen frame while scanning.
          if (_scanning && _captured != null)
            Positioned.fill(
              child: Image.memory(_captured!, fit: BoxFit.cover),
            )
          else
            switch (_state) {
              _PageState.loading => const _LoadingView(),
              _PageState.error => _ErrorView(message: _errorMessage ?? ''),
              _PageState.ready => CameraViewfinder(
                  controller: _cameraService.controller!,
                ),
            },

          if (_scanning) const Positioned.fill(child: ScanOverlay()),

          // Capture button — only when ready and not already scanning.
          if (_state == _PageState.ready && !_scanning)
            Positioned(
              left: 0,
              right: 0,
              bottom: 48,
              child: SafeArea(
                child: Center(child: _CaptureButton(onTap: _capture)),
              ),
            ),

          // Back — hidden while scanning to avoid interrupting the request.
          if (!_scanning)
            Positioned(
              bottom: 56,
              right: 24,
              child: SafeArea(
                child: IconButton(
                  icon: const Icon(Icons.arrow_back_ios_new, size: 18),
                  color: AppColors.textPrimary,
                  onPressed: () => context.pop(),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

enum _PageState { loading, ready, error }

class _CaptureButton extends StatelessWidget {
  const _CaptureButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: Colors.white.withAlpha(20),
          border: Border.all(color: AppColors.primary, width: 2),
        ),
        child: Center(
          child: Container(
            width: 52,
            height: 52,
            decoration: const BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.primary,
            ),
            child: const Icon(Icons.center_focus_strong,
                size: 24, color: AppColors.background),
          ),
        ),
      ),
    );
  }
}

class _LoadingView extends StatelessWidget {
  const _LoadingView();

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: SizedBox(
        width: 24,
        height: 24,
        child: CircularProgressIndicator(
          strokeWidth: 1.5,
          color: AppColors.textSecondary,
        ),
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 32),
        child: Text(
          message,
          style: Theme.of(context).textTheme.bodyMedium,
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
