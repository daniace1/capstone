import 'dart:convert';
import 'dart:typed_data';

import 'package:camera/camera.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:http/http.dart' as http;

import '../../../../core/network/api_client.dart';
import '../../result/models/scan_result.dart';

class CameraService {
  CameraController? _controller;

  CameraController? get controller => _controller;

  bool get isInitialized => _controller?.value.isInitialized ?? false;

  Future<void> initialize() async {
    final cameras = await availableCameras();
    if (cameras.isEmpty) {
      throw CameraException('NoCamerasAvailable', 'No cameras found.');
    }

    final back = cameras.firstWhere(
      (c) => c.lensDirection == CameraLensDirection.back,
      orElse: () => cameras.first,
    );

    _controller = CameraController(
      back,
      ResolutionPreset.high,
      enableAudio: false,
      imageFormatGroup: ImageFormatGroup.jpeg,
    );

    await _controller!.initialize();
  }

  /// Captures a single frame and returns its raw JPEG bytes.
  Future<Uint8List> capture() async {
    if (_controller == null) {
      throw CameraException('NotInitialized', 'Camera is not ready.');
    }
    final xFile = await _controller!.takePicture();
    return xFile.readAsBytes();
  }

  /// Compresses [bytes] and posts them to `/scan`. The original frame is kept
  /// for the result preview (full quality); only the upload is compressed.
  Future<ScanResult> scan(Uint8List bytes) async {
    final compressed = await _compress(bytes);

    final streamed = await ApiClient.postMultipart('/scan', [
      http.MultipartFile.fromBytes('image', compressed, filename: 'scan.jpg'),
    ]);
    final body = await streamed.stream.bytesToString();

    if (streamed.statusCode != 200) {
      throw Exception('Server error ${streamed.statusCode}');
    }
    return _parseResponse(bytes, body);
  }

  /// Re-scales to ~1280px and re-encodes as JPEG q80. Claude re-samples images
  /// internally, so this keeps recognition quality while cutting the payload
  /// from several MB to a few hundred KB. Falls back to the original bytes if
  /// compression yields nothing.
  Future<Uint8List> _compress(Uint8List bytes) async {
    final result = await FlutterImageCompress.compressWithList(
      bytes,
      minWidth: 1280,
      minHeight: 1280,
      quality: 80,
      format: CompressFormat.jpeg,
    );
    return result.isNotEmpty ? result : bytes;
  }

  ScanResult _parseResponse(Uint8List imageBytes, String body) {
    try {
      final map = jsonDecode(body) as Map<String, dynamic>;
      final raw = map['candidates'] as List<dynamic>? ?? [];
      final candidates = raw
          .map((e) => MachineCandidate.fromJson(e as Map<String, dynamic>))
          .toList();
      return ScanResult(imageBytes: imageBytes, candidates: candidates);
    } catch (_) {
      return ScanResult.dummy();
    }
  }

  Future<void> dispose() async {
    await _controller?.dispose();
    _controller = null;
  }
}
