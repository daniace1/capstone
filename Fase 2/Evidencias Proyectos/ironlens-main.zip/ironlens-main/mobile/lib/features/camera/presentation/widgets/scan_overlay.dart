import 'package:flutter/material.dart';

import '../../../../core/theme/app_theme.dart';

/// Animated scanning effect shown over a frozen frame while `/scan` runs.
/// A vertical sweep line travels top→bottom over reticle corner brackets.
class ScanOverlay extends StatefulWidget {
  const ScanOverlay({super.key});

  @override
  State<ScanOverlay> createState() => _ScanOverlayState();
}

class _ScanOverlayState extends State<ScanOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Dim the frozen frame so the sweep reads clearly.
        Positioned.fill(
          child: Container(color: Colors.black.withAlpha(70)),
        ),
        Positioned.fill(
          child: CustomPaint(painter: _ReticlePainter()),
        ),
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _controller,
            builder: (_, _) =>
                CustomPaint(painter: _SweepPainter(_controller.value)),
          ),
        ),
        Positioned(
          left: 0,
          right: 0,
          bottom: 120,
          child: Center(
            child: Text(
              'SCANNING...',
              style: TextStyle(
                fontFamily: 'monospace',
                fontSize: 12,
                letterSpacing: 4,
                color: AppColors.primary.withAlpha(220),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

/// Four corner brackets framing the scan area.
class _ReticlePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.primary.withAlpha(160)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    const margin = 32.0;
    const len = 28.0;
    final l = margin, t = margin;
    final r = size.width - margin, b = size.height - margin;

    // Top-left
    canvas.drawLine(Offset(l, t), Offset(l + len, t), paint);
    canvas.drawLine(Offset(l, t), Offset(l, t + len), paint);
    // Top-right
    canvas.drawLine(Offset(r, t), Offset(r - len, t), paint);
    canvas.drawLine(Offset(r, t), Offset(r, t + len), paint);
    // Bottom-left
    canvas.drawLine(Offset(l, b), Offset(l + len, b), paint);
    canvas.drawLine(Offset(l, b), Offset(l, b - len), paint);
    // Bottom-right
    canvas.drawLine(Offset(r, b), Offset(r - len, b), paint);
    canvas.drawLine(Offset(r, b), Offset(r, b - len), paint);
  }

  @override
  bool shouldRepaint(covariant _ReticlePainter oldDelegate) => false;
}

/// A horizontal line with a soft glow, swept vertically by [progress] (0–1).
class _SweepPainter extends CustomPainter {
  _SweepPainter(this.progress);

  final double progress;

  @override
  void paint(Canvas canvas, Size size) {
    const margin = 32.0;
    final top = margin;
    final bottom = size.height - margin;
    final y = top + (bottom - top) * progress;

    // Glow band trailing the line.
    final glow = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          AppColors.primary.withAlpha(0),
          AppColors.primary.withAlpha(60),
        ],
      ).createShader(Rect.fromLTWH(margin, y - 48, size.width - margin * 2, 48));
    canvas.drawRect(
      Rect.fromLTWH(margin, y - 48, size.width - margin * 2, 48),
      glow,
    );

    // The sweep line itself.
    final line = Paint()
      ..color = AppColors.primary
      ..strokeWidth = 2;
    canvas.drawLine(Offset(margin, y), Offset(size.width - margin, y), line);
  }

  @override
  bool shouldRepaint(covariant _SweepPainter oldDelegate) =>
      oldDelegate.progress != progress;
}
