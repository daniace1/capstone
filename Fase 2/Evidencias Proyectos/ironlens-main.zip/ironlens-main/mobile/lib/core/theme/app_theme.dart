import 'package:flutter/material.dart';

abstract final class AppTheme {
  static ThemeData get dark => ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: AppColors.background,
        colorScheme: const ColorScheme.dark(
          surface: AppColors.surface,
          primary: AppColors.primary,
          onPrimary: AppColors.background,
          secondary: AppColors.accent,
          onSecondary: AppColors.background,
          onSurface: AppColors.textPrimary,
        ),
        textTheme: const TextTheme(
          displayLarge: TextStyle(
            fontSize: 26,
            fontWeight: FontWeight.w200,
            color: AppColors.textPrimary,
            letterSpacing: 10,
          ),
          titleMedium: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w400,
            color: AppColors.textSecondary,
            letterSpacing: 4,
          ),
          bodyMedium: TextStyle(
            fontSize: 14,
            color: AppColors.textSecondary,
            height: 1.6,
          ),
          labelLarge: TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w600,
            color: AppColors.textSecondary,
            letterSpacing: 2.5,
          ),
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          iconTheme: IconThemeData(color: AppColors.textPrimary),
          titleTextStyle: TextStyle(
            fontSize: 11,
            fontWeight: FontWeight.w400,
            color: AppColors.textSecondary,
            letterSpacing: 4,
          ),
        ),
        iconTheme: const IconThemeData(color: AppColors.textPrimary),
        useMaterial3: true,
      );
}

abstract final class AppColors {
  // Catppuccin Mocha base
  static const Color background   = Color(0xFF0D0D0D);
  static const Color surface      = Color(0xFF181825);
  static const Color crust        = Color(0xFF11111B);

  // Text
  static const Color textPrimary  = Color(0xFFCDD6F4); // text
  static const Color textSecondary= Color(0xFF6C7086); // overlay0

  // Accents
  static const Color primary      = Color(0xFFCBA6F7); // mauve
  static const Color accent       = Color(0xFFB4BEFE); // lavender
  static const Color green        = Color(0xFFA6E3A1); // green
  static const Color teal         = Color(0xFF94E2D5); // teal
  static const Color yellow       = Color(0xFFF9E2AF); // yellow
  static const Color peach        = Color(0xFFFAB387); // peach
  static const Color red          = Color(0xFFF38BA8); // red
  static const Color subtext      = Color(0xFFBAC2DE); // subtext1

  // Borders
  static const Color borderSubtle = Color(0xFF313244); // surface1
  static const Color borderPrimary= Color(0xFF45475A); // surface2

  // Terminal screen (result page)
  static const Color termBg       = Color(0xFF0D0D0D);
  static const Color termGreen    = Color(0xFFA6E3A1);
  static const Color termMauve    = Color(0xFFCBA6F7);
  static const Color termComment  = Color(0xFF6C7086);
  static const Color termText     = Color(0xFFCDD6F4);
}
