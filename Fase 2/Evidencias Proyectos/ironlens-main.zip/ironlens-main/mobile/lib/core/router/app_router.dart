import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../features/auth/presentation/pages/login_page.dart';
import '../../features/auth/presentation/pages/profile_setup_page.dart';
import '../../features/auth/presentation/pages/register_page.dart';
import '../../features/camera/presentation/pages/camera_page.dart';
import '../../features/collection/presentation/pages/machine_picker_page.dart';
import '../../features/collection/presentation/pages/scanned_page.dart';
import '../../features/home/presentation/pages/home_page.dart';
import '../../features/progress/presentation/pages/machine_progress_page.dart';
import '../../features/progress/presentation/pages/monthly_analysis_page.dart';
import '../../features/progress/presentation/pages/progress_page.dart';
import '../../features/workout/presentation/pages/sessions_page.dart';
import '../../features/workout/presentation/pages/workout_page.dart';
import '../../features/profile/presentation/pages/profile_page.dart';
import '../../features/routine/presentation/pages/routine_execution_page.dart';
import '../../features/routine/presentation/pages/routine_page.dart';
import '../../features/result/models/scan_result.dart';
import '../../features/settings/presentation/pages/settings_page.dart';
import '../../features/result/presentation/pages/result_page.dart';
import '../../features/navi/presentation/navi_shell.dart';
import '../../features/navi/presentation/navi_scope.dart';

abstract final class AppRoutes {
  static const String home         = '/';
  static const String login        = '/login';
  static const String register     = '/register';
  static const String profileSetup = '/profile-setup';
  static const String camera       = '/camera';
  static const String result       = '/result';
  static const String scanned       = '/scanned';
  static const String progress      = '/progress';
  static const String profile       = '/profile';
  static const String settings      = '/settings';
  static const String machinePicker    = '/machine-picker';
  static const String workout          = '/workout';
  static const String sessions         = '/sessions';
  static const String routine          = '/routine';
  static const String routineExecution = '/routine-execution';
  static const String machineProgress    = '/machine-progress';
  static const String monthlyAnalysis   = '/monthly-analysis';
}

abstract final class AppRouter {
  static final _authNotifier = _AuthNotifier();

  static final GoRouter router = GoRouter(
    initialLocation: AppRoutes.home,
    refreshListenable: _authNotifier,
    redirect: (context, state) {
      final session = Supabase.instance.client.auth.currentSession;
      final loc = state.matchedLocation;

      final isAuthRoute = loc == AppRoutes.login || loc == AppRoutes.register;

      if (session == null && !isAuthRoute) return AppRoutes.login;
      if (session != null && isAuthRoute) return AppRoutes.home;
      return null;
    },
    routes: [
      GoRoute(
        path: AppRoutes.login,
        builder: (context, state) => const LoginPage(),
      ),
      GoRoute(
        path: AppRoutes.register,
        builder: (context, state) => const RegisterPage(),
      ),
      GoRoute(
        path: AppRoutes.profileSetup,
        builder: (context, state) => const ProfileSetupPage(),
      ),
      GoRoute(
        path: AppRoutes.camera,
        builder: (context, state) => const CameraPage(),
      ),
      // Everything below shares the persistent Navi assistant overlay.
      ShellRoute(
        observers: [naviRouteObserver],
        builder: (context, state, child) => NaviShell(child: child),
        routes: [
      GoRoute(
        path: AppRoutes.home,
        builder: (context, state) => const HomePage(),
      ),
      GoRoute(
        path: AppRoutes.result,
        builder: (context, state) {
          final result = state.extra as ScanResult;
          return ResultPage(result: result);
        },
      ),
      GoRoute(
        path: AppRoutes.machinePicker,
        builder: (context, state) => const MachinePickerPage(),
      ),
      GoRoute(
        path: AppRoutes.sessions,
        builder: (context, state) => const SessionsPage(),
      ),
      GoRoute(
        path: AppRoutes.workout,
        builder: (context, state) {
          final args = state.extra as Map<String, dynamic>;
          return WorkoutPage(
            machineId:         args['machineId']   as int,
            machineName:       args['machineName'] as String,
            muscleGroup:       args['muscleGroup'] as String,
            existingSessionId: args['sessionId']   as String?,
          );
        },
      ),
      GoRoute(
        path: AppRoutes.scanned,
        pageBuilder: (context, state) => _expandPage(
          key: state.pageKey,
          child: const ScannedPage(),
        ),
      ),
      GoRoute(
        path: AppRoutes.progress,
        pageBuilder: (context, state) => _expandPage(
          key: state.pageKey,
          child: const ProgressPage(),
        ),
      ),
      GoRoute(
        path: AppRoutes.machineProgress,
        builder: (context, state) {
          final args = state.extra as Map<String, dynamic>;
          return MachineProgressPage(
            machineId:   args['machineId']   as int,
            machineName: args['machineName'] as String,
            muscleGroup: args['muscleGroup'] as String,
            best1rmKg:   args['best1rmKg']   as double?,
            baselineKg:  args['baselineKg']  as double?,
          );
        },
      ),
      GoRoute(
        path: AppRoutes.routine,
        pageBuilder: (context, state) {
          final extra = state.extra as Map<String, dynamic>?;
          return _expandPage(
            key: state.pageKey,
            child: RoutinePage(autoRegen: extra?['regen'] == true),
          );
        },
      ),
      GoRoute(
        path: AppRoutes.routineExecution,
        builder: (context, state) {
          final args = state.extra as Map<String, dynamic>;
          return RoutineExecutionPage(
            routineDayId: args['routineDayId'] as String,
            dayLabel:     args['dayLabel']     as String,
          );
        },
      ),
      GoRoute(
        path: AppRoutes.profile,
        pageBuilder: (context, state) => _expandPage(
          key: state.pageKey,
          child: const ProfilePage(),
        ),
      ),
      GoRoute(
        path: AppRoutes.settings,
        pageBuilder: (context, state) => _expandPage(
          key: state.pageKey,
          child: const SettingsPage(),
        ),
      ),
      GoRoute(
        path: AppRoutes.monthlyAnalysis,
        builder: (context, state) => const MonthlyAnalysisPage(),
      ),
        ],
      ),
    ],
  );

  static CustomTransitionPage<void> _expandPage({
    required LocalKey key,
    required Widget child,
  }) {
    return CustomTransitionPage<void>(
      key: key,
      child: child,
      transitionDuration: const Duration(milliseconds: 340),
      reverseTransitionDuration: const Duration(milliseconds: 240),
      transitionsBuilder: (context, animation, secondaryAnimation, child) {
        final curved = CurvedAnimation(
          parent: animation,
          curve: Curves.easeOutCubic,
          reverseCurve: Curves.easeInCubic,
        );
        return ScaleTransition(
          scale: Tween<double>(begin: 0.88, end: 1.0).animate(curved),
          child: FadeTransition(opacity: curved, child: child),
        );
      },
    );
  }
}

class _AuthNotifier extends ChangeNotifier {
  _AuthNotifier() {
    Supabase.instance.client.auth.onAuthStateChange.listen((_) {
      notifyListeners();
    });
  }
}
