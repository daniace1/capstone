import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Three dots that bounce in a staggered loop — a "typing"/loading indicator.
class TypingDots extends StatefulWidget {
  const TypingDots({this.color, this.size = 6, super.key});

  final Color? color;
  final double size;

  @override
  State<TypingDots> createState() => _TypingDotsState();
}

class _TypingDotsState extends State<TypingDots>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = widget.color ?? AppColors.textSecondary;
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, _) {
        return Row(
          mainAxisSize: MainAxisSize.min,
          children: List.generate(3, (i) {
            // Each dot is offset in phase so they bounce in sequence.
            final phase = (_controller.value - i * 0.15) % 1.0;
            final t = phase < 0.5 ? phase * 2 : (1 - phase) * 2; // 0→1→0
            final dy = -widget.size * Curves.easeOut.transform(t.clamp(0.0, 1.0));
            return Padding(
              padding: EdgeInsets.symmetric(horizontal: widget.size * 0.4),
              child: Transform.translate(
                offset: Offset(0, dy),
                child: Container(
                  width: widget.size,
                  height: widget.size,
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            );
          }),
        );
      },
    );
  }
}
