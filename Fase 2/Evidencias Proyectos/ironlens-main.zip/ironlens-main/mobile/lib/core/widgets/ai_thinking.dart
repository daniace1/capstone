import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

import '../theme/app_theme.dart';

/// "AI thinking" state: the ✦ mark pulses while a terminal-style status line
/// cycles through [messages]. Used while routines / reports are generated.
class AiThinking extends StatefulWidget {
  const AiThinking({required this.messages, super.key});

  final List<String> messages;

  @override
  State<AiThinking> createState() => _AiThinkingState();
}

class _AiThinkingState extends State<AiThinking> {
  int _i = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    if (widget.messages.length > 1) {
      _timer = Timer.periodic(const Duration(milliseconds: 1600), (_) {
        if (!mounted) return;
        setState(() => _i = (_i + 1) % widget.messages.length);
      });
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final message = widget.messages.isEmpty ? '' : widget.messages[_i];

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            '✦',
            style: const TextStyle(
              fontSize: 40,
              color: AppColors.primary,
            ),
          )
              .animate(onPlay: (c) => c.repeat(reverse: true))
              .scaleXY(
                begin: 0.9,
                end: 1.2,
                duration: 900.ms,
                curve: Curves.easeInOut,
              )
              .fade(begin: 0.55, end: 1.0, duration: 900.ms),
          const SizedBox(height: 20),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 350),
            child: Text(
              '> $message...',
              key: ValueKey(_i),
              style: const TextStyle(
                fontSize: 11,
                color: AppColors.textSecondary,
                fontFamily: 'monospace',
                letterSpacing: 1,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
