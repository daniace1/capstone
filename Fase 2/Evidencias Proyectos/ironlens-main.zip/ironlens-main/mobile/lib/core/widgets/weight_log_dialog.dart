import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../theme/app_theme.dart';
import '../units/unit_system.dart';

/// Quick weight-entry dialog (same look as the confirm dialog, plus an input).
/// Returns the entered weight in **kg**, or null if cancelled.
Future<double?> showWeightLogDialog(BuildContext context) {
  return showDialog<double>(
    context: context,
    builder: (_) => const _WeightLogDialog(),
  );
}

class _WeightLogDialog extends StatefulWidget {
  const _WeightLogDialog();

  @override
  State<_WeightLogDialog> createState() => _WeightLogDialogState();
}

class _WeightLogDialogState extends State<_WeightLogDialog> {
  final _ctrl = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _save() {
    final kg = Units.parseWeightInput(context, _ctrl.text.trim());
    if (kg == null || kg <= 0) {
      setState(() => _error = 'enter a valid weight');
      return;
    }
    if (kg < 20 || kg > 400) {
      setState(() => _error = 'out of range');
      return;
    }
    Navigator.pop(context, kg);
  }

  @override
  Widget build(BuildContext context) {
    final unit = Units.weightUnit(context);
    return AlertDialog(
      backgroundColor: AppColors.surface,
      shape: const RoundedRectangleBorder(),
      title: const Text(
        'log weight',
        style: TextStyle(
          fontFamily: 'monospace',
          fontSize: 13,
          letterSpacing: 2,
          color: AppColors.textPrimary,
        ),
      ),
      content: TextField(
        controller: _ctrl,
        autofocus: true,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        inputFormatters: [
          FilteringTextInputFormatter.allow(RegExp(r'[0-9.,]')),
        ],
        onSubmitted: (_) => _save(),
        style: const TextStyle(
          fontFamily: 'monospace',
          fontSize: 16,
          color: AppColors.textPrimary,
        ),
        cursorColor: AppColors.primary,
        decoration: InputDecoration(
          isDense: true,
          suffixText: unit,
          suffixStyle: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 12,
            color: AppColors.textSecondary,
          ),
          errorText: _error,
          errorStyle: const TextStyle(
            fontFamily: 'monospace',
            fontSize: 10,
            color: AppColors.red,
          ),
          enabledBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: AppColors.borderSubtle),
          ),
          focusedBorder: const UnderlineInputBorder(
            borderSide: BorderSide(color: AppColors.primary),
          ),
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text(
            'cancel',
            style: TextStyle(
              fontFamily: 'monospace',
              fontSize: 11,
              letterSpacing: 1,
              color: AppColors.textSecondary,
            ),
          ),
        ),
        TextButton(
          onPressed: _save,
          child: const Text(
            'save',
            style: TextStyle(
              fontFamily: 'monospace',
              fontSize: 11,
              letterSpacing: 1,
              color: AppColors.primary,
            ),
          ),
        ),
      ],
    );
  }
}
