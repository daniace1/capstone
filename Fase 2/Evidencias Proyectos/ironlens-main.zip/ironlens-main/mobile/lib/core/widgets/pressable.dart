import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Reusable press feedback wrapper: on tap-down the child shrinks slightly and
/// (optionally) a highlight border lights up at its edge, returning on release.
///
/// No Material ink ripple — it would clash with the flat, no-rounded-corner
/// NieR aesthetic. Use [highlightBorder] for bordered elements (tiles, framed
/// buttons); leave it off for plain text links (scale only).
class Pressable extends StatefulWidget {
  const Pressable({
    required this.child,
    required this.onTap,
    this.highlightBorder = false,
    this.borderColor = AppColors.primary,
    this.scale = 0.97,
    super.key,
  });

  final Widget child;

  /// When null, the element is inert: no tap, no press feedback.
  final VoidCallback? onTap;
  final bool highlightBorder;
  final Color borderColor;
  final double scale;

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  static const _duration = Duration(milliseconds: 90);
  bool _pressed = false;

  void _set(bool v) {
    if (_pressed != v) setState(() => _pressed = v);
  }

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onTap != null;
    Widget child = widget.child;

    if (widget.highlightBorder) {
      child = Stack(
        children: [
          child,
          Positioned.fill(
            child: IgnorePointer(
              child: AnimatedOpacity(
                opacity: _pressed ? 1 : 0,
                duration: _duration,
                child: DecoratedBox(
                  decoration: BoxDecoration(
                    border: Border.all(color: widget.borderColor),
                  ),
                ),
              ),
            ),
          ),
        ],
      );
    }

    return GestureDetector(
      onTap: widget.onTap,
      onTapDown: enabled ? (_) => _set(true) : null,
      onTapUp: enabled ? (_) => _set(false) : null,
      onTapCancel: enabled ? () => _set(false) : null,
      behavior: HitTestBehavior.opaque,
      child: AnimatedScale(
        scale: _pressed ? widget.scale : 1.0,
        duration: _duration,
        curve: Curves.easeOut,
        child: child,
      ),
    );
  }
}
