import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'page_controls.dart';

/// Renders as many [items] as fit below [fixedTop] without ever needing to
/// scroll — measures the real rendered height of the fixed content and a
/// sample of rows (once, after first layout) instead of guessing constants,
/// so pagination stays correct across devices, font scales, and item
/// content that varies in height (e.g. an optional extra line).
///
/// Assumes [items] is non-empty; callers handle the empty state themselves.
class MeasuredFitList<T> extends StatefulWidget {
  const MeasuredFitList({
    required this.fixedTop,
    required this.items,
    required this.itemBuilder,
    required this.page,
    required this.onPageChanged,
    required this.onRefresh,
    this.sampleSize = 3,
    super.key,
  });

  final Widget fixedTop;
  final List<T> items;
  final Widget Function(BuildContext, T) itemBuilder;
  final int page;
  final ValueChanged<int> onPageChanged;
  final Future<void> Function() onRefresh;

  /// How many real rows to measure to estimate a safe per-row height. The
  /// max across the sample is used, so an occasional taller row (e.g. one
  /// with an extra optional line) never gets cut off.
  final int sampleSize;

  @override
  State<MeasuredFitList<T>> createState() => _MeasuredFitListState<T>();
}

class _MeasuredFitListState<T> extends State<MeasuredFitList<T>> {
  final GlobalKey _fixedKey = GlobalKey();
  List<GlobalKey> _sampleKeys = [];
  double? _fixedHeight;
  double? _rowHeight;
  int? _measuredForCount;

  @override
  void didUpdateWidget(covariant MeasuredFitList<T> old) {
    super.didUpdateWidget(old);
    // Data shape may have changed (refresh, filter change) — re-measure.
    if (old.items.length != widget.items.length) {
      _fixedHeight = null;
      _rowHeight = null;
    }
  }

  void _ensureSampleKeys(int count) {
    if (_sampleKeys.length != count) {
      _sampleKeys = List.generate(count, (_) => GlobalKey());
    }
  }

  void _measure() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final fixedH = _fixedKey.currentContext?.size?.height;
      if (fixedH == null) return;
      var maxRow = 0.0;
      for (final key in _sampleKeys) {
        final h = key.currentContext?.size?.height;
        if (h == null) return; // not laid out yet — retry next frame
        if (h > maxRow) maxRow = h;
      }
      if (maxRow <= 0) return;
      setState(() {
        _fixedHeight = fixedH;
        _rowHeight = maxRow;
        _measuredForCount = widget.items.length;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    final sampleCount = math.min(widget.sampleSize, widget.items.length);
    _ensureSampleKeys(sampleCount);

    final measured = _rowHeight != null &&
        _fixedHeight != null &&
        _measuredForCount == widget.items.length;

    if (!measured) {
      // Probe frame: render fixedTop + a small sample (keyed) to measure
      // real heights. Scroll-safe so it never visually overflows while
      // mid-measurement; corrected on the very next frame.
      _measure();
      return SingleChildScrollView(
        physics: const NeverScrollableScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            KeyedSubtree(key: _fixedKey, child: widget.fixedTop),
            for (var i = 0; i < sampleCount; i++)
              KeyedSubtree(
                key: _sampleKeys[i],
                child: widget.itemBuilder(context, widget.items[i]),
              ),
          ],
        ),
      );
    }

    return LayoutBuilder(
      builder: (context, constraints) {
        final avail =
            constraints.maxHeight - _fixedHeight! - PageControls.height;
        final rowsPerPage = math.max(1, (avail / _rowHeight!).floor());
        final totalPages = (widget.items.length / rowsPerPage).ceil();
        final page = widget.page.clamp(0, totalPages - 1);
        final start = page * rowsPerPage;
        final pageItems = widget.items.sublist(
            start, math.min(start + rowsPerPage, widget.items.length));

        return Column(
          children: [
            Expanded(
              child: RefreshIndicator(
                onRefresh: widget.onRefresh,
                color: AppColors.primary,
                backgroundColor: AppColors.surface,
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      widget.fixedTop,
                      ...pageItems
                          .map((it) => widget.itemBuilder(context, it)),
                    ],
                  ),
                ),
              ),
            ),
            PageControls(
              page: page,
              totalPages: totalPages,
              onPrev: () => widget.onPageChanged(page - 1),
              onNext: () => widget.onPageChanged(page + 1),
            ),
          ],
        );
      },
    );
  }
}
