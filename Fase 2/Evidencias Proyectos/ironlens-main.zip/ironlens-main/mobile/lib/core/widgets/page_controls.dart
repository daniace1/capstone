import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import 'pressable.dart';

/// Monospace pagination control: `‹  N / M  ›`. Hidden when there's one page.
class PageControls extends StatelessWidget {
  const PageControls({
    required this.page, // 0-based
    required this.totalPages,
    required this.onPrev,
    required this.onNext,
    super.key,
  });

  final int page;
  final int totalPages;
  final VoidCallback onPrev;
  final VoidCallback onNext;

  /// Reserved height when visible — callers subtract this from the list area.
  static const double height = 46;

  @override
  Widget build(BuildContext context) {
    if (totalPages <= 1) return const SizedBox.shrink();
    final canPrev = page > 0;
    final canNext = page < totalPages - 1;
    return SizedBox(
      height: height,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _Arrow('‹', onTap: canPrev ? onPrev : null),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Text(
              '${page + 1} / $totalPages',
              style: const TextStyle(
                fontSize: 12,
                color: AppColors.textSecondary,
                fontFamily: 'monospace',
                letterSpacing: 1,
              ),
            ),
          ),
          _Arrow('›', onTap: canNext ? onNext : null),
        ],
      ),
    );
  }
}

class _Arrow extends StatelessWidget {
  const _Arrow(this.glyph, {required this.onTap});
  final String glyph;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final color = onTap != null
        ? AppColors.primary
        : AppColors.textSecondary.withAlpha(60);
    return Pressable(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        child: Text(glyph,
            style: TextStyle(fontSize: 20, color: color, fontFamily: 'monospace')),
      ),
    );
  }
}
