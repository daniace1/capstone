/// Canonical Monday-first weekday order, shared wherever a `day_of_week`
/// text value needs a stable chronological index — routine ordering,
/// scheduling, etc. Single source of truth so nothing relies on incidental
/// array/insertion order (AI response order, Set iteration order, ...).
const List<String> weekdayOrder = [
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
  'sunday',
];

/// 0 (Monday) .. 6 (Sunday). Unrecognized values sort last.
int weekdayIndex(String dayOfWeek) {
  final i = weekdayOrder.indexOf(dayOfWeek.toLowerCase());
  return i == -1 ? weekdayOrder.length : i;
}
