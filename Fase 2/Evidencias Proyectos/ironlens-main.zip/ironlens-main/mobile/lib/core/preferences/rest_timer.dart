import 'package:shared_preferences/shared_preferences.dart';

/// Rest-timer duration (seconds) between sets, persisted locally.
const _prefRestSeconds = 'rest_timer_seconds';

/// Selectable durations shown in Settings.
const restTimerOptions = [60, 90, 120];

Future<int> getRestTimerSeconds() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getInt(_prefRestSeconds) ?? 90;
}

Future<void> setRestTimerSeconds(int seconds) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setInt(_prefRestSeconds, seconds);
}
