import 'package:shared_preferences/shared_preferences.dart';

const _prefDays      = 'weight_reminder_days';
const _prefDismissed = 'weight_reminder_dismissed';

Future<int> getWeightReminderDays() async {
  final prefs = await SharedPreferences.getInstance();
  return prefs.getInt(_prefDays) ?? 14;
}

Future<void> setWeightReminderDays(int days) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setInt(_prefDays, days);
}

/// [lastLoggedAt] is the real most-recent `weight_logs` row from Supabase —
/// the caller already has it from the same query used to show current
/// weight/delta on Home, so this never drifts from the actual data (a
/// locally-cached "last logged date" would stay stale if a log was deleted
/// or added outside the app's own log-weight flow).
Future<({bool show, int daysSince})> checkWeightOverdue(DateTime? lastLoggedAt) async {
  final prefs = await SharedPreferences.getInstance();
  final now = DateTime.now();
  final todayStr = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';

  final dismissed = prefs.getString(_prefDismissed) ?? '';
  if (dismissed == todayStr) return (show: false, daysSince: 0);

  final reminderDays = prefs.getInt(_prefDays) ?? 14;

  if (lastLoggedAt == null) return (show: true, daysSince: 0);

  final daysSince = now.difference(lastLoggedAt).inDays;
  return (show: daysSince >= reminderDays, daysSince: daysSince);
}

Future<void> dismissWeightBanner() async {
  final prefs = await SharedPreferences.getInstance();
  final now = DateTime.now();
  final todayStr = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
  await prefs.setString(_prefDismissed, todayStr);
}
