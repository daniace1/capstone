import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import 'package:supabase_flutter/supabase_flutter.dart';

class ApiClient {
  static String get _base => dotenv.env['API_BASE_URL'] ?? '';

  static String? get _token =>
      Supabase.instance.client.auth.currentSession?.accessToken;

  static Map<String, String> get _authHeader {
    final token = _token;
    return token != null ? {'Authorization': 'Bearer $token'} : {};
  }

  static Future<http.StreamedResponse> postMultipart(
    String path,
    List<http.MultipartFile> files,
  ) async {
    final request = http.MultipartRequest('POST', Uri.parse('$_base$path'))
      ..headers.addAll(_authHeader)
      ..files.addAll(files);
    return request.send();
  }

  static Future<Map<String, dynamic>> get(String path) async {
    final response = await http.get(
      Uri.parse('$_base$path'),
      headers: _authHeader,
    );
    return jsonDecode(response.body) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> post(
    String path,
    Map<String, dynamic> body,
  ) async {
    final response = await http.post(
      Uri.parse('$_base$path'),
      headers: {..._authHeader, 'Content-Type': 'application/json'},
      body: jsonEncode(body),
    );
    return jsonDecode(response.body) as Map<String, dynamic>;
  }
}
