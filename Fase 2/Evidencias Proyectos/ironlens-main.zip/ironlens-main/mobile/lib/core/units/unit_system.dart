import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kPrefKey = 'unit_system_imperial';

final ValueNotifier<bool> isImperialNotifier = ValueNotifier(false);

Future<void> loadUnitPreference() async {
  final prefs = await SharedPreferences.getInstance();
  isImperialNotifier.value = prefs.getBool(_kPrefKey) ?? false;
}

Future<void> saveUnitPreference(bool imperial) async {
  final prefs = await SharedPreferences.getInstance();
  await prefs.setBool(_kPrefKey, imperial);
  isImperialNotifier.value = imperial;
}

// Provides isImperial to the widget tree via InheritedWidget
class UnitSystemScope extends InheritedWidget {
  const UnitSystemScope({
    super.key,
    required this.isImperial,
    required super.child,
  });

  final bool isImperial;

  static UnitSystemScope of(BuildContext context) =>
      context.dependOnInheritedWidgetOfExactType<UnitSystemScope>()!;

  @override
  bool updateShouldNotify(UnitSystemScope old) => isImperial != old.isImperial;
}

// Conversion utilities — all DB values stay in kg / cm
abstract final class Units {
  static bool isImperial(BuildContext context) =>
      UnitSystemScope.of(context).isImperial;

  // Weight
  static double kgToLbs(double kg) => kg * 2.20462;
  static double lbsToKg(double lbs) => lbs / 2.20462;

  // Height
  static ({int ft, int inches}) cmToFtIn(double cm) {
    final totalInches = (cm / 2.54).round();
    return (ft: totalInches ~/ 12, inches: totalInches % 12);
  }

  static double ftInToCm(int ft, int inches) => (ft * 12 + inches) * 2.54;

  // Labels
  static String weightUnit(BuildContext context) =>
      isImperial(context) ? 'lbs' : 'kg';

  static String weightLabel(BuildContext context) =>
      isImperial(context) ? 'weight (lbs)' : 'weight (kg)';

  // Display: kg → formatted string with unit
  static String formatWeight(BuildContext context, double? kg) {
    if (kg == null) return 'bw';
    if (isImperial(context)) return '${kgToLbs(kg).toStringAsFixed(1)} lbs';
    return '${kg.toStringAsFixed(1)} kg';
  }

  // Display: kg → number only (for charts / stat blocks)
  static String formatWeightValue(BuildContext context, double kg) =>
      isImperial(context)
          ? kgToLbs(kg).toStringAsFixed(1)
          : kg.toStringAsFixed(1);

  // Display: total volume (kg) → rounded with thousands separator + unit
  static String formatVolume(BuildContext context, double kg) {
    final v = (isImperial(context) ? kgToLbs(kg) : kg).round();
    final s = v.toString().replaceAllMapped(
          RegExp(r'(\d)(?=(\d{3})+$)'),
          (m) => '${m[1]},',
        );
    return '$s ${weightUnit(context)}';
  }

  // Input: user-entered string → kg for DB storage
  static double? parseWeightInput(BuildContext context, String text) {
    final val = double.tryParse(text.replaceAll(',', '.'));
    if (val == null) return null;
    return isImperial(context) ? lbsToKg(val) : val;
  }
}
