/// Epley estimated one-rep max from a working set.
double epley1rm(double weightKg, int reps) => weightKg * (1 + reps / 30);
