import 'package:flutter/material.dart';

import '../theme/app_theme.dart';

/// Power-rank tiers, shared by the progress pages and the Navi assistant.
enum Rank { bronze, silver, gold, platinum, diamond, master }

/// Tier from a rank score (best 1RM / baseline * 100).
Rank rankFromScore(double score) {
  if (score < 80) return Rank.bronze;
  if (score < 100) return Rank.silver;
  if (score < 130) return Rank.gold;
  if (score < 170) return Rank.platinum;
  if (score < 220) return Rank.diamond;
  return Rank.master;
}

/// Tier for a machine given its best 1RM and catalog baseline. Null if the
/// baseline is missing or non-positive.
Rank? rankFor(double best1rm, double baseline) =>
    baseline > 0 ? rankFromScore(best1rm / baseline * 100) : null;

extension RankInfo on Rank {
  String get label {
    switch (this) {
      case Rank.bronze:   return 'bronze';
      case Rank.silver:   return 'silver';
      case Rank.gold:     return 'gold';
      case Rank.platinum: return 'platinum';
      case Rank.diamond:  return 'diamond';
      case Rank.master:   return 'master';
    }
  }

  Color get color {
    switch (this) {
      case Rank.bronze:   return AppColors.peach;
      case Rank.silver:   return AppColors.subtext;
      case Rank.gold:     return AppColors.yellow;
      case Rank.platinum: return AppColors.teal;
      case Rank.diamond:  return AppColors.accent;
      case Rank.master:   return AppColors.red;
    }
  }

  String get asset => 'assets/ranks/$label.webp';
}

/// Label of the next tier above [score], or null at max rank.
String? nextRankLabel(double score) {
  if (score < 80) return 'silver';
  if (score < 100) return 'gold';
  if (score < 130) return 'platinum';
  if (score < 170) return 'diamond';
  if (score < 220) return 'master';
  return null;
}

/// Score threshold to reach the next tier, or null at max rank.
double? nextRankThreshold(double score) {
  if (score < 80) return 80;
  if (score < 100) return 100;
  if (score < 130) return 130;
  if (score < 170) return 170;
  if (score < 220) return 220;
  return null;
}
