/// Body Mass Index from weight (kg) and height (cm).
double bmi(double weightKg, double heightCm) {
  final h = heightCm / 100;
  return weightKg / (h * h);
}

/// WHO category for a BMI value.
String bmiCategory(double value) {
  if (value < 18.5) return 'underweight';
  if (value < 25) return 'healthy';
  if (value < 30) return 'overweight';
  return 'obese';
}
