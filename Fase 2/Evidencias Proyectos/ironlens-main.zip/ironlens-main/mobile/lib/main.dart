import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';
import 'core/units/unit_system.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await dotenv.load(fileName: '.env');

  await Supabase.initialize(
    url: dotenv.env['SUPABASE_URL']!,
    publishableKey: dotenv.env['SUPABASE_ANON_KEY']!,
  );

  await loadUnitPreference();

  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );

  runApp(const ProviderScope(child: IronLensApp()));
}

class IronLensApp extends StatefulWidget {
  const IronLensApp({super.key});

  @override
  State<IronLensApp> createState() => _IronLensAppState();
}

class _IronLensAppState extends State<IronLensApp> {
  @override
  void initState() {
    super.initState();
    isImperialNotifier.addListener(_onUnitChanged);
  }

  @override
  void dispose() {
    isImperialNotifier.removeListener(_onUnitChanged);
    super.dispose();
  }

  void _onUnitChanged() => setState(() {});

  @override
  Widget build(BuildContext context) {
    return UnitSystemScope(
      isImperial: isImperialNotifier.value,
      child: MaterialApp.router(
        title: 'IronLens',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        routerConfig: AppRouter.router,
      ),
    );
  }
}
