# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project overview

IronLens — Android-first Flutter capstone (DUOC). Scans gym machines with Claude AI, tracks workout sessions (sets + reps/weight), and shows 30-day progress graphs.

```
app/                    ← git root
├── mobile/             ← Flutter app
│   ├── lib/
│   │   ├── core/
│   │   │   ├── network/api_client.dart   ← static HTTP wrapper (JWT auto-injected)
│   │   │   ├── router/app_router.dart    ← all routes + auth guard (15 routes)
│   │   │   └── theme/app_theme.dart      ← AppColors + AppTheme
│   │   ├── features/
│   │   │   ├── auth/          ← login, register, profile_setup pages
│   │   │   ├── camera/        ← CameraPage, CameraService
│   │   │   ├── result/        ← ResultPage (scan output, save to collection)
│   │   │   ├── collection/    ← ScannedPage, MachinePickerPage
│   │   │   ├── workout/       ← WorkoutPage, SessionsPage, sessions_provider
│   │   │   ├── progress/      ← ProgressPage, MachineProgressPage
│   │   │   ├── home/          ← HomePage (scan button + active sessions card)
│   │   │   ├── routine/       ← RoutinePage (browser + AI generation), RoutineExecutionPage
│   │   │   ├── profile/       ← ProfilePage (weight, height, goal, training days, notes)
│   │   │   └── settings/      ← SettingsPage (sign out)
│   │   └── main.dart
│   └── pubspec.yaml
└── backend/            ← FastAPI (Python) — AI endpoints only
    ├── main.py
    ├── auth.py
    ├── routers/        ← scan.py, recommend.py, routine.py
    ├── models/         ← Pydantic models per router
    └── services/claude.py
```

## Commands

```bash
# Flutter
cd mobile
flutter run                      # Android device/emulator
flutter analyze                  # lint
flutter test                     # all tests
flutter test test/path/test.dart # single test

# Backend
cd backend
uvicorn main:app --reload        # dev server (port 8000)
```

## Environment setup

Two separate `.env` files are required:

**`mobile/.env`** (bundled as Flutter asset, see `pubspec.yaml`):
```
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_ANON_KEY=
API_BASE_URL=http://10.0.2.2:8000   # Android emulator → localhost
```

**`backend/.env`**:
```
SUPABASE_URL=https://xxxx.supabase.co
SUPABASE_SERVICE_KEY=   # service_role key (not anon)
ANTHROPIC_API_KEY=      # Claude API key
```

## Tech stack (enforced)

- Flutter + Riverpod + go_router + Supabase + fl_chart
- FastAPI (Python) — AI endpoints: `POST /scan`, `POST /recommend`, `POST /generate-routine`, `POST /monthly-analysis`, `POST /chat`
- Claude (Anthropic): Haiku (scan, recommend, chat), Opus (routine), Sonnet (analysis)
- Forbidden: Firebase, Bloc, GetX, Django, Node.js

## Architecture rules

- FastAPI handles **only** AI operations (`/scan`, `/recommend`, `/generate-routine`). All other data (sessions, sets, progress, collection, routines) is direct Supabase client calls from Flutter.
- Riverpod is for shared/global state only (`activeSessionsCountProvider`). All other pages use `StatefulWidget` + `setState` for local data loading. Only `WorkoutPage` and `RoutineExecutionPage` use `ConsumerStatefulWidget` (to call `ref.invalidate`).
- UI: Catppuccin Mocha dark theme, monospace fonts, no rounded corners. All colors come from `AppColors` in `core/theme/app_theme.dart`.

## Navigation patterns

Routes and constants live in `core/router/app_router.dart`. Pages that need parameters receive them via `state.extra` as typed objects or `Map<String, dynamic>`:

```dart
// Passing data
context.push(AppRoutes.workout, extra: {
  'machineId': id, 'machineName': name, 'muscleGroup': group, 'sessionId': null,
});

// Receiving (in router builder)
final args = state.extra as Map<String, dynamic>;
```

Auth guard redirects unauthenticated users to `/login` and authenticated users away from auth routes. It is driven by a `ChangeNotifier` on `Supabase.instance.client.auth.onAuthStateChange`.

## Session lifecycle (WorkoutPage)

1. On enter: creates a new `workout_sessions` row (or resumes `existingSessionId`).
2. Each set: inserts a `workout_sets` row with `set_number`, `reps`, `weight_kg` (null = bodyweight).
3. On "done": if no sets were logged → **deletes** the session; otherwise → sets `ended_at`.
4. Always invalidates `activeSessionsCountProvider` on exit (`ref.invalidate`).

## Routine lifecycle (RoutinePage + RoutineExecutionPage)

1. `RoutinePage` loads the user's stored routine from `routines` table; calls `POST /generate-routine` if none exists or it has expired.
2. Weekly plan displays as day cards. Days marked "done" when `routine_log_items` exist with `ended_at` set.
3. "Start" (or "Redo") navigates to `RoutineExecutionPage` with the day's exercise list.
4. `RoutineExecutionPage`: per-exercise set logging; creates a `workout_sessions` row on first set for each exercise; inserts `routine_log_items` for tracking.
5. "Finish" → finalizes the log, invalidates `activeSessionsCountProvider`.

## Scan → save → workout flow

`CameraPage` auto-captures → posts image to `ApiClient.postMultipart('/scan')` with JWT → `ResultPage` receives a `ScanResult` (top candidate + alternatives). Tapping "save" upserts into `scanned_machines` then immediately navigates to `WorkoutPage`.

## Database (Supabase)

Key tables: `machines`, `scanned_machines`, `workout_sessions`, `workout_sets`, `routines`, `routine_log_items`, `profiles`

- `scanned_machines` and `workout_sessions` FK → `auth.users(id)` (not `profiles.id`)
- `workout_sessions`: `id, user_id, machine_id, started_at, ended_at` (null = still active)
- `workout_sets`: `id, session_id, machine_id, set_number, reps, weight_kg` (null = bodyweight)
- `routines`: AI-generated weekly plan per user; `RoutinePage` re-generates if missing or expired
- `routine_log_items`: tracks completion per exercise within a routine execution day
- Full schema: `docs/schema.sql`

## Key provider

```dart
// lib/features/workout/providers/sessions_provider.dart
final activeSessionsCountProvider = FutureProvider.autoDispose<int>(...);
// Invalidate explicitly after session changes: ref.invalidate(activeSessionsCountProvider)
```

Counts today's sessions with `ended_at IS NULL` that have at least one set — drives the home screen card.

## Roadmap

MVP (phases 1–6) complete. Current development: **Phase 2 — AI coach** (phases 7–10). See [README.md](README.md) for full scope and pending DB changes.

## Progress graphs

`MachineProgressPage` queries `workout_sessions` joined with `workout_sets` for the last 30 days. If any set has a `weight_kg`, graphs **max weight per day**; otherwise graphs **max reps per day**. Uses `fl_chart` `LineChart` with `FlSpot`.
